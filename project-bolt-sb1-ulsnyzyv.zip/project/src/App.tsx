import React, { useState } from 'react';
import { Tv, Menu, X } from 'lucide-react';
import HomePage from './components/HomePage';
import PricingPage from './components/PricingPage';
import BookingPage from './components/BookingPage';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState('home');
  
  const handleGetQuote = () => {
    setCurrentPage('booking');
  };

  const handleBookNow = () => {
    setCurrentPage('booking');
  };

  const navigateToHome = (e) => {
    e.preventDefault();
    setCurrentPage('home');
    setIsMenuOpen(false);
  };

  const navigateToPricing = (e) => {
    e.preventDefault();
    setCurrentPage('pricing');
    setIsMenuOpen(false);
  };
  
  const navigateToBooking = (e) => {
    e.preventDefault();
    setCurrentPage('booking');
    setIsMenuOpen(false);
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Navigation Bar */}
      <header className="fixed top-0 left-0 right-0 bg-white shadow-md z-10">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <Tv size={24} className="text-blue-600 mr-2" />
              <span className="font-bold text-xl text-gray-800">Picture Perfect</span>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <a 
                href="#" 
                onClick={navigateToHome} 
                className={`font-medium ${currentPage === 'home' ? 'text-blue-600' : 'text-gray-800 hover:text-blue-600'}`}
              >
                Home
              </a>
              <a 
                href="#" 
                onClick={navigateToPricing} 
                className={`font-medium ${currentPage === 'pricing' ? 'text-blue-600' : 'text-gray-800 hover:text-blue-600'}`}
              >
                Pricing
              </a>
              <button 
                onClick={navigateToBooking} 
                className={`${currentPage === 'booking' 
                  ? 'bg-blue-600' 
                  : 'bg-blue-500 hover:bg-blue-600'} text-white font-medium py-2 px-4 rounded-md transition-colors duration-300`}
              >
                Book Now
              </button>
            </nav>
            
            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button 
                onClick={toggleMenu}
                className="text-gray-700 hover:text-blue-600 focus:outline-none"
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
          
          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden py-4 border-t border-gray-200">
              <div className="flex flex-col space-y-4">
                <a 
                  href="#" 
                  onClick={navigateToHome} 
                  className={`font-medium ${currentPage === 'home' ? 'text-blue-600' : 'text-gray-800 hover:text-blue-600'}`}
                >
                  Home
                </a>
                <a 
                  href="#" 
                  onClick={navigateToPricing} 
                  className={`font-medium ${currentPage === 'pricing' ? 'text-blue-600' : 'text-gray-800 hover:text-blue-600'}`}
                >
                  Pricing
                </a>
                <button 
                  onClick={(e) => { navigateToBooking(e); setIsMenuOpen(false); }} 
                  className={`${currentPage === 'booking' 
                    ? 'bg-blue-600' 
                    : 'bg-blue-500 hover:bg-blue-600'} text-white font-medium py-2 px-4 rounded-md transition-colors duration-300 text-left`}
                >
                  Book Now
                </button>
              </div>
            </div>
          )}
        </div>
      </header>
      
      {/* Main Content */}
      <main className="flex-grow flex items-center justify-center p-4 mt-16">
        {currentPage === 'home' && <HomePage onGetQuote={handleGetQuote} />}
        {currentPage === 'pricing' && <PricingPage />}
        {currentPage === 'booking' && <BookingPage />}
      </main>
    </div>
  );
}

export default App;