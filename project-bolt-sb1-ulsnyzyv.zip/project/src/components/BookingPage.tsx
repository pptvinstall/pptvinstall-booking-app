Here's the fixed version with the missing closing brackets and whitespace:

```javascript
                {/* Total */}
                <div className="border-t border-gray-300 pt-2 mt-2">
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total{pricing.requiresEstimate ? ' (Partial)' : ''}</span>
                    <span>${pricing.total}</span>
                  </div>
                  {pricing.requiresEstimate && (
                    <p className="text-sm text-orange-600 mt-2">
                      * Final price will be determined after in-person assessment of fireplace wire concealment
                    </p>
                  )}
                </div>
              </div>
            </div>
            
            {/* Submit Button */}
            <div className="text-center">
              <button
                type="submit"
                className="bg-blue-600 text-white font-medium py-3 px-8 rounded-md hover:bg-blue-700 transition-colors duration-300"
              >
                Submit Booking Request
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

export default BookingPage;
```