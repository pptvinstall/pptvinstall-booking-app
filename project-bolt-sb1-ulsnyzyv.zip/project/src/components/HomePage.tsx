import React from 'react';
import { Tv } from 'lucide-react';

function HomePage({ onGetQuote }) {
  return (
    <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full text-center">
      <div className="flex justify-center mb-4">
        <Tv size={48} className="text-blue-600" />
      </div>
      <h1 className="text-3xl font-bold text-gray-800 mb-2">Picture Perfect TV Install</h1>
      <p className="text-gray-600 mb-6">Expert TV mounting services with top-quality installation.</p>
      <button 
        onClick={onGetQuote}
        className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-6 rounded-md transition-colors duration-300"
      >
        Get a Quote
      </button>
    </div>
  );
}

export default HomePage;