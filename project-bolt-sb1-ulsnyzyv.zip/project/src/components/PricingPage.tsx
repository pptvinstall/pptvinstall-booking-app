import React from 'react';
import { Tag } from 'lucide-react';
import { pricingData, discountData } from '../data/pricingData';

function PricingPage() {
  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Our Pricing</h1>
        <p className="text-gray-600">Transparent pricing for professional TV mounting services</p>
      </div>
      
      <div className="grid md:grid-cols-2 gap-6">
        {pricingData.map((item) => (
          <div key={item.id} className={`bg-white p-6 rounded-lg shadow-md border-t-4 ${item.borderColor}`}>
            <div className="flex items-center mb-4">
              <div className={`${item.iconBgColor} p-3 rounded-full mr-4`}>
                <item.icon className={item.iconColor} size={24} />
              </div>
              <h2 className="text-xl font-bold text-gray-800">{item.title}</h2>
            </div>
            <p className="text-gray-600 mb-4">{item.description}</p>
            <div className="flex items-center justify-between">
              <span className={`text-2xl font-bold ${item.iconColor}`}>{item.price}</span>
              {item.priceNote && <span className="text-sm text-gray-500">{item.priceNote}</span>}
            </div>
            <ul className="mt-4 space-y-2 text-sm text-gray-600">
              {item.features.map((feature, index) => (
                <li key={index} className="flex items-start">
                  <span className="text-green-500 mr-2">✓</span>
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      
      {/* Discounts Section */}
      <div className="mt-10 bg-white p-6 rounded-lg shadow-md border-t-4 border-green-500">
        <div className="flex items-center mb-4">
          <div className="bg-green-100 p-3 rounded-full mr-4">
            <Tag className="text-green-600" size={24} />
          </div>
          <h2 className="text-xl font-bold text-gray-800">Available Discounts</h2>
        </div>
        
        <div className="grid md:grid-cols-2 gap-4 mt-4">
          {discountData.map((discount) => (
            <div key={discount.id} className="border border-gray-200 rounded-lg p-4">
              <h3 className="font-bold text-gray-800 mb-2">{discount.title}</h3>
              <p className="text-gray-600 mb-2">{discount.description}</p>
              <div className="text-sm text-gray-500">
                {discount.details}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Call to Action */}
      <div className="mt-10 text-center">
        <p className="text-gray-600 mb-4">Ready to get your TV professionally mounted?</p>
        <button className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-6 rounded-md transition-colors duration-300">
          Contact Us for a Quote
        </button>
      </div>
    </div>
  );
}

export default PricingPage;