# PPTV Booking Integration

A full-stack application for handling PPTV booking integrations with email notifications and calendar events.

## Project Structure

- **Frontend**: React application built with Vite
- **Backend**: Express.js server with routes for booking management
- **Integrations**: 
  - SendGrid for email confirmations
  - Google Calendar API for appointment scheduling

## Features

- **Booking Form**: User-friendly form for submitting booking requests
- **Email Confirmations**: Automated email confirmations sent to customers
- **Calendar Integration**: Automatic creation of calendar events for appointments
- **Integration Status**: Real-time feedback on integration success/failure
- **Status Dashboard**: API endpoint to check the status of recent bookings
- **Retry Mechanism**: Ability to retry failed email or calendar integrations

## Setup Instructions

### Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- SendGrid account with API key
- Google Cloud project with Calendar API enabled
- Google OAuth credentials

### Installation

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```
3. Set up environment variables:
   ```
   cp .env.example .env
   ```
4. Edit the `.env` file and fill in your credentials:
   - `PORT`: Server port (default: 3001)
   - `SENDGRID_API_KEY`: Your SendGrid API key
   - `EMAIL_FROM`: Verified sender email for SendGrid
   - `GOOGLE_CLIENT_ID`: Google OAuth client ID
   - `GOOGLE_CLIENT_SECRET`: Google OAuth client secret
   - `GOOGLE_REFRESH_TOKEN`: Google OAuth refresh token
   - `GOOGLE_CALENDAR_ID`: ID of the Google Calendar to use

### Google Calendar Setup

1. Create a project in the [Google Cloud Console](https://console.cloud.google.com/)
2. Enable the Google Calendar API
3. Create OAuth 2.0 credentials (Web application type)
4. Set up the OAuth consent screen
5. Use the OAuth Playground to get a refresh token:
   - Go to [OAuth 2.0 Playground](https://developers.google.com/oauthplayground/)
   - Click the gear icon and check "Use your own OAuth credentials"
   - Enter your Client ID and Client Secret
   - Select "Calendar API v3" from the list of APIs
   - Authorize the APIs and exchange the authorization code for tokens
   - Copy the refresh token to your `.env` file

### SendGrid Setup

1. Create a [SendGrid account](https://sendgrid.com/)
2. Create an API key with full access or restricted to "Mail Send" permissions
3. Verify a sender email address in SendGrid
4. Add the API key and verified sender email to your `.env` file

### Running the Application

Development mode (both frontend and backend):
```
npm run dev
```

Frontend only:
```
npm run dev:frontend
```

Backend only:
```
npm run dev:backend
```

Build for production:
```
npm run build
```

## Testing the Integration

### Using the React Form

1. Start the application with `npm run dev`
2. Open your browser to `http://localhost:3000`
3. Fill out the booking form with test data:
   - Customer Name: Your name
   - Customer Email: Your email address (to receive the confirmation)
   - Booking Date & Time: Select a future date and time
   - Services: Enter services separated by commas (e.g., "TV Mounting, Sound Bar Installation")
   - Travel Fee: Enter an amount if applicable
4. Click "Submit Booking"
5. The form will display the integration status showing:
   - Email confirmation status (success/failure)
   - Calendar event creation status (success/failure)
   - Link to view the calendar event (if successful)
6. Check your email for the confirmation message
7. Check your Google Calendar for the new event

### Using Postman or cURL

You can test the API directly using Postman or cURL:

```bash
# Submit a booking
curl -X POST http://localhost:3001/api/booking/submit \
  -H "Content-Type: application/json" \
  -d '{
    "customerName": "Test Customer",
    "customerEmail": "your-email@example.com",
    "bookingDateTime": "2023-06-15T14:00:00Z",
    "services": ["TV Mounting", "Sound Bar Installation"],
    "travelFee": 25
  }'

# Check the status of the last booking
curl http://localhost:3001/api/booking/status

# Retry email sending for the last booking
curl -X POST http://localhost:3001/api/booking/retry-email \
  -H "Content-Type: application/json" \
  -d '{
    "customerEmail": "your-email@example.com"
  }'

# Retry calendar event creation for the last booking
curl -X POST http://localhost:3001/api/booking/retry-calendar \
  -H "Content-Type: application/json" \
  -d '{}'
```

## API Endpoints

### Booking

- **POST /api/booking/submit**
  - Submit a new booking
  - Request body:
    ```json
    {
      "customerName": "John Doe",
      "customerEmail": "john@example.com",
      "bookingDateTime": "2023-06-15T14:00:00Z",
      "services": ["TV Mounting", "Sound Bar Installation"],
      "travelFee": 25
    }
    ```
  - Response:
    ```json
    {
      "success": true,
      "message": "Booking received successfully",
      "data": {
        "bookingId": "1623762000000",
        "customerName": "John Doe",
        "customerEmail": "john@example.com",
        "bookingDateTime": "2023-06-15T14:00:00Z",
        "services": ["TV Mounting", "Sound Bar Installation"],
        "travelFee": 25
      },
      "integrations": {
        "email": {
          "success": true,
          "message": "Email sent successfully",
          "timestamp": "2023-06-15T14:01:23Z"
        },
        "calendar": {
          "success": true,
          "message": "Calendar event created successfully",
          "eventLink": "https://calendar.google.com/calendar/event?eid=...",
          "timestamp": "2023-06-15T14:01:24Z"
        }
      }
    }
    ```

- **GET /api/booking/status**
  - Get the status of the last booking integration
  - Response:
    ```json
    {
      "success": true,
      "data": {
        "bookingId": "1623762000000",
        "customerName": "John Doe",
        "bookingDateTime": "2023-06-15T14:00:00Z",
        "integrationStatus": {
          "email": {
            "success": true,
            "message": "Email sent successfully",
            "timestamp": "2023-06-15T14:01:23Z"
          },
          "calendar": {
            "success": true,
            "message": "Calendar event created successfully",
            "eventLink": "https://calendar.google.com/calendar/event?eid=...",
            "timestamp": "2023-06-15T14:01:24Z"
          }
        },
        "timestamp": "2023-06-15T14:01:25Z"
      }
    }
    ```

- **POST /api/booking/retry-email**
  - Retry sending email for the last booking
  - Request body (optional):
    ```json
    {
      "customerEmail": "john@example.com"
    }
    ```
  - Response:
    ```json
    {
      "success": true,
      "message": "Email retry successful",
      "data": {
        "bookingId": "1623762000000",
        "customerName": "John Doe",
        "bookingDateTime": "2023-06-15T14:00:00Z",
        "integrationStatus": {
          "email": {
            "success": true,
            "message": "Email sent successfully",
            "timestamp": "2023-06-15T14:05:23Z"
          },
          "calendar": {
            "success": true,
            "message": "Calendar event created successfully",
            "eventLink": "https://calendar.google.com/calendar/event?eid=...",
            "timestamp": "2023-06-15T14:01:24Z"
          }
        },
        "timestamp": "2023-06-15T14:05:25Z"
      }
    }
    ```

- **POST /api/booking/retry-calendar**
  - Retry creating calendar event for the last booking
  - Request body (optional):
    ```json
    {
      "bookingDateTime": "2023-06-15T15:00:00Z"
    }
    ```
  - Response:
    ```json
    {
      "success": true,
      "message": "Calendar event retry successful",
      "data": {
        "bookingId": "1623762000000",
        "customerName": "John Doe",
        "bookingDateTime": "2023-06-15T14:00:00Z",
        "integrationStatus": {
          "email": {
            "success": true,
            "message": "Email sent successfully",
            "timestamp": "2023-06-15T14:01:23Z"
          },
          "calendar": {
            "success": true,
            "message": "Calendar event created successfully",
            "eventLink": "https://calendar.google.com/calendar/event?eid=...",
            "timestamp": "2023-06-15T14:10:24Z"
          }
        },
        "timestamp": "2023-06-15T14:10:25Z"
      }
    }
    ```

## Troubleshooting

### Email Integration Issues

- **API Key Invalid**: Verify your SendGrid API key is correct and active
  - Check for any spaces or extra characters in the .env file
  - Regenerate the API key if necessary
  
- **Sender Email Not Verified**: Ensure your sender email is verified in SendGrid
  - Complete the verification process in your SendGrid account
  - Use a different verified sender email if available
  
- **Rate Limiting**: SendGrid may rate limit your requests
  - Check the error response for rate limiting information
  - Implement retry logic with exponential backoff
  
- **Email Content Issues**: If emails are being sent but look incorrect
  - Check the HTML template in `backend/utils/email.js`
  - Verify that all variables are being properly interpolated
  - Test the email template with different email clients

### Calendar Integration Issues

- **Authentication Errors**: Verify all Google OAuth credentials
  - Check that the client ID and secret are correct
  - Ensure the refresh token is valid and has not expired
  - Regenerate the refresh token if necessary
  
- **Permission Issues**: Ensure you have the correct permissions
  - Verify the Google Calendar API is enabled in your Google Cloud project
  - Check that you have write access to the specified calendar ID
  - Verify the OAuth scopes include calendar write permissions
  
- **Calendar ID Not Found**: Confirm the calendar ID exists
  - Check the calendar ID in your Google Calendar settings
  - Ensure you're using the correct calendar ID format
  
- **Date/Time Format Issues**: If events are created at incorrect times
  - Verify that the date/time is being properly formatted
  - Check timezone settings in the calendar event creation
  - Test with different date/time values

### Server Logs

For detailed troubleshooting, check the server logs. The application includes enhanced logging for both integrations:

- Email sending attempts and responses
- Calendar event creation attempts and responses
- Detailed error information for failed integrations

### Common Error Codes

- **SendGrid Error Codes**:
  - `401`: Invalid API key
  - `403`: Forbidden (e.g., unverified sender)
  - `429`: Too many requests (rate limiting)
  
- **Google Calendar API Error Codes**:
  - `400`: Bad request (invalid parameters)
  - `401`: Unauthorized (invalid credentials)
  - `403`: Forbidden (insufficient permissions)
  - `404`: Not found (invalid calendar ID)

### Retry Mechanism

If an integration fails, you can use the retry mechanism:

1. **Frontend**: Use the "Retry Email" or "Retry Calendar" buttons that appear when an integration fails
2. **API**: Use the `/api/booking/retry-email` or `/api/booking/retry-calendar` endpoints

## Advanced Configuration

### Environment Variables

Additional optional environment variables:

- `NODE_ENV`: Set to "development" for verbose error details or "production" for minimal error information
- `LOG_LEVEL`: Control the verbosity of logs (e.g., "error", "warn", "info", "debug")

### Email Template Customization

The email template can be customized by modifying the HTML in `backend/utils/email.js`. The template uses inline CSS for maximum email client compatibility.

### Calendar Event Customization

Calendar events can be customized by modifying the event object in `backend/utils/calendar.js`. You can adjust:

- Event duration (currently set to 1 hour)
- Reminder settings
- Color coding
- Visibility settings

## Screenshots

![Booking Form](https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80)

![Integration Status](https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80)