import React, { useState, useEffect } from 'react';
import { Send, Calendar, Mail, CheckCircle, XCircle, Loader2, AlertCircle, Info, RefreshCw } from 'lucide-react';

// Define types for form data and integration status
interface FormData {
  customerName: string;
  customerEmail: string;
  bookingDateTime: string;
  services: string;
  travelFee: string;
}

interface IntegrationStatus {
  success: boolean;
  message: string;
  timestamp: string;
  eventLink?: string | null;
}

interface BookingResponse {
  success: boolean;
  message: string;
  data: {
    bookingId: string;
    [key: string]: any;
  };
  integrations: {
    email: IntegrationStatus;
    calendar: IntegrationStatus;
  };
}

function App() {
  // Form state
  const [formData, setFormData] = useState<FormData>({
    customerName: '',
    customerEmail: '',
    bookingDateTime: '',
    services: '',
    travelFee: ''
  });
  
  // UI state
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isError, setIsError] = useState(false);
  
  // Integration status state
  const [integrationStatus, setIntegrationStatus] = useState<{
    email: IntegrationStatus | null;
    calendar: IntegrationStatus | null;
  }>({
    email: null,
    calendar: null
  });
  
  // Booking ID for reference
  const [bookingId, setBookingId] = useState<string | null>(null);
  
  // Status polling state
  const [isPolling, setIsPolling] = useState(false);
  const [showStatusDetails, setShowStatusDetails] = useState(false);
  
  // Retry state
  const [isRetryingEmail, setIsRetryingEmail] = useState(false);
  const [isRetryingCalendar, setIsRetryingCalendar] = useState(false);

  // Handle form input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage('');
    setIsSuccess(false);
    setIsError(false);
    setIntegrationStatus({ email: null, calendar: null });
    setBookingId(null);
    setShowStatusDetails(false);
    
    try {
      // Format the data for the API
      const bookingData = {
        ...formData,
        services: formData.services.split(',').map(service => service.trim()),
        travelFee: formData.travelFee ? parseFloat(formData.travelFee) : 0
      };
      
      // Make API call to backend
      const response = await fetch('http://localhost:3001/api/booking/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(bookingData),
      });
      
      const data = await response.json() as BookingResponse;
      
      if (response.ok) {
        setIsSuccess(true);
        setMessage(data.message);
        setIntegrationStatus(data.integrations);
        setBookingId(data.data.bookingId);
        setShowStatusDetails(true);
        
        // Reset form
        setFormData({
          customerName: '',
          customerEmail: '',
          bookingDateTime: '',
          services: '',
          travelFee: ''
        });
      } else {
        setIsError(true);
        setMessage(data.message || 'Something went wrong');
      }
    } catch (error) {
      setIsError(true);
      setMessage('Failed to connect to the server');
      console.error('Error submitting booking:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Function to check booking status
  const checkBookingStatus = async () => {
    if (!bookingId) return;
    
    setIsPolling(true);
    
    try {
      const response = await fetch('http://localhost:3001/api/booking/status');
      const data = await response.json();
      
      if (response.ok && data.success) {
        setIntegrationStatus(data.data.integrationStatus);
      }
    } catch (error) {
      console.error('Error checking booking status:', error);
    } finally {
      setIsPolling(false);
    }
  };
  
  // Function to retry email sending
  const retryEmailSending = async () => {
    if (!bookingId) return;
    
    setIsRetryingEmail(true);
    
    try {
      const response = await fetch('http://localhost:3001/api/booking/retry-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          customerEmail: formData.customerEmail || integrationStatus.email?.message.split(':')[1]?.trim()
        }),
      });
      
      const data = await response.json();
      
      if (response.ok && data.success) {
        setIntegrationStatus(prev => ({
          ...prev,
          email: data.data.integrationStatus.email
        }));
        
        // Show success message
        alert('Email retry was successful!');
      } else {
        // Show error message
        alert(`Email retry failed: ${data.message}`);
      }
    } catch (error) {
      console.error('Error retrying email:', error);
      alert('Failed to retry email sending. Please check console for details.');
    } finally {
      setIsRetryingEmail(false);
    }
  };
  
  // Function to retry calendar event creation
  const retryCalendarEvent = async () => {
    if (!bookingId) return;
    
    setIsRetryingCalendar(true);
    
    try {
      const response = await fetch('http://localhost:3001/api/booking/retry-calendar', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),
      });
      
      const data = await response.json();
      
      if (response.ok && data.success) {
        setIntegrationStatus(prev => ({
          ...prev,
          calendar: data.data.integrationStatus.calendar
        }));
        
        // Show success message
        alert('Calendar event retry was successful!');
      } else {
        // Show error message
        alert(`Calendar event retry failed: ${data.message}`);
      }
    } catch (error) {
      console.error('Error retrying calendar event:', error);
      alert('Failed to retry calendar event creation. Please check console for details.');
    } finally {
      setIsRetryingCalendar(false);
    }
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    
    try {
      return new Date(dateString).toLocaleString();
    } catch (e) {
      return dateString;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden">
        <div className="bg-blue-600 px-6 py-4">
          <h1 className="text-white text-xl font-bold">PPTV Booking Integration</h1>
        </div>
        
        <div className="px-6 py-4">
          <p className="text-gray-700 mb-4">
            Submit a booking request using the form below.
          </p>
          
          {message && (
            <div className={`p-4 mb-4 rounded ${isSuccess ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  {isSuccess ? (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500" />
                  )}
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium">{message}</p>
                  {bookingId && (
                    <p className="text-xs mt-1">Booking ID: {bookingId}</p>
                  )}
                </div>
              </div>
            </div>
          )}
          
          {/* Integration Status Section */}
          {showStatusDetails && integrationStatus.email && integrationStatus.calendar && (
            <div className="mb-6 border rounded-md overflow-hidden">
              <div className="bg-gray-50 px-4 py-2 border-b">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-medium text-gray-700">Integration Status</h3>
                  <button 
                    onClick={() => checkBookingStatus()}
                    disabled={isPolling}
                    className="text-xs text-blue-600 hover:text-blue-800 flex items-center"
                  >
                    {isPolling ? (
                      <>
                        <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                        Refreshing...
                      </>
                    ) : (
                      <>
                        <Info className="h-3 w-3 mr-1" />
                        Refresh Status
                      </>
                    )}
                  </button>
                </div>
              </div>
              
              <div className="px-4 py-3 border-b">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <div className="ml-3 flex-grow">
                    <h4 className="text-sm font-medium text-gray-900">Email Confirmation</h4>
                    <div className="mt-1 flex items-center">
                      {integrationStatus.email.success ? (
                        <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500 mr-1" />
                      )}
                      <p className="text-xs text-gray-500">{integrationStatus.email.message}</p>
                    </div>
                    <p className="text-xs text-gray-400 mt-1">
                      {formatDate(integrationStatus.email.timestamp)}
                    </p>
                    
                    {/* Retry Email Button */}
                    {!integrationStatus.email.success && (
                      <button
                        onClick={retryEmailSending}
                        disabled={isRetryingEmail}
                        className="mt-2 inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      >
                        {isRetryingEmail ? (
                          <>
                            <Loader2 className="animate-spin h-3 w-3 mr-1" />
                            Retrying...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="h-3 w-3 mr-1" />
                            Retry Email
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="px-4 py-3">
                <div className="flex items-start">
                  <div className="flex-shrink-0">
                    <Calendar className="h-5 w-5 text-gray-400" />
                  </div>
                  <div className="ml-3 flex-grow">
                    <h4 className="text-sm font-medium text-gray-900">Calendar Event</h4>
                    <div className="mt-1 flex items-center">
                      {integrationStatus.calendar.success ? (
                        <CheckCircle className="h-4 w-4 text-green-500 mr-1" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500 mr-1" />
                      )}
                      <p className="text-xs text-gray-500">{integrationStatus.calendar.message}</p>
                    </div>
                    {integrationStatus.calendar.eventLink && (
                      <a 
                        href={integrationStatus.calendar.eventLink} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-xs text-blue-600 hover:text-blue-800 mt-1 inline-block"
                      >
                        View Calendar Event
                      </a>
                    )}
                    <p className="text-xs text-gray-400 mt-1">
                      {formatDate(integrationStatus.calendar.timestamp)}
                    </p>
                    
                    {/* Retry Calendar Button */}
                    {!integrationStatus.calendar.success && (
                      <button
                        onClick={retryCalendarEvent}
                        disabled={isRetryingCalendar}
                        className="mt-2 inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      >
                        {isRetryingCalendar ? (
                          <>
                            <Loader2 className="animate-spin h-3 w-3 mr-1" />
                            Retrying...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="h-3 w-3 mr-1" />
                            Retry Calendar
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Booking Form */}
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="customerName" className="block text-gray-700 text-sm font-bold mb-2">
                Customer Name *
              </label>
              <input
                type="text"
                id="customerName"
                name="customerName"
                value={formData.customerName}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                required
                aria-required="true"
              />
            </div>
            
            <div className="mb-4">
              <label htmlFor="customerEmail" className="block text-gray-700 text-sm font-bold mb-2">
                Customer Email *
              </label>
              <input
                type="email"
                id="customerEmail"
                name="customerEmail"
                value={formData.customerEmail}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                required
                aria-required="true"
              />
            </div>
            
            <div className="mb-4">
              <label htmlFor="bookingDateTime" className="block text-gray-700 text-sm font-bold mb-2">
                Booking Date & Time *
              </label>
              <input
                type="datetime-local"
                id="bookingDateTime"
                name="bookingDateTime"
                value={formData.bookingDateTime}
                onChange={handleChange}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                required
                aria-required="true"
              />
            </div>
            
            <div className="mb-4">
              <label htmlFor="services" className="block text-gray-700 text-sm font-bold mb-2">
                Services (comma separated) *
              </label>
              <input
                type="text"
                id="services"
                name="services"
                value={formData.services}
                onChange={handleChange}
                placeholder="TV Mounting, Sound Bar Installation"
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                required
                aria-required="true"
              />
              <p className="text-xs text-gray-500 mt-1">
                Example: TV Mounting, Sound Bar Installation, Cable Management
              </p>
            </div>
            
            <div className="mb-6">
              <label htmlFor="travelFee" className="block text-gray-700 text-sm font-bold mb-2">
                Travel Fee (if applicable)
              </label>
              <input
                type="number"
                id="travelFee"
                name="travelFee"
                value={formData.travelFee}
                onChange={handleChange}
                placeholder="0.00"
                step="0.01"
                min="0"
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                aria-required="false"
              />
            </div>
            
            <div className="flex items-center justify-end">
              <button
                type="submit"
                disabled={isLoading}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
                aria-busy={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    Submit Booking
                    <Send className="ml-2 h-4 w-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
        
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
          <p className="text-xs text-gray-500">
            This booking form connects with SendGrid for email confirmations and Google Calendar for appointment scheduling.
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;