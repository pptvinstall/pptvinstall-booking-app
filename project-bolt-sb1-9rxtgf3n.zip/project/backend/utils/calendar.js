import { google } from 'googleapis';

/**
 * Create a calendar event for the booking
 * @param {Object} bookingData - Booking information
 * @returns {Promise} - Promise resolving when calendar event is created
 */
export const createCalendarEvent = async (bookingData) => {
  try {
    // Log the start of calendar integration
    console.log(`Starting Google Calendar integration for booking: ${bookingData.customerName} at ${bookingData.bookingDateTime}`);
    
    // Create OAuth2 client with credentials from environment variables
    const oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET
    );
    
    // Set credentials using refresh token
    oauth2Client.setCredentials({
      refresh_token: process.env.GOOGLE_REFRESH_TOKEN
    });
    
    // Log OAuth setup
    console.log('Google OAuth client initialized');
    
    // Create Google Calendar client
    const calendar = google.calendar({ version: 'v3', auth: oauth2Client });
    
    // Calculate event duration (default to 1 hour if not specified)
    const startTime = new Date(bookingData.bookingDateTime);
    const endTime = new Date(startTime.getTime() + 60 * 60 * 1000); // Add 1 hour
    
    // Format services for description
    const servicesText = bookingData.services.join(', ');
    
    // Log event preparation
    console.log(`Preparing calendar event for ${startTime.toISOString()} to ${endTime.toISOString()}`);
    
    // Create event details with enhanced metadata
    const event = {
      summary: `PPTV Mounting Appointment for ${bookingData.customerName}`,
      description: `
Services: ${servicesText}
Customer: ${bookingData.customerName}
Email: ${bookingData.customerEmail}
${bookingData.travelFee ? `Travel Fee: $${bookingData.travelFee.toFixed(2)}` : ''}

Booking ID: ${Date.now().toString()}
Created via PPTV Booking Integration System
      `.trim(),
      start: {
        dateTime: startTime.toISOString(),
        timeZone: 'America/New_York',
      },
      end: {
        dateTime: endTime.toISOString(),
        timeZone: 'America/New_York',
      },
      // Add reminder notifications
      reminders: {
        useDefault: false,
        overrides: [
          { method: 'email', minutes: 24 * 60 }, // 1 day before
          { method: 'popup', minutes: 60 }, // 1 hour before
        ],
      },
      // Add color coding (optional)
      colorId: '4', // Typically represents "Appointment" in Google Calendar
      // Add status
      status: 'confirmed',
      // Add transparency (shows as busy)
      transparency: 'opaque',
      // Add visibility
      visibility: 'private',
    };
    
    // Log the calendar ID being used
    console.log(`Using Google Calendar ID: ${process.env.GOOGLE_CALENDAR_ID}`);
    
    // Insert the event into the calendar with detailed logging
    console.log('Sending request to Google Calendar API');
    const response = await calendar.events.insert({
      calendarId: process.env.GOOGLE_CALENDAR_ID,
      resource: event,
    });
    
    // Log success with event details
    console.log(`Calendar event created successfully. Event ID: ${response.data.id}`);
    console.log(`Event link: ${response.data.htmlLink}`);
    
    return {
      id: response.data.id,
      htmlLink: response.data.htmlLink,
      status: response.data.status,
      created: response.data.created,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    // Enhanced error logging
    console.error('Error creating calendar event:', error);
    
    // Log specific Google API errors if available
    if (error.response) {
      console.error('Google Calendar API error details:', {
        data: error.response.data,
        status: error.response.status,
        headers: error.response.headers
      });
    }
    
    // Return structured error object
    return { 
      error: 'Failed to create calendar event', 
      details: error.message,
      code: error.code || 'UNKNOWN_ERROR',
      timestamp: new Date().toISOString()
    };
  }
};