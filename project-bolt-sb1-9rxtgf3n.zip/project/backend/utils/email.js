import sgMail from '@sendgrid/mail';

/**
 * Send booking confirmation email to customer
 * @param {Object} bookingData - Booking information
 * @returns {Promise} - Promise resolving when email is sent
 */
export const sendBookingConfirmation = async (bookingData) => {
  try {
    // Set SendGrid API key from environment variables
    sgMail.setApiKey(process.env.SENDGRID_API_KEY);
    
    // Format the booking date for display
    const formattedDate = new Date(bookingData.bookingDateTime).toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      timeZoneName: 'short'
    });
    
    // Log the email preparation
    console.log(`Preparing email for ${bookingData.customerEmail} with appointment on ${formattedDate}`);
    
    // Create the email content with improved template
    const msg = {
      to: bookingData.customerEmail,
      from: process.env.EMAIL_FROM,
      subject: 'Your PPTV Mounting Appointment Confirmation',
      text: `Thank you for your booking, ${bookingData.customerName}! Your appointment is scheduled for ${formattedDate}. Services: ${bookingData.services.join(', ')}. ${bookingData.travelFee ? `Travel Fee: $${bookingData.travelFee}` : ''}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <h2 style="color: #2c5282; border-bottom: 1px solid #e0e0e0; padding-bottom: 10px;">PPTV Mounting Appointment Confirmation</h2>
          
          <p>Hello <strong>${bookingData.customerName}</strong>,</p>
          
          <p>Thank you for booking with PPTV! Your appointment details are confirmed as follows:</p>
          
          <div style="background-color: #f7fafc; padding: 15px; border-radius: 5px; margin: 15px 0;">
            <p><strong>Date & Time:</strong> ${formattedDate}</p>
            <p><strong>Services:</strong> ${bookingData.services.join(', ')}</p>
            ${bookingData.travelFee ? `<p><strong>Travel Fee:</strong> $${bookingData.travelFee.toFixed(2)}</p>` : ''}
          </div>
          
          <p>If you need to reschedule or have any questions about your appointment, please contact us as soon as possible.</p>
          
          <div style="margin-top: 20px; background-color: #ebf8ff; padding: 15px; border-radius: 5px;">
            <p style="margin: 0;"><strong>What to expect:</strong></p>
            <ul style="margin-top: 10px;">
              <li>Our technician will arrive within the scheduled time window</li>
              <li>Please ensure the installation area is accessible</li>
              <li>Have your TV and any additional equipment ready</li>
            </ul>
          </div>
          
          <p style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #e0e0e0; font-size: 14px; color: #718096;">
            Thank you for choosing PPTV for your mounting needs!
          </p>
        </div>
      `
    };
    
    // Send the email with detailed logging
    console.log(`Sending email via SendGrid to ${bookingData.customerEmail}`);
    const response = await sgMail.send(msg);
    
    // Log success with status code
    console.log(`Email sent successfully to ${bookingData.customerEmail}. Status code: ${response[0].statusCode}`);
    
    return {
      statusCode: response[0].statusCode,
      messageId: response[0].headers['x-message-id'],
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    // Enhanced error logging
    console.error('Error sending confirmation email:', error);
    
    // Log specific SendGrid API errors if available
    if (error.response) {
      console.error('SendGrid API error details:', {
        body: error.response.body,
        statusCode: error.response.statusCode,
        headers: error.response.headers
      });
    }
    
    // Return structured error object
    return { 
      error: 'Failed to send confirmation email', 
      details: error.message,
      code: error.code || 'UNKNOWN_ERROR',
      timestamp: new Date().toISOString()
    };
  }
};