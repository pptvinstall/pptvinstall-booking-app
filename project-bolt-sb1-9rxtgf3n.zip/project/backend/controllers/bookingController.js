import { sendBookingConfirmation } from '../utils/email.js';
import { createCalendarEvent } from '../utils/calendar.js';

// Store the last booking result for status endpoint
let lastBookingResult = null;

/**
 * Handle booking submission
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
export const submitBooking = async (req, res, next) => {
  try {
    // Extract booking data from request body
    const bookingData = req.body;
    
    // Log booking data to console
    console.log('Received booking:', JSON.stringify(bookingData, null, 2));
    
    // Validate booking data (enhanced validation)
    if (!bookingData.customerName || !bookingData.customerEmail || !bookingData.bookingDateTime) {
      return res.status(400).json({
        success: false,
        message: 'Missing required booking information',
        details: {
          customerName: !bookingData.customerName ? 'Customer name is required' : null,
          customerEmail: !bookingData.customerEmail ? 'Customer email is required' : null,
          bookingDateTime: !bookingData.bookingDateTime ? 'Booking date and time is required' : null
        }
      });
    }
    
    // Track integration results with detailed logging
    const integrationResults = {
      email: null,
      calendar: null,
      timestamp: new Date().toISOString()
    };
    
    // Send confirmation email with enhanced logging
    console.log(`[${new Date().toISOString()}] Attempting to send confirmation email to ${bookingData.customerEmail}...`);
    try {
      integrationResults.email = await sendBookingConfirmation(bookingData);
      if (integrationResults.email.error) {
        console.error(`[${new Date().toISOString()}] Email sending failed:`, integrationResults.email.error);
      } else {
        console.log(`[${new Date().toISOString()}] Email sent successfully to ${bookingData.customerEmail}`);
      }
    } catch (emailError) {
      console.error(`[${new Date().toISOString()}] Email integration error:`, emailError);
      integrationResults.email = { 
        error: emailError.message,
        stack: process.env.NODE_ENV === 'development' ? emailError.stack : undefined
      };
    }
    
    // Create calendar event with enhanced logging
    console.log(`[${new Date().toISOString()}] Attempting to create calendar event for ${bookingData.customerName} at ${bookingData.bookingDateTime}...`);
    try {
      integrationResults.calendar = await createCalendarEvent(bookingData);
      if (integrationResults.calendar.error) {
        console.error(`[${new Date().toISOString()}] Calendar event creation failed:`, integrationResults.calendar.error);
      } else {
        console.log(`[${new Date().toISOString()}] Calendar event created successfully: ${integrationResults.calendar.htmlLink || 'No link available'}`);
      }
    } catch (calendarError) {
      console.error(`[${new Date().toISOString()}] Calendar integration error:`, calendarError);
      integrationResults.calendar = { 
        error: calendarError.message,
        stack: process.env.NODE_ENV === 'development' ? calendarError.stack : undefined
      };
    }
    
    // Check for integration errors
    const hasEmailError = integrationResults.email && integrationResults.email.error;
    const hasCalendarError = integrationResults.calendar && integrationResults.calendar.error;
    
    // Create detailed integration status for response
    const integrationStatus = {
      email: {
        success: !hasEmailError,
        message: hasEmailError 
          ? `Failed to send email: ${integrationResults.email.error}` 
          : 'Email sent successfully',
        timestamp: new Date().toISOString()
      },
      calendar: {
        success: !hasCalendarError,
        message: hasCalendarError 
          ? `Failed to create calendar event: ${integrationResults.calendar.error}` 
          : 'Calendar event created successfully',
        eventLink: !hasCalendarError && integrationResults.calendar.htmlLink 
          ? integrationResults.calendar.htmlLink 
          : null,
        timestamp: new Date().toISOString()
      }
    };
    
    // Store the result for the status endpoint
    lastBookingResult = {
      bookingId: Date.now().toString(),
      customerName: bookingData.customerName,
      customerEmail: bookingData.customerEmail,
      bookingDateTime: bookingData.bookingDateTime,
      services: bookingData.services,
      travelFee: bookingData.travelFee,
      integrationStatus,
      timestamp: new Date().toISOString()
    };
    
    // Respond with success message and detailed integration results
    res.status(201).json({
      success: true,
      message: 'Booking received successfully',
      data: {
        bookingId: lastBookingResult.bookingId,
        ...bookingData
      },
      integrations: integrationStatus
    });
  } catch (error) {
    console.error(`[${new Date().toISOString()}] Unexpected error in booking submission:`, error);
    next(error);
  }
};

/**
 * Get the status of the last booking integration
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
export const getBookingStatus = (req, res) => {
  if (!lastBookingResult) {
    return res.status(404).json({
      success: false,
      message: 'No booking data available'
    });
  }
  
  res.status(200).json({
    success: true,
    data: lastBookingResult
  });
};

/**
 * Retry sending email for the last booking
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
export const retryEmailSending = async (req, res, next) => {
  try {
    if (!lastBookingResult) {
      return res.status(404).json({
        success: false,
        message: 'No booking data available to retry'
      });
    }
    
    // Extract booking data from the last booking
    const bookingId = lastBookingResult.bookingId;
    const bookingData = {
      customerName: lastBookingResult.customerName,
      customerEmail: req.body.customerEmail || lastBookingResult.customerEmail,
      bookingDateTime: lastBookingResult.bookingDateTime,
      services: req.body.services || lastBookingResult.services || [],
      travelFee: req.body.travelFee || lastBookingResult.travelFee || 0
    };
    
    console.log(`[${new Date().toISOString()}] Retrying email sending for booking ID: ${bookingId}`);
    
    // Attempt to send the email again
    const emailResult = await sendBookingConfirmation(bookingData);
    
    // Update the integration status
    if (emailResult.error) {
      console.error(`[${new Date().toISOString()}] Email retry failed:`, emailResult.error);
      lastBookingResult.integrationStatus.email = {
        success: false,
        message: `Failed to send email: ${emailResult.error}`,
        timestamp: new Date().toISOString()
      };
    } else {
      console.log(`[${new Date().toISOString()}] Email retry successful for ${bookingData.customerEmail}`);
      lastBookingResult.integrationStatus.email = {
        success: true,
        message: 'Email sent successfully',
        timestamp: new Date().toISOString()
      };
    }
    
    // Update the overall timestamp
    lastBookingResult.timestamp = new Date().toISOString();
    
    // Return the updated status
    res.status(200).json({
      success: !emailResult.error,
      message: emailResult.error ? 'Email retry failed' : 'Email retry successful',
      data: lastBookingResult
    });
  } catch (error) {
    console.error(`[${new Date().toISOString()}] Error in email retry:`, error);
    next(error);
  }
};

/**
 * Retry creating calendar event for the last booking
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 */
export const retryCalendarEvent = async (req, res, next) => {
  try {
    if (!lastBookingResult) {
      return res.status(404).json({
        success: false,
        message: 'No booking data available to retry'
      });
    }
    
    // Extract booking data from the last booking
    const bookingId = lastBookingResult.bookingId;
    const bookingData = {
      customerName: lastBookingResult.customerName,
      customerEmail: req.body.customerEmail || lastBookingResult.customerEmail,
      bookingDateTime: req.body.bookingDateTime || lastBookingResult.bookingDateTime,
      services: req.body.services || lastBookingResult.services || [],
      travelFee: req.body.travelFee || lastBookingResult.travelFee || 0
    };
    
    console.log(`[${new Date().toISOString()}] Retrying calendar event creation for booking ID: ${bookingId}`);
    
    // Attempt to create the calendar event again
    const calendarResult = await createCalendarEvent(bookingData);
    
    // Update the integration status
    if (calendarResult.error) {
      console.error(`[${new Date().toISOString()}] Calendar event retry failed:`, calendarResult.error);
      lastBookingResult.integrationStatus.calendar = {
        success: false,
        message: `Failed to create calendar event: ${calendarResult.error}`,
        timestamp: new Date().toISOString()
      };
    } else {
      console.log(`[${new Date().toISOString()}] Calendar event retry successful: ${calendarResult.htmlLink || 'No link available'}`);
      lastBookingResult.integrationStatus.calendar = {
        success: true,
        message: 'Calendar event created successfully',
        eventLink: calendarResult.htmlLink,
        timestamp: new Date().toISOString()
      };
    }
    
    // Update the overall timestamp
    lastBookingResult.timestamp = new Date().toISOString();
    
    // Return the updated status
    res.status(200).json({
      success: !calendarResult.error,
      message: calendarResult.error ? 'Calendar event retry failed' : 'Calendar event retry successful',
      data: lastBookingResult
    });
  } catch (error) {
    console.error(`[${new Date().toISOString()}] Error in calendar event retry:`, error);
    next(error);
  }
};