import express from 'express';
import { 
  submitBooking, 
  getBookingStatus, 
  retryEmailSending, 
  retryCalendarEvent 
} from '../controllers/bookingController.js';

const router = express.Router();

/**
 * @route POST /api/booking/submit
 * @desc Submit a new booking
 * @access Public
 */
router.post('/submit', submitBooking);

/**
 * @route GET /api/booking/status
 * @desc Get the status of the last booking integration
 * @access Public
 */
router.get('/status', getBookingStatus);

/**
 * @route POST /api/booking/retry-email
 * @desc Retry sending email for the last booking
 * @access Public
 */
router.post('/retry-email', retryEmailSending);

/**
 * @route POST /api/booking/retry-calendar
 * @desc Retry creating calendar event for the last booking
 * @access Public
 */
router.post('/retry-calendar', retryCalendarEvent);

export default router;