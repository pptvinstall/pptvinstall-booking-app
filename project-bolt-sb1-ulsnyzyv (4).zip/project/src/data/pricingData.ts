import { Tv, Flame, Cable, Truck, Tag, DollarSign } from 'lucide-react';

export interface PricingItem {
  id: string;
  title: string;
  description: string;
  price: string;
  priceNote?: string;
  category: 'service' | 'addon' | 'discount' | 'other';
  icon: any;
  iconBgColor: string;
  iconColor: string;
  borderColor: string;
  features: string[];
}

export interface DiscountItem {
  id: string;
  title: string;
  description: string;
  details: string;
}

export const pricingData: PricingItem[] = [
  {
    id: 'basic-mounting',
    title: 'Basic TV Mounting',
    description: 'Standard installation on drywall with customer-provided mount',
    price: '$100',
    priceNote: 'Per TV',
    category: 'service',
    icon: Tv,
    iconBgColor: 'bg-blue-100',
    iconColor: 'text-blue-600',
    borderColor: 'border-blue-500',
    features: [
      'Professional installation',
      'Level mounting',
      'Basic cable management'
    ]
  },
  {
    id: 'fireplace-mounting',
    title: 'Over Fireplace Installation',
    description: 'Specialized mounting above fireplaces',
    price: '+$100',
    priceNote: 'Additional',
    category: 'addon',
    icon: Flame,
    iconBgColor: 'bg-orange-100',
    iconColor: 'text-orange-600',
    borderColor: 'border-orange-500',
    features: [
      'Heat-resistant installation',
      'Special mounting hardware',
      'Optimal viewing angle'
    ]
  },
  {
    id: 'wire-concealment',
    title: 'Wire Concealment & Outlet',
    description: 'Clean, professional wire management and power solutions',
    price: '$100+',
    priceNote: 'Starting price',
    category: 'addon',
    icon: Cable,
    iconBgColor: 'bg-purple-100',
    iconColor: 'text-purple-600',
    borderColor: 'border-purple-500',
    features: [
      'In-wall cable routing',
      'Power outlet installation',
      'Clean, professional finish'
    ]
  },
  {
    id: 'travel-fee',
    title: 'Travel Fee',
    description: 'Service area coverage and travel expenses',
    price: 'TBD',
    priceNote: 'Based on location',
    category: 'other',
    icon: Truck,
    iconBgColor: 'bg-gray-100',
    iconColor: 'text-gray-600',
    borderColor: 'border-gray-500',
    features: [
      'Determined by distance',
      'Contact for quote'
    ]
  }
];

export const discountData: DiscountItem[] = [
  {
    id: 'labor-discount',
    title: 'Labor Discount',
    description: '$10 off per additional service booked',
    details: 'Book multiple services and save on each additional service'
  },
  {
    id: 'mount-discount',
    title: 'Mount Discount',
    description: '$5 off per additional mount purchased',
    details: 'Save when purchasing multiple mounts for your installation'
  }
];