import React, { useState } from 'react';
import { Tag, Check, Tv, Flame, Cable, Volume2, Lightbulb, Video, DollarSign, ArrowRight } from 'lucide-react';

// Define service types
interface ServiceOption {
  id: string;
  title: string;
  description: string;
  price: number | string;
  priceDisplay: string;
  priceNote?: string;
  category: 'mounting' | 'addon' | 'smart-home' | 'mount';
  icon: React.ElementType;
  iconBgColor: string;
  iconColor: string;
  borderColor: string;
  features: string[];
  options?: {
    id: string;
    name: string;
    price: number;
    priceDisplay: string;
  }[];
}

interface DiscountItem {
  id: string;
  title: string;
  description: string;
  details: string;
}

// Define props for the component
interface PricingPageProps {
  onServiceSelect?: (service: ServiceOption, option?: string) => void;
  selectedServices?: string[];
}

function PricingPage({ onServiceSelect, selectedServices = [] }: PricingPageProps) {
  // Local state for selected services if not provided via props
  const [localSelectedServices, setLocalSelectedServices] = useState<string[]>([]);
  
  // Use either provided selectedServices or local state
  const selected = selectedServices.length > 0 ? selectedServices : localSelectedServices;
  
  // Handle service selection
  const handleServiceSelect = (service: ServiceOption, optionId?: string) => {
    // If onServiceSelect prop is provided, use it
    if (onServiceSelect) {
      onServiceSelect(service, optionId);
    } else {
      // Otherwise, manage selection locally
      setLocalSelectedServices(prev => {
        const serviceId = optionId ? `${service.id}-${optionId}` : service.id;
        if (prev.includes(serviceId)) {
          return prev.filter(id => id !== serviceId);
        } else {
          return [...prev, serviceId];
        }
      });
    }
    
    // Log selection for demonstration
    console.log(`Selected service: ${service.title}${optionId ? ` (${optionId})` : ''}`);
  };
  
  // Check if a service is selected
  const isServiceSelected = (service: ServiceOption, optionId?: string) => {
    const serviceId = optionId ? `${service.id}-${optionId}` : service.id;
    return selected.includes(serviceId);
  };
  
  // All available services
  const services: ServiceOption[] = [
    {
      id: 'basic-mounting',
      title: 'Basic TV Mounting',
      description: 'Standard installation on drywall with customer-provided mount',
      price: 100,
      priceDisplay: '$100',
      priceNote: 'Per TV',
      category: 'mounting',
      icon: Tv,
      iconBgColor: 'bg-blue-100',
      iconColor: 'text-blue-600',
      borderColor: 'border-blue-500',
      features: [
        'Professional installation',
        'Level mounting',
        'Basic cable management',
        'Hardware included'
      ]
    },
    {
      id: 'fireplace-mounting',
      title: 'Fireplace Mounting',
      description: 'Specialized mounting above fireplaces',
      price: 'varies',
      priceDisplay: 'From $200',
      category: 'mounting',
      icon: Flame,
      iconBgColor: 'bg-orange-100',
      iconColor: 'text-orange-600',
      borderColor: 'border-orange-500',
      features: [
        'Heat-resistant installation',
        'Special mounting hardware',
        'Optimal viewing angle'
      ],
      options: [
        {
          id: 'drywall',
          name: 'Drywall Fireplace',
          price: 200,
          priceDisplay: '$200'
        },
        {
          id: 'brick',
          name: 'Brick/Stone Fireplace',
          price: 250,
          priceDisplay: '$250'
        }
      ]
    },
    {
      id: 'tv-mounts',
      title: 'TV Mounts',
      description: 'High-quality mounts for any TV size',
      price: 'varies',
      priceDisplay: 'From $40',
      category: 'mount',
      icon: Tv,
      iconBgColor: 'bg-green-100',
      iconColor: 'text-green-600',
      borderColor: 'border-green-500',
      features: [
        'Various sizes available',
        'Full-motion options',
        'Weight-rated for safety',
        'Installation included with TV mounting'
      ],
      options: [
        {
          id: 'small',
          name: 'Small Mount (32"-50")',
          price: 40,
          priceDisplay: '$40'
        },
        {
          id: 'medium',
          name: 'Medium Mount (51"-65")',
          price: 50,
          priceDisplay: '$50'
        },
        {
          id: 'large',
          name: 'Large Mount (66"-85")',
          price: 65,
          priceDisplay: '$65'
        },
        {
          id: 'fullMotion',
          name: 'Full-Motion Mount (Any size)',
          price: 80,
          priceDisplay: '$80'
        }
      ]
    },
    {
      id: 'wire-concealment',
      title: 'Wire Concealment & Outlet',
      description: 'Clean, professional wire management and power solutions',
      price: 100,
      priceDisplay: '$100',
      priceNote: 'Per location',
      category: 'addon',
      icon: Cable,
      iconBgColor: 'bg-purple-100',
      iconColor: 'text-purple-600',
      borderColor: 'border-purple-500',
      features: [
        'In-wall cable routing',
        'Power outlet installation',
        'Clean, professional finish',
        'Works with any mounted TV'
      ]
    },
    {
      id: 'soundbar-installation',
      title: 'Soundbar Installation',
      description: 'Professional soundbar mounting and setup',
      price: 50,
      priceDisplay: '$50',
      priceNote: 'Per soundbar',
      category: 'addon',
      icon: Volume2,
      iconBgColor: 'bg-indigo-100',
      iconColor: 'text-indigo-600',
      borderColor: 'border-indigo-500',
      features: [
        'Secure mounting',
        'Cable management',
        'Basic audio setup',
        'Mount included with customer-provided soundbar'
      ]
    },
    {
      id: 'smart-floodlight',
      title: 'Smart Floodlight Installation',
      description: 'Professional installation of smart floodlights',
      price: 125,
      priceDisplay: '$125',
      priceNote: 'Per floodlight',
      category: 'smart-home',
      icon: Lightbulb,
      iconBgColor: 'bg-yellow-100',
      iconColor: 'text-yellow-600',
      borderColor: 'border-yellow-500',
      features: [
        'Secure mounting',
        'Wiring installation',
        'App setup assistance',
        'Works with existing wiring or wireless options'
      ]
    },
    {
      id: 'smart-doorbell',
      title: 'Smart Video Doorbell',
      description: 'Professional installation of video doorbells',
      price: 85,
      priceDisplay: '$85',
      priceNote: 'Per doorbell',
      category: 'smart-home',
      icon: Video,
      iconBgColor: 'bg-red-100',
      iconColor: 'text-red-600',
      borderColor: 'border-red-500',
      features: [
        'Secure mounting',
        'Wiring setup',
        'App configuration',
        'Testing and demonstration'
      ]
    }
  ];
  
  // Discount data
  const discountData: DiscountItem[] = [
    {
      id: 'labor-discount',
      title: 'Labor Discount',
      description: '$10 off per additional service booked',
      details: 'Book multiple services and save on each additional service'
    },
    {
      id: 'mount-discount',
      title: 'Mount Discount',
      description: '$5 off per additional mount purchased',
      details: 'Save when purchasing multiple mounts for your installation'
    }
  ];
  
  // Group services by category
  const mountingServices = services.filter(s => s.category === 'mounting');
  const mountServices = services.filter(s => s.category === 'mount');
  const addonServices = services.filter(s => s.category === 'addon');
  const smartHomeServices = services.filter(s => s.category === 'smart-home');

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Our Services & Pricing</h1>
        <p className="text-gray-600">Select services to add to your booking or get a custom quote</p>
      </div>
      
      {/* TV Mounting Services */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
          <Tv size={24} className="mr-2 text-blue-600" />
          TV Mounting Services
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          {mountingServices.map((service) => (
            <div 
              key={service.id}
              className={`bg-white p-6 rounded-lg shadow-md border-t-4 ${service.borderColor} transition-all duration-300 hover:shadow-lg`}
            >
              <div className="flex items-center mb-4">
                <div className={`${service.iconBgColor} p-3 rounded-full mr-4`}>
                  <service.icon className={service.iconColor} size={24} />
                </div>
                <h3 className="text-xl font-bold text-gray-800">{service.title}</h3>
              </div>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <div className="flex items-center justify-between mb-4">
                <span className={`text-2xl font-bold ${service.iconColor}`}>{service.priceDisplay}</span>
                {service.priceNote && <span className="text-sm text-gray-500">{service.priceNote}</span>}
              </div>
              
              <ul className="mt-4 mb-6 space-y-2 text-sm text-gray-600">
                {service.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              
              {/* Options if available */}
              {service.options ? (
                <div className="space-y-2 mb-6">
                  {service.options.map(option => (
                    <button
                      key={option.id}
                      onClick={() => handleServiceSelect(service, option.id)}
                      className={`w-full py-2 px-4 rounded-md text-left flex justify-between items-center transition-colors duration-200 ${
                        isServiceSelected(service, option.id)
                          ? `${service.iconBgColor} ${service.iconColor} font-medium border border-current`
                          : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                      }`}
                    >
                      <span>{option.name}</span>
                      <div className="flex items-center">
                        <span className="font-medium">{option.priceDisplay}</span>
                        {isServiceSelected(service, option.id) && (
                          <Check size={18} className="ml-2" />
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                <button
                  onClick={() => handleServiceSelect(service)}
                  className={`w-full py-2 px-4 rounded-md text-center font-medium transition-colors duration-200 ${
                    isServiceSelected(service)
                      ? `${service.iconBgColor} ${service.iconColor} border border-current`
                      : `bg-${service.iconColor.split('-')[1]}-500 hover:bg-${service.iconColor.split('-')[1]}-600 text-white`
                  }`}
                >
                  {isServiceSelected(service) ? (
                    <span className="flex items-center justify-center">
                      <Check size={18} className="mr-2" />
                      Added to Booking
                    </span>
                  ) : (
                    'Add to Booking'
                  )}
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
      
      {/* TV Mounts */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
          <DollarSign size={24} className="mr-2 text-green-600" />
          TV Mounts
        </h2>
        <div className="grid md:grid-cols-1 gap-6">
          {mountServices.map((service) => (
            <div 
              key={service.id}
              className={`bg-white p-6 rounded-lg shadow-md border-t-4 ${service.borderColor} transition-all duration-300 hover:shadow-lg`}
            >
              <div className="flex items-center mb-4">
                <div className={`${service.iconBgColor} p-3 rounded-full mr-4`}>
                  <service.icon className={service.iconColor} size={24} />
                </div>
                <h3 className="text-xl font-bold text-gray-800">{service.title}</h3>
              </div>
              <p className="text-gray-600 mb-4">{service.description}</p>
              
              <ul className="mt-4 mb-6 space-y-2 text-sm text-gray-600">
                {service.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {service.options?.map(option => (
                  <button
                    key={option.id}
                    onClick={() => handleServiceSelect(service, option.id)}
                    className={`py-2 px-4 rounded-md text-left flex justify-between items-center transition-colors duration-200 ${
                      isServiceSelected(service, option.id)
                        ? `${service.iconBgColor} ${service.iconColor} font-medium border border-current`
                        : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                    }`}
                  >
                    <span>{option.name}</span>
                    <div className="flex items-center">
                      <span className="font-medium">{option.priceDisplay}</span>
                      {isServiceSelected(service, option.id) && (
                        <Check size={18} className="ml-2" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Add-on Services */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
          <Cable size={24} className="mr-2 text-purple-600" />
          Add-on Services
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          {addonServices.map((service) => (
            <div 
              key={service.id}
              className={`bg-white p-6 rounded-lg shadow-md border-t-4 ${service.borderColor} transition-all duration-300 hover:shadow-lg`}
            >
              <div className="flex items-center mb-4">
                <div className={`${service.iconBgColor} p-3 rounded-full mr-4`}>
                  <service.icon className={service.iconColor} size={24} />
                </div>
                <h3 className="text-xl font-bold text-gray-800">{service.title}</h3>
              </div>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <div className="flex items-center justify-between mb-4">
                <span className={`text-2xl font-bold ${service.iconColor}`}>{service.priceDisplay}</span>
                {service.priceNote && <span className="text-sm text-gray-500">{service.priceNote}</span>}
              </div>
              
              <ul className="mt-4 mb-6 space-y-2 text-sm text-gray-600">
                {service.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              
              <button
                onClick={() => handleServiceSelect(service)}
                className={`w-full py-2 px-4 rounded-md text-center font-medium transition-colors duration-200 ${
                  isServiceSelected(service)
                    ? `${service.iconBgColor} ${service.iconColor} border border-current`
                    : `bg-${service.iconColor.split('-')[1]}-500 hover:bg-${service.iconColor.split('-')[1]}-600 text-white`
                }`}
              >
                {isServiceSelected(service) ? (
                  <span className="flex items-center justify-center">
                    <Check size={18} className="mr-2" />
                    Added to Booking
                  </span>
                ) : (
                  'Add to Booking'
                )}
              </button>
            </div>
          ))}
        </div>
      </div>
      
      {/* Smart Home Services */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
          <Lightbulb size={24} className="mr-2 text-yellow-600" />
          Smart Home Services
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          {smartHomeServices.map((service) => (
            <div 
              key={service.id}
              className={`bg-white p-6 rounded-lg shadow-md border-t-4 ${service.borderColor} transition-all duration-300 hover:shadow-lg`}
            >
              <div className="flex items-center mb-4">
                <div className={`${service.iconBgColor} p-3 rounded-full mr-4`}>
                  <service.icon className={service.iconColor} size={24} />
                </div>
                <h3 className="text-xl font-bold text-gray-800">{service.title}</h3>
              </div>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <div className="flex items-center justify-between mb-4">
                <span className={`text-2xl font-bold ${service.iconColor}`}>{service.priceDisplay}</span>
                {service.priceNote && <span className="text-sm text-gray-500">{service.priceNote}</span>}
              </div>
              
              <ul className="mt-4 mb-6 space-y-2 text-sm text-gray-600">
                {service.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-green-500 mr-2">✓</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              
              <button
                onClick={() => handleServiceSelect(service)}
                className={`w-full py-2 px-4 rounded-md text-center font-medium transition-colors duration-200 ${
                  isServiceSelected(service)
                    ? `${service.iconBgColor} ${service.iconColor} border border-current`
                    : `bg-${service.iconColor.split('-')[1]}-500 hover:bg-${service.iconColor.split('-')[1]}-600 text-white`
                }`}
              >
                {isServiceSelected(service) ? (
                  <span className="flex items-center justify-center">
                    <Check size={18} className="mr-2" />
                    Added to Booking
                  </span>
                ) : (
                  'Add to Booking'
                )}
              </button>
            </div>
          ))}
        </div>
      </div>
      
      {/* Discounts Section */}
      <div className="mt-10 bg-white p-6 rounded-lg shadow-md border-t-4 border-green-500">
        <div className="flex items-center mb-4">
          <div className="bg-green-100 p-3 rounded-full mr-4">
            <Tag className="text-green-600" size={24} />
          </div>
          <h2 className="text-xl font-bold text-gray-800">Available Discounts</h2>
        </div>
        
        <div className="grid md:grid-cols-2 gap-4 mt-4">
          {discountData.map((discount) => (
            <div key={discount.id} className="border border-gray-200 rounded-lg p-4">
              <h3 className="font-bold text-gray-800 mb-2">{discount.title}</h3>
              <p className="text-gray-600 mb-2">{discount.description}</p>
              <div className="text-sm text-gray-500">
                {discount.details}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Call to Action */}
      <div className="mt-10 text-center">
        <p className="text-gray-600 mb-4">Ready to get your TV professionally mounted?</p>
        <button 
          onClick={() => window.location.href = '#booking'}
          className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-8 rounded-md transition-colors duration-300 flex items-center mx-auto"
        >
          Proceed to Booking
          <ArrowRight size={18} className="ml-2" />
        </button>
      </div>
    </div>
  );
}

export default PricingPage;