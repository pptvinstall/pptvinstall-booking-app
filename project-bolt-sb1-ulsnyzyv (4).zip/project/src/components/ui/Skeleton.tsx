import React from 'react';
import clsx from 'clsx';

interface SkeletonProps {
  className?: string;
  width?: string | number;
  height?: string | number;
  circle?: boolean;
  animate?: boolean;
}

const Skeleton: React.FC<SkeletonProps> = ({
  className,
  width,
  height,
  circle = false,
  animate = true,
}) => {
  return (
    <div
      className={clsx(
        'bg-gray-200',
        animate && 'animate-pulse',
        circle && 'rounded-full',
        !circle && 'rounded',
        className
      )}
      style={{
        width: width,
        height: height,
      }}
    />
  );
};

export const SkeletonText: React.FC<{ lines?: number; className?: string }> = ({
  lines = 3,
  className,
}) => {
  return (
    <div className={clsx('space-y-2', className)}>
      {Array.from({ length: lines }).map((_, i) => (
        <Skeleton
          key={i}
          className={clsx(i === lines - 1 && 'max-w-[70%]')}
          height={16}
        />
      ))}
    </div>
  );
};

export const SkeletonCard: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <div className={clsx('border border-gray-200 rounded-lg p-4 space-y-4', className)}>
      <Skeleton height={24} className="max-w-[50%]" />
      <SkeletonText lines={2} />
      <div className="flex justify-between">
        <Skeleton width={80} height={32} />
        <Skeleton width={100} height={32} />
      </div>
    </div>
  );
};

export default Skeleton;