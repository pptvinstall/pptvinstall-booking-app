import React from 'react';
import clsx from 'clsx';

interface RadioOption {
  value: string;
  label: string;
  description?: string;
  disabled?: boolean;
}

interface RadioGroupProps {
  name: string;
  options: RadioOption[];
  value?: string;
  onChange?: (value: string) => void;
  label?: string;
  error?: string;
  helperText?: string;
  className?: string;
  horizontal?: boolean;
  isRequired?: boolean;
}

const RadioGroup: React.FC<RadioGroupProps> = ({
  name,
  options,
  value,
  onChange,
  label,
  error,
  helperText,
  className,
  horizontal = false,
  isRequired = false,
}) => {
  const groupId = `radio-group-${Math.random().toString(36).substring(2, 9)}`;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (onChange) {
      onChange(e.target.value);
    }
  };

  return (
    <div className={className}>
      {label && (
        <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center">
          {label}
          {isRequired && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      <div
        role="radiogroup"
        aria-labelledby={label ? groupId : undefined}
        className={clsx(
          horizontal ? 'flex flex-wrap gap-4' : 'space-y-2',
          error && 'text-red-900'
        )}
      >
        {options.map((option) => (
          <div key={option.value} className={clsx('flex items-start', horizontal && 'mr-4')}>
            <div className="flex items-center h-5">
              <input
                id={`${name}-${option.value}`}
                name={name}
                type="radio"
                value={option.value}
                checked={value === option.value}
                disabled={option.disabled}
                onChange={handleChange}
                className={clsx(
                  'h-4 w-4 border-gray-300 text-brand-600 focus:ring-brand-500',
                  error && 'border-red-300'
                )}
              />
            </div>
            <div className="ml-3 text-sm">
              <label
                htmlFor={`${name}-${option.value}`}
                className={clsx(
                  'font-medium',
                  option.disabled ? 'text-gray-400' : 'text-gray-700'
                )}
              >
                {option.label}
              </label>
              {option.description && (
                <p className={clsx('text-gray-500', option.disabled && 'text-gray-400')}>
                  {option.description}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
      {error && <p className="mt-1 text-sm text-red-600">{error}</p>}
      {helperText && !error && <p className="mt-1 text-sm text-gray-500">{helperText}</p>}
    </div>
  );
};

export default RadioGroup;