import React, { useState } from 'react';
import clsx from 'clsx';

interface Tab {
  id: string;
  label: string;
  content: React.ReactNode;
  disabled?: boolean;
}

interface TabsProps {
  tabs: Tab[];
  defaultTab?: string;
  onChange?: (tabId: string) => void;
  variant?: 'underline' | 'pills' | 'enclosed';
  className?: string;
}

const Tabs: React.FC<TabsProps> = ({
  tabs,
  defaultTab,
  onChange,
  variant = 'underline',
  className,
}) => {
  const [activeTab, setActiveTab] = useState(defaultTab || tabs[0]?.id);

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    if (onChange) {
      onChange(tabId);
    }
  };

  const variantStyles = {
    underline: {
      container: 'border-b border-gray-200',
      tab: 'py-2 px-4 text-sm font-medium',
      active: 'text-brand-600 border-b-2 border-brand-500',
      inactive: 'text-gray-500 hover:text-gray-700 hover:border-gray-300 border-b-2 border-transparent',
    },
    pills: {
      container: 'flex space-x-1',
      tab: 'py-2 px-4 text-sm font-medium rounded-md',
      active: 'bg-brand-100 text-brand-700',
      inactive: 'text-gray-500 hover:text-gray-700 hover:bg-gray-100',
    },
    enclosed: {
      container: 'flex',
      tab: 'py-2 px-4 text-sm font-medium first:rounded-l-md last:rounded-r-md border-y border-r first:border-l',
      active: 'bg-white text-brand-700 border-gray-200',
      inactive: 'bg-gray-50 text-gray-500 hover:text-gray-700 border-gray-200',
    },
  };

  return (
    <div className={className}>
      <div className={clsx('flex', variantStyles[variant].container)}>
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => !tab.disabled && handleTabChange(tab.id)}
            className={clsx(
              variantStyles[variant].tab,
              activeTab === tab.id
                ? variantStyles[variant].active
                : variantStyles[variant].inactive,
              tab.disabled && 'opacity-50 cursor-not-allowed'
            )}
            disabled={tab.disabled}
            aria-selected={activeTab === tab.id}
            role="tab"
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div className="mt-4">
        {tabs.find((tab) => tab.id === activeTab)?.content}
      </div>
    </div>
  );
};

export default Tabs;