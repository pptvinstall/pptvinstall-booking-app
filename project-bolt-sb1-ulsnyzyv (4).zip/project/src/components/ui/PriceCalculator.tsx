import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DollarSign, ChevronDown, ChevronUp, Info, Tag, AlertCircle } from 'lucide-react';
import Card, { CardBody } from './Card';
import Badge from './Badge';

export interface PriceItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  category?: string;
  isDiscount?: boolean;
}

interface PriceCalculatorProps {
  items: PriceItem[];
  travelFee?: number;
  tax?: number;
  taxRate?: number;
  discounts?: PriceItem[];
  className?: string;
  showDetails?: boolean;
  isSticky?: boolean;
}

const PriceCalculator: React.FC<PriceCalculatorProps> = ({
  items,
  travelFee = 0,
  tax = 0,
  taxRate = 0,
  discounts = [],
  className = '',
  showDetails = false,
  isSticky = false,
}) => {
  const [isExpanded, setIsExpanded] = useState(showDetails);

  // Calculate subtotal (before tax and travel fee)
  const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  // Calculate discount total
  const discountTotal = discounts.reduce((sum, discount) => sum + discount.price, 0);
  
  // Calculate total
  const total = subtotal - discountTotal + travelFee + tax;

  // Group items by category
  const groupedItems: Record<string, PriceItem[]> = {};
  items.forEach(item => {
    const category = item.category || 'Other';
    if (!groupedItems[category]) {
      groupedItems[category] = [];
    }
    groupedItems[category].push(item);
  });

  return (
    <Card 
      elevated 
      className={`${className} ${isSticky ? 'sticky top-20' : ''}`}
    >
      <CardBody className="p-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-lg font-bold text-gray-800 flex items-center">
            <DollarSign className="mr-1 text-brand-600" size={20} />
            Estimated Total
          </h3>
          <span className="text-2xl font-bold text-brand-600">${total.toFixed(2)}</span>
        </div>
        
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center justify-between w-full text-sm text-gray-600 hover:text-gray-800 transition-colors py-1"
        >
          <span className="flex items-center">
            <Info size={14} className="mr-1" />
            {isExpanded ? 'Hide details' : 'Show price breakdown'}
          </span>
          {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
        
        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="mt-3 pt-3 border-t border-gray-200"
            >
              {/* Items by category */}
              {Object.entries(groupedItems).map(([category, categoryItems]) => (
                <div key={category} className="mb-3">
                  <h4 className="text-xs font-medium text-gray-500 mb-1">{category}</h4>
                  {categoryItems.map((item) => (
                    <div key={item.id} className="flex justify-between items-center mb-1 text-sm">
                      <div className="flex items-center">
                        <span className="text-gray-800">
                          {item.name}
                          {item.quantity > 1 && (
                            <span className="text-gray-500 ml-1">
                              (x{item.quantity})
                            </span>
                          )}
                        </span>
                      </div>
                      <span className="text-gray-800">
                        ${(item.price * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              ))}
              
              {/* Subtotal */}
              <div className="flex justify-between items-center py-1 text-sm border-t border-gray-200">
                <span className="text-gray-600">Subtotal</span>
                <span className="text-gray-800">${subtotal.toFixed(2)}</span>
              </div>
              
              {/* Discounts */}
              {discounts.length > 0 && (
                <>
                  {discounts.map((discount) => (
                    <div key={discount.id} className="flex justify-between items-center py-1 text-sm">
                      <span className="text-green-600 flex items-center">
                        <Tag size={14} className="mr-1" />
                        {discount.name}
                      </span>
                      <span className="text-green-600">-${Math.abs(discount.price).toFixed(2)}</span>
                    </div>
                  ))}
                </>
              )}
              
              {/* Travel Fee */}
              {travelFee > 0 && (
                <div className="flex justify-between items-center py-1 text-sm">
                  <span className="text-gray-600">Travel Fee</span>
                  <span className="text-gray-800">${travelFee.toFixed(2)}</span>
                </div>
              )}
              
              {/* Tax */}
              {tax > 0 && (
                <div className="flex justify-between items-center py-1 text-sm">
                  <span className="text-gray-600">
                    Tax {taxRate > 0 && `(${(taxRate * 100).toFixed(1)}%)`}
                  </span>
                  <span className="text-gray-800">${tax.toFixed(2)}</span>
                </div>
              )}
              
              {/* Total */}
              <div className="flex justify-between items-center pt-2 mt-1 border-t border-gray-200 font-medium">
                <span className="text-gray-800">Total</span>
                <span className="text-brand-600 text-lg">${total.toFixed(2)}</span>
              </div>
              
              {/* Notes */}
              <div className="mt-3 text-xs text-gray-500">
                <p className="flex items-start">
                  <Info size={12} className="mr-1 mt-0.5 flex-shrink-0" />
                  Final price may vary based on additional services requested during installation.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Promotional Badge */}
        {discounts.length > 0 && (
          <div className="mt-3">
            <Badge variant="success" size="sm" className="w-full flex justify-center py-1">
              <Tag size={14} className="mr-1" /> 
              Savings Applied: ${Math.abs(discountTotal).toFixed(2)}
            </Badge>
          </div>
        )}
      </CardBody>
    </Card>
  );
};

export default PriceCalculator;