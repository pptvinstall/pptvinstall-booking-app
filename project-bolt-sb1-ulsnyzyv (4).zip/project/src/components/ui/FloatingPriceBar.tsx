import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DollarSign, ChevronUp, ShoppingCart } from 'lucide-react';
import Button from './Button';
import { PriceItem } from './PriceCalculator';

interface FloatingPriceBarProps {
  items: PriceItem[];
  travelFee?: number;
  tax?: number;
  discounts?: PriceItem[];
  isVisible: boolean;
  onDetailsClick: () => void;
  onContinueClick?: () => void;
  continueText?: string;
}

const FloatingPriceBar: React.FC<FloatingPriceBarProps> = ({
  items,
  travelFee = 0,
  tax = 0,
  discounts = [],
  isVisible,
  onDetailsClick,
  onContinueClick,
  continueText = 'Continue'
}) => {
  // Calculate subtotal
  const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  // Calculate discount total
  const discountTotal = discounts.reduce((sum, discount) => sum + discount.price, 0);
  
  // Calculate total
  const total = subtotal - discountTotal + travelFee + tax;
  
  // Count items
  const itemCount = items.reduce((count, item) => count + item.quantity, 0);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50"
        >
          <div className="container mx-auto px-4 py-3">
            <div className="flex justify-between items-center">
              <div className="flex flex-col">
                <div className="flex items-center">
                  <ShoppingCart size={16} className="text-gray-600 mr-2" />
                  <span className="text-sm text-gray-600">{itemCount} {itemCount === 1 ? 'service' : 'services'}</span>
                </div>
                <div className="flex items-center">
                  <DollarSign size={18} className="text-brand-600" />
                  <span className="text-xl font-bold text-brand-600">${total.toFixed(2)}</span>
                  <button 
                    onClick={onDetailsClick}
                    className="ml-2 text-xs text-gray-500 flex items-center hover:text-gray-700"
                  >
                    Details <ChevronUp size={14} className="ml-1" />
                  </button>
                </div>
              </div>
              
              {onContinueClick && (
                <Button
                  variant="primary"
                  onClick={onContinueClick}
                >
                  {continueText}
                </Button>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default FloatingPriceBar;