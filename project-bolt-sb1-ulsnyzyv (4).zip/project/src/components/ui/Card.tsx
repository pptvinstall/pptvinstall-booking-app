import React from 'react';
import clsx from 'clsx';

interface CardProps {
  className?: string;
  children: React.ReactNode;
  bordered?: boolean;
  elevated?: boolean;
  hoverEffect?: boolean;
  topBorder?: boolean;
  topBorderColor?: string;
}

const Card: React.FC<CardProps> = ({
  className,
  children,
  bordered = false,
  elevated = false,
  hoverEffect = false,
  topBorder = false,
  topBorderColor = 'border-brand-500',
}) => {
  return (
    <div
      className={clsx(
        'bg-white rounded-lg overflow-hidden',
        bordered && 'border border-gray-200',
        elevated && 'shadow-elevation-3',
        hoverEffect && 'transition-all duration-200 hover:shadow-elevation-4',
        topBorder && `border-t-4 ${topBorderColor}`,
        className
      )}
    >
      {children}
    </div>
  );
};

export const CardHeader: React.FC<{ className?: string; children: React.ReactNode }> = ({
  className,
  children,
}) => {
  return <div className={clsx('px-6 py-4 border-b border-gray-200', className)}>{children}</div>;
};

export const CardBody: React.FC<{ className?: string; children: React.ReactNode }> = ({
  className,
  children,
}) => {
  return <div className={clsx('px-6 py-4', className)}>{children}</div>;
};

export const CardFooter: React.FC<{ className?: string; children: React.ReactNode }> = ({
  className,
  children,
}) => {
  return <div className={clsx('px-6 py-4 border-t border-gray-200', className)}>{children}</div>;
};

export default Card;