import React from 'react';
import clsx from 'clsx';
import { Check } from 'lucide-react';

interface Step {
  id: string;
  label: string;
  description?: string;
}

interface StepperProps {
  steps: Step[];
  currentStep: string;
  className?: string;
  orientation?: 'horizontal' | 'vertical';
}

const Stepper: React.FC<StepperProps> = ({
  steps,
  currentStep,
  className,
  orientation = 'horizontal',
}) => {
  const currentStepIndex = steps.findIndex((step) => step.id === currentStep);

  return (
    <div
      className={clsx(
        orientation === 'horizontal' ? 'flex items-center' : 'flex flex-col space-y-4',
        className
      )}
    >
      {steps.map((step, index) => {
        const isCompleted = index < currentStepIndex;
        const isCurrent = index === currentStepIndex;
        const isUpcoming = index > currentStepIndex;

        return (
          <React.Fragment key={step.id}>
            <div
              className={clsx(
                'flex',
                orientation === 'horizontal' ? 'flex-col items-center' : 'items-start'
              )}
            >
              <div
                className={clsx(
                  'flex items-center justify-center rounded-full w-8 h-8 text-sm font-medium',
                  isCompleted && 'bg-brand-600 text-white',
                  isCurrent && 'bg-brand-100 border-2 border-brand-600 text-brand-600',
                  isUpcoming && 'bg-gray-100 text-gray-500'
                )}
              >
                {isCompleted ? <Check size={16} /> : index + 1}
              </div>
              <div
                className={clsx(
                  'mt-2',
                  orientation === 'horizontal' ? 'text-center' : 'ml-3'
                )}
              >
                <div
                  className={clsx(
                    'text-sm font-medium',
                    isCompleted && 'text-brand-600',
                    isCurrent && 'text-gray-900',
                    isUpcoming && 'text-gray-500'
                  )}
                >
                  {step.label}
                </div>
                {step.description && (
                  <div
                    className={clsx(
                      'text-xs',
                      isCompleted && 'text-brand-500',
                      isCurrent && 'text-gray-700',
                      isUpcoming && 'text-gray-400'
                    )}
                  >
                    {step.description}
                  </div>
                )}
              </div>
            </div>
            {index < steps.length - 1 && (
              <div
                className={clsx(
                  orientation === 'horizontal'
                    ? 'flex-1 h-0.5 mx-2'
                    : 'w-0.5 h-6 ml-4 my-1',
                  index < currentStepIndex
                    ? 'bg-brand-600'
                    : 'bg-gray-200'
                )}
              />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
};

export default Stepper;