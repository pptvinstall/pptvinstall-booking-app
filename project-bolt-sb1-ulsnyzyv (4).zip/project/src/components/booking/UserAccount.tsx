import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock, User, Mail, Phone, Edit, Trash2, Eye, AlertCircle, CheckCircle, XCircle } from 'lucide-react';
import { format, isAfter, parseISO } from 'date-fns';
import Card, { CardBody, CardHeader } from '../ui/Card';
import Button from '../ui/Button';
import Tabs from '../ui/Tabs';
import Badge from '../ui/Badge';

interface Appointment {
  id: string;
  date: string; // ISO string
  timeSlot: string;
  services: string[];
  status: 'upcoming' | 'completed' | 'cancelled';
  totalPrice: number;
}

interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  preferredServices: string[];
}

interface UserAccountProps {
  onBookNew: () => void;
  onLogout: () => void;
}

const UserAccount: React.FC<UserAccountProps> = ({ onBookNew, onLogout }) => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Simulate loading user data
  useEffect(() => {
    // This would be an API call in a real application
    setTimeout(() => {
      setProfile({
        id: 'user-1',
        name: 'John Smith',
        email: 'john.smith@example.com',
        phone: '(404) 555-6789',
        address: '123 Main St, Atlanta, GA 30303',
        preferredServices: ['TV Mounting', 'Wire Concealment']
      });
      
      setAppointments([
        {
          id: 'appt-001',
          date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 days from now
          timeSlot: '10:00 AM',
          services: ['TV Mounting (65" TV)', 'Wire Concealment'],
          status: 'upcoming',
          totalPrice: 200
        },
        {
          id: 'appt-002',
          date: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(), // 14 days ago
          timeSlot: '2:00 PM',
          services: ['Soundbar Installation', 'Smart Home Setup'],
          status: 'completed',
          totalPrice: 150
        },
        {
          id: 'appt-003',
          date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days ago
          timeSlot: '9:00 AM',
          services: ['TV Mounting (55" TV)'],
          status: 'cancelled',
          totalPrice: 100
        }
      ]);
      
      setIsLoading(false);
    }, 1000);
  }, []);

  // Handle appointment cancellation
  const handleCancelAppointment = (appointmentId: string) => {
    // This would be an API call in a real application
    if (confirm('Are you sure you want to cancel this appointment?')) {
      setAppointments(prev => 
        prev.map(appt => 
          appt.id === appointmentId 
            ? { ...appt, status: 'cancelled' } 
            : appt
        )
      );
    }
  };

  // Handle appointment rescheduling
  const handleRescheduleAppointment = (appointmentId: string) => {
    // This would navigate to a reschedule form in a real application
    alert(`Reschedule appointment ${appointmentId}`);
  };

  // Handle profile update
  const handleUpdateProfile = () => {
    // This would open a profile edit form in a real application
    alert('Update profile');
  };

  // Filter appointments by status
  const upcomingAppointments = appointments.filter(appt => appt.status === 'upcoming');
  const pastAppointments = appointments.filter(appt => appt.status === 'completed' || appt.status === 'cancelled');

  // Check if an appointment can be cancelled (more than 24 hours before)
  const canCancelAppointment = (date: string): boolean => {
    const appointmentDate = parseISO(date);
    const twentyFourHoursFromNow = new Date(Date.now() + 24 * 60 * 60 * 1000);
    return isAfter(appointmentDate, twentyFourHoursFromNow);
  };

  // Render appointment card
  const renderAppointmentCard = (appointment: Appointment) => {
    const appointmentDate = parseISO(appointment.date);
    const formattedDate = format(appointmentDate, 'EEEE, MMMM d, yyyy');
    const canCancel = canCancelAppointment(appointment.date);
    
    return (
      <Card key={appointment.id} elevated className="mb-4">
        <CardBody className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <div className="flex items-center mb-2">
                {appointment.status === 'upcoming' && (
                  <Badge variant="primary" size="sm" className="mr-2">Upcoming</Badge>
                )}
                {appointment.status === 'completed' && (
                  <Badge variant="success" size="sm" className="mr-2">Completed</Badge>
                )}
                {appointment.status === 'cancelled' && (
                  <Badge variant="danger" size="sm" className="mr-2">Cancelled</Badge>
                )}
                <span className="text-sm text-gray-500">Booking #{appointment.id}</span>
              </div>
              <h3 className="text-lg font-bold text-gray-800">
                {formattedDate} at {appointment.timeSlot}
              </h3>
            </div>
            
            {appointment.status === 'upcoming' && (
              <div className="flex space-x-2">
                {canCancel && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-red-600 border-red-300 hover:bg-red-50"
                    onClick={() => handleCancelAppointment(appointment.id)}
                  >
                    Cancel
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleRescheduleAppointment(appointment.id)}
                >
                  Reschedule
                </Button>
              </div>
            )}
          </div>
          
          <div className="mb-4">
            <h4 className="text-sm font-medium text-gray-500 mb-1">Services</h4>
            <ul className="space-y-1">
              {appointment.services.map((service, index) => (
                <li key={index} className="text-gray-800 flex items-start">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2 mt-1 flex-shrink-0" />
                  {service}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="flex justify-between items-center pt-3 border-t border-gray-200">
            <span className="text-gray-600">Total</span>
            <span className="text-brand-600 font-bold">${appointment.totalPrice.toFixed(2)}</span>
          </div>
        </CardBody>
      </Card>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">My Account</h1>
        <p className="text-gray-600">
          Manage your appointments and account information
        </p>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600"></div>
        </div>
      ) : (
        <>
          {/* User Profile */}
          {profile && (
            <Card elevated className="mb-8">
              <CardBody className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <h2 className="text-xl font-bold text-gray-800 flex items-center">
                    <User className="mr-2 text-brand-600" size={24} />
                    My Profile
                  </h2>
                  <Button
                    variant="outline"
                    size="sm"
                    leftIcon={<Edit size={16} />}
                    onClick={handleUpdateProfile}
                  >
                    Edit Profile
                  </Button>
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Full Name</h3>
                    <p className="text-gray-800 font-medium">{profile.name}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Email</h3>
                    <p className="text-gray-800 font-medium">{profile.email}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Phone</h3>
                    <p className="text-gray-800 font-medium">{profile.phone}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Address</h3>
                    <p className="text-gray-800 font-medium">{profile.address}</p>
                  </div>
                </div>
                
                {profile.preferredServices.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <h3 className="text-sm font-medium text-gray-500 mb-2">Preferred Services</h3>
                    <div className="flex flex-wrap gap-2">
                      {profile.preferredServices.map((service, index) => (
                        <Badge key={index} variant="secondary">
                          {service}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardBody>
            </Card>
          )}

          {/* Appointments */}
          <Card elevated className="mb-8">
            <CardHeader className="p-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-800 flex items-center">
                  <Calendar className="mr-2 text-brand-600" size={24} />
                  My Appointments
                </h2>
                <Button
                  variant="primary"
                  size="sm"
                  onClick={onBookNew}
                >
                  Book New Appointment
                </Button>
              </div>
            </CardHeader>
            <CardBody className="p-6 pt-0">
              <Tabs
                tabs={[
                  {
                    id: 'upcoming',
                    label: `Upcoming (${upcomingAppointments.length})`,
                    content: (
                      <div className="py-4">
                        {upcomingAppointments.length === 0 ? (
                          <div className="text-center py-8 text-gray-500">
                            <Calendar className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                            <p>You don't have any upcoming appointments</p>
                            <Button
                              variant="outline"
                              size="sm"
                              className="mt-4"
                              onClick={onBookNew}
                            >
                              Book an Appointment
                            </Button>
                          </div>
                        ) : (
                          upcomingAppointments.map(renderAppointmentCard)
                        )}
                      </div>
                    )
                  },
                  {
                    id: 'past',
                    label: `Past Appointments (${pastAppointments.length})`,
                    content: (
                      <div className="py-4">
                        {pastAppointments.length === 0 ? (
                          <div className="text-center py-8 text-gray-500">
                            <Clock className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                            <p>You don't have any past appointments</p>
                          </div>
                        ) : (
                          pastAppointments.map(renderAppointmentCard)
                        )}
                      </div>
                    )
                  }
                ]}
                variant="underline"
              />
            </CardBody>
          </Card>

          {/* Account Actions */}
          <div className="flex justify-end">
            <Button
              variant="outline"
              onClick={onLogout}
            >
              Log Out
            </Button>
          </div>
        </>
      )}
    </motion.div>
  );
};

export default UserAccount;