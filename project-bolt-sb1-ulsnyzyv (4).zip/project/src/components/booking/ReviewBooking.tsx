import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock, User, Mail, Phone, MessageSquare, DollarSign, Check, AlertCircle, Edit, ChevronDown, ChevronUp, Tag } from 'lucide-react';
import { format } from 'date-fns';
import Card, { CardBody, CardFooter } from '../ui/Card';
import Button from '../ui/Button';
import Badge from '../ui/Badge';

interface TimeSlot {
  id: string;
  time: string;
}

interface ScheduleFormData {
  date: Date | null;
  timeSlot: string;
  fullName: string;
  email: string;
  phone: string;
  preferredTechnician: string;
  specialRequests: string;
  sendReminders: boolean;
  reminderMethod: 'email' | 'sms' | 'both';
}

interface ServiceSummary {
  name: string;
  price: number;
  quantity: number;
  category?: string;
}

interface PriceItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  category?: string;
  isDiscount?: boolean;
}

interface ReviewBookingProps {
  scheduleData: ScheduleFormData;
  selectedServices: string[];
  serviceSummary: ServiceSummary[];
  travelFee: number;
  totalPrice: number;
  tax?: number;
  taxRate?: number;
  discounts?: PriceItem[];
  onBack: () => void;
  onConfirm: () => void;
  onEdit: (section: 'services' | 'details' | 'schedule') => void;
}

const ReviewBooking: React.FC<ReviewBookingProps> = ({
  scheduleData,
  selectedServices,
  serviceSummary,
  travelFee,
  totalPrice,
  tax = 0,
  taxRate = 0,
  discounts = [],
  onBack,
  onConfirm,
  onEdit
}) => {
  const [showPriceDetails, setShowPriceDetails] = useState(true);

  // Get time slot display value
  const getTimeSlotDisplay = (): string => {
    if (!scheduleData.timeSlot) return 'Not selected';
    
    // Extract time from the time slot ID (format: yyyy-MM-dd-HH)
    const hour = parseInt(scheduleData.timeSlot.split('-')[3]);
    return `${hour % 12 || 12}:00 ${hour < 12 ? 'AM' : 'PM'}`;
  };

  // Get technician name
  const getTechnicianName = (): string => {
    if (!scheduleData.preferredTechnician) return 'No preference';
    
    // This would normally come from your technician data
    const technicianMap: Record<string, string> = {
      'tech-1': 'Michael Johnson',
      'tech-2': 'Sarah Williams',
      'tech-3': 'David Thompson',
      'tech-4': 'Jennifer Martinez'
    };
    
    return technicianMap[scheduleData.preferredTechnician] || 'Unknown';
  };

  // Get reminder method display
  const getReminderMethodDisplay = (): string => {
    if (!scheduleData.sendReminders) return 'No reminders';
    
    switch (scheduleData.reminderMethod) {
      case 'email':
        return 'Email only';
      case 'sms':
        return 'SMS only';
      case 'both':
        return 'Email and SMS';
      default:
        return 'Unknown';
    }
  };

  // Calculate subtotal
  const subtotal = serviceSummary.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  // Calculate discount total
  const discountTotal = discounts.reduce((sum, discount) => sum + discount.price, 0);

  // Group services by category
  const groupedServices: Record<string, ServiceSummary[]> = {};
  serviceSummary.forEach(service => {
    const category = service.category || 'Other';
    if (!groupedServices[category]) {
      groupedServices[category] = [];
    }
    groupedServices[category].push(service);
  });

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Review Your Booking</h1>
        <p className="text-gray-600">
          Please review your appointment details before confirming
        </p>
      </div>

      {/* Appointment Summary */}
      <Card elevated className="mb-8">
        <CardBody className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-xl font-bold text-gray-800 flex items-center">
              <Calendar className="mr-2 text-brand-600" size={24} />
              Appointment Details
            </h2>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => onEdit('schedule')}
              leftIcon={<Edit size={16} />}
            >
              Edit
            </Button>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-1">Date</h3>
              <p className="text-gray-800 font-medium">
                {scheduleData.date ? format(scheduleData.date, 'EEEE, MMMM d, yyyy') : 'Not selected'}
              </p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-1">Time</h3>
              <p className="text-gray-800 font-medium">
                {getTimeSlotDisplay()}
              </p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-1">Preferred Technician</h3>
              <p className="text-gray-800 font-medium">
                {getTechnicianName()}
              </p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-1">Reminders</h3>
              <p className="text-gray-800 font-medium">
                {getReminderMethodDisplay()}
              </p>
            </div>
          </div>
          
          {scheduleData.specialRequests && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <h3 className="text-sm font-medium text-gray-500 mb-1">Special Requests</h3>
              <p className="text-gray-800">
                {scheduleData.specialRequests}
              </p>
            </div>
          )}
        </CardBody>
      </Card>

      {/* Contact Information */}
      <Card elevated className="mb-8">
        <CardBody className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-xl font-bold text-gray-800 flex items-center">
              <User className="mr-2 text-brand-600" size={24} />
              Contact Information
            </h2>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => onEdit('schedule')}
              leftIcon={<Edit size={16} />}
            >
              Edit
            </Button>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-1">Full Name</h3>
              <p className="text-gray-800 font-medium">
                {scheduleData.fullName}
              </p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-1">Phone Number</h3>
              <p className="text-gray-800 font-medium">
                {scheduleData.phone}
              </p>
            </div>
            
            {scheduleData.email && (
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">Email Address</h3>
                <p className="text-gray-800 font-medium">
                  {scheduleData.email}
                </p>
              </div>
            )}
          </div>
        </CardBody>
      </Card>

      {/* Service Summary */}
      <Card elevated className="mb-8">
        <CardBody className="p-6">
          <div className="flex justify-between items-start mb-4">
            <h2 className="text-xl font-bold text-gray-800 flex items-center">
              <DollarSign className="mr-2 text-brand-600" size={24} />
              Service Summary
            </h2>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => onEdit('services')}
              leftIcon={<Edit size={16} />}
            >
              Edit
            </Button>
          </div>
          
          <div className="space-y-4">
            {/* Services by category */}
            {Object.entries(groupedServices).map(([category, services]) => (
              <div key={category} className="mb-3">
                <h4 className="text-sm font-medium text-gray-500 mb-2">{category}</h4>
                {services.map((service, index) => (
                  <div key={index} className="flex justify-between items-center mb-2">
                    <div>
                      <span className="text-gray-800">
                        {service.name}
                        {service.quantity > 1 && (
                          <span className="text-gray-500 ml-1">
                            (x{service.quantity})
                          </span>
                        )}
                      </span>
                    </div>
                    <span className="text-gray-800 font-medium">
                      ${(service.price * service.quantity).toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            ))}
            
            {/* Subtotal */}
            <div className="flex justify-between items-center pt-2 border-t border-gray-200">
              <span className="text-gray-700">Subtotal</span>
              <span className="text-gray-800 font-medium">${subtotal.toFixed(2)}</span>
            </div>
            
            {/* Discounts */}
            {discounts.length > 0 && (
              <>
                {discounts.map((discount, index) => (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-green-600 flex items-center">
                      <Tag size={16} className="mr-1" />
                      {discount.name}
                    </span>
                    <span className="text-green-600 font-medium">
                      ${Math.abs(discount.price).toFixed(2)}
                    </span>
                  </div>
                ))}
              </>
            )}
            
            {/* Travel Fee */}
            {travelFee > 0 && (
              <div className="flex justify-between items-center">
                <span className="text-gray-700">Travel Fee</span>
                <span className="text-gray-800 font-medium">${travelFee.toFixed(2)}</span>
              </div>
            )}
            
            {/* Tax */}
            {tax > 0 && (
              <div className="flex justify-between items-center">
                <span className="text-gray-700">
                  Tax {taxRate > 0 && `(${(taxRate * 100).toFixed(1)}%)`}
                </span>
                <span className="text-gray-800 font-medium">${tax.toFixed(2)}</span>
              </div>
            )}
            
            {/* Total */}
            <div className="flex justify-between items-center pt-2 border-t border-gray-200">
              <span className="text-gray-900 font-bold">Total</span>
              <span className="text-brand-600 font-bold text-xl">${totalPrice.toFixed(2)}</span>
            </div>
            
            {/* Savings Badge */}
            {discounts.length > 0 && (
              <div className="mt-2">
                <Badge variant="success" size="md" className="w-full flex justify-center py-1">
                  <Tag size={16} className="mr-1" /> 
                  You're saving ${Math.abs(discountTotal).toFixed(2)} with applied discounts!
                </Badge>
              </div>
            )}
          </div>
        </CardBody>
        <CardFooter className="bg-gray-50 p-4 border-t border-gray-200">
          <div className="text-sm text-gray-600">
            <p className="mb-2">
              <strong>Cancellation Policy:</strong> You may cancel or reschedule your appointment up to 24 hours before the scheduled time without any charges.
            </p>
            <p>
              <strong>Payment:</strong> Payment will be collected at the time of service. We accept all major credit cards, cash, and digital payment methods.
            </p>
          </div>
        </CardFooter>
      </Card>

      {/* Confirmation */}
      <Card elevated className="mb-8 border border-brand-200 bg-brand-50">
        <CardBody className="p-6">
          <div className="flex items-start">
            <div className="bg-brand-100 p-2 rounded-full mr-4">
              <Check className="h-6 w-6 text-brand-600" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-800 mb-2">
                Ready to Confirm Your Booking
              </h2>
              <p className="text-gray-600 mb-2">
                By confirming, you agree to our terms of service and cancellation policy. A confirmation will be sent to your email and/or phone.
              </p>
              <p className="text-gray-600">
                Our technician will arrive within the selected time slot. We'll send you a reminder 24 hours before your appointment.
              </p>
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Navigation Buttons */}
      <div className="flex justify-between mt-8">
        <Button 
          type="button" 
          onClick={onBack} 
          variant="outline"
        >
          Back
        </Button>
        <Button 
          type="button" 
          onClick={onConfirm} 
          variant="primary"
          size="lg"
        >
          Confirm Booking
        </Button>
      </div>
    </motion.div>
  );
};

export default ReviewBooking;