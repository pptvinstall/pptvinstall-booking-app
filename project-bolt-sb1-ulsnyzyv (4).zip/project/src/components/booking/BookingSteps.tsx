import React from 'react';
import { motion } from 'framer-motion';
import Stepper from '../ui/Stepper';

interface BookingStepsProps {
  currentStep: string;
}

const BookingSteps: React.FC<BookingStepsProps> = ({ currentStep }) => {
  const steps = [
    {
      id: 'services',
      label: 'Select Services',
      description: 'Choose what you need'
    },
    {
      id: 'details',
      label: 'Installation Details',
      description: 'Tell us about your setup'
    },
    {
      id: 'schedule',
      label: 'Schedule',
      description: 'Pick a date & time'
    },
    {
      id: 'review',
      label: 'Review & Pay',
      description: 'Confirm your booking'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="mb-8"
    >
      <Stepper 
        steps={steps} 
        currentStep={currentStep} 
        orientation="horizontal" 
        className="max-w-3xl mx-auto"
      />
    </motion.div>
  );
};

export default BookingSteps;