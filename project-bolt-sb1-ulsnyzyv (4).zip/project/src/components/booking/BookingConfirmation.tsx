import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Calendar, Clock, MapPin, User, Phone, Mail, ArrowRight, Download, Share2 } from 'lucide-react';
import { format } from 'date-fns';
import Card, { CardBody } from '../ui/Card';
import Button from '../ui/Button';

interface BookingConfirmationProps {
  bookingId: string;
  appointmentDate: Date;
  appointmentTime: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  services: string[];
  totalPrice: number;
  onBookAnother: () => void;
  onViewAccount: () => void;
}

const BookingConfirmation: React.FC<BookingConfirmationProps> = ({
  bookingId,
  appointmentDate,
  appointmentTime,
  customerName,
  customerPhone,
  customerEmail,
  services,
  totalPrice,
  onBookAnother,
  onViewAccount
}) => {
  useEffect(() => {
    console.log('Sending confirmation to:', customerEmail, customerPhone);
  }, [customerEmail, customerPhone]);

  // Validate appointmentDate before formatting
  const formattedDate = isNaN(appointmentDate.getTime())
    ? "Invalid Date"
    : format(appointmentDate, 'EEEE, MMMM d, yyyy');

  const addToCalendar = () => {
    alert('Calendar feature would be implemented here');
  };

  const shareAppointment = () => {
    if (navigator.share) {
      navigator.share({
        title: 'My TV Installation Appointment',
        text: `I have a TV installation appointment on ${formattedDate} at ${appointmentTime}.`,
        url: window.location.href,
      });
    } else {
      alert('Sharing is not available on this device');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-2xl mx-auto"
    >
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
          <CheckCircle className="h-10 w-10 text-green-600" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Booking Confirmed!</h1>
        <p className="text-gray-600 text-lg">Your appointment has been successfully scheduled</p>
      </div>

      <Card elevated className="mb-8 border-t-4 border-green-500">
        <CardBody className="p-6">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-xl font-bold text-gray-800">Appointment Details</h2>
            <div className="bg-gray-100 px-3 py-1 rounded-full text-sm font-medium text-gray-800">
              Booking #{bookingId}
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="flex items-start">
              <Calendar className="h-5 w-5 text-brand-600 mt-0.5 mr-3 flex-shrink-0" />
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">Date</h3>
                <p className="text-gray-800 font-medium">{formattedDate}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Clock className="h-5 w-5 text-brand-600 mt-0.5 mr-3 flex-shrink-0" />
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">Time</h3>
                <p className="text-gray-800 font-medium">{appointmentTime}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <MapPin className="h-5 w-5 text-brand-600 mt-0.5 mr-3 flex-shrink-0" />
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">Location</h3>
                <p className="text-gray-800 font-medium">Your Home</p>
                <p className="text-gray-600 text-sm">Our technician will arrive at your address</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <User className="h-5 w-5 text-brand-600 mt-0.5 mr-3 flex-shrink-0" />
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">Customer</h3>
                <p className="text-gray-800 font-medium">{customerName}</p>
              </div>
            </div>
          </div>
          
          <div className="mt-6 pt-6 border-t border-gray-200">
            <h3 className="text-sm font-medium text-gray-500 mb-2">Services</h3>
            <ul className="space-y-1">
              {services.map((service, index) => (
                <li key={index} className="text-gray-800 flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  {service}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="mt-6 pt-6 border-t border-gray-200 flex justify-between items-center">
            <span className="text-gray-800 font-medium">Total Price:</span>
            <span className="text-brand-600 font-bold text-xl">{`$${totalPrice.toFixed(2)}`}</span>
          </div>
        </CardBody>
      </Card>

      <Card elevated className="mb-8">
        <CardBody className="p-6">
          <h2 className="text-xl font-bold text-gray-800 mb-4">What's Next</h2>
          <div className="space-y-4">
            <div className="flex items-start">
              <div className="bg-brand-100 rounded-full w-6 h-6 flex items-center justify-center mr-3 flex-shrink-0">
                <span className="text-brand-600 font-medium text-sm">1</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-800">Confirmation Sent</h3>
                <p className="text-gray-600 text-sm">
                  {customerEmail && `We've sent a confirmation email to ${customerEmail}`}
                  {customerEmail && customerPhone && ' and '}
                  {customerPhone && `a text message to ${customerPhone}`}
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="bg-brand-100 rounded-full w-6 h-6 flex items-center justify-center mr-3 flex-shrink-0">
                <span className="text-brand-600 font-medium text-sm">2</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-800">Appointment Reminder</h3>
                <p className="text-gray-600 text-sm">
                  We'll send you a reminder 24 hours before your appointment
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="bg-brand-100 rounded-full w-6 h-6 flex items-center justify-center mr-3 flex-shrink-0">
                <span className="text-brand-600 font-medium text-sm">3</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-800">Technician Arrival</h3>
                <p className="text-gray-600 text-sm">
                  Our technician will arrive during your scheduled time slot
                </p>
              </div>
            </div>
          </div>
        </CardBody>
      </Card>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <Button
          variant="outline"
          fullWidth
          leftIcon={<Download size={18} />}
          onClick={addToCalendar}
        >
          Add to Calendar
        </Button>
        <Button
          variant="outline"
          fullWidth
          leftIcon={<Share2 size={18} />}
          onClick={shareAppointment}
        >
          Share Appointment
        </Button>
      </div>

      <Card elevated className="mb-8 bg-gray-50">
        <CardBody className="p-6">
          <h2 className="text-lg font-bold text-gray-800 mb-4">Need to make changes?</h2>
          <div className="space-y-3">
            <div className="flex items-center">
              <Phone className="h-5 w-5 text-brand-600 mr-3" />
              <div>
                <p className="text-gray-800 font-medium">(404) 555-1234</p>
                <p className="text-gray-600 text-sm">Call us to reschedule or cancel</p>
              </div>
            </div>
            <div className="flex items-center">
              <Mail className="h-5 w-5 text-brand-600 mr-3" />
              <div>
                <p className="text-gray-800 font-medium">support@pictureperfect.com</p>
                <p className="text-gray-600 text-sm">Email our support team</p>
              </div>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-200 text-sm text-gray-600">
            <p>
              <strong>Cancellation Policy:</strong> You may cancel or reschedule your appointment up to 24 hours before the scheduled time without any charges.
            </p>
          </div>
        </CardBody>
      </Card>

      <div className="flex flex-col md:flex-row justify-between gap-4">
        <Button variant="outline" onClick={onBookAnother}>
          Book Another Service
        </Button>
        <Button variant="primary" rightIcon={<ArrowRight size={18} />} onClick={onViewAccount}>
          View My Account
        </Button>
      </div>
    </motion.div>
  );
};

export default BookingConfirmation;
