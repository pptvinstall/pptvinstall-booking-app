import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calendar as CalendarIcon, Clock, User, Mail, Phone, MessageSquare, Calendar, ChevronLeft, ChevronRight, Check, AlertCircle } from 'lucide-react';
import Card, { CardBody } from '../ui/Card';
import Input from '../ui/Input';
import Button from '../ui/Button';
import Select from '../ui/Select';
import Checkbox from '../ui/Checkbox';
import { format, addDays, startOfWeek, addWeeks, subWeeks, isSameDay, isAfter, isBefore, addMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth } from 'date-fns';

interface TimeSlot {
  id: string;
  time: string;
  available: boolean;
}

interface Technician {
  id: string;
  name: string;
  specialties: string[];
  available: boolean;
}

interface ScheduleFormData {
  date: Date | null;
  timeSlot: string;
  fullName: string;
  email: string;
  phone: string;
  preferredTechnician: string;
  specialRequests: string;
  sendReminders: boolean;
  reminderMethod: 'email' | 'sms' | 'both';
}

interface ScheduleFormProps {
  onBack: () => void;
  onContinue: (data: ScheduleFormData) => void;
  initialData?: Partial<ScheduleFormData>;
  selectedServices: string[];
}

const ScheduleForm: React.FC<ScheduleFormProps> = ({
  onBack,
  onContinue,
  initialData = {},
  selectedServices
}) => {
  const [formData, setFormData] = useState<ScheduleFormData>({
    date: null,
    timeSlot: '',
    fullName: '',
    email: '',
    phone: '',
    preferredTechnician: '',
    specialRequests: '',
    sendReminders: true,
    reminderMethod: 'both',
    ...initialData
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [calendarView, setCalendarView] = useState<'month' | 'week'>('month');
  const [currentWeek, setCurrentWeek] = useState<Date>(startOfWeek(new Date(), { weekStartsOn: 0 }));
  const [availableTimeSlots, setAvailableTimeSlots] = useState<Record<string, TimeSlot[]>>({});
  const [technicians, setTechnicians] = useState<Technician[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Generate time slots for the selected date
  useEffect(() => {
    if (formData.date) {
      const dateString = format(formData.date, 'yyyy-MM-dd');
      
      // Check if we already have time slots for this date
      if (!availableTimeSlots[dateString]) {
        setIsLoading(true);
        
        // Simulate API call to get available time slots
        setTimeout(() => {
          // Generate time slots from 8 AM to 6 PM
          const slots: TimeSlot[] = [];
          for (let hour = 8; hour <= 18; hour++) {
            // Skip 12 PM (lunch break)
            if (hour !== 12) {
              const time = `${hour % 12 || 12}:00 ${hour < 12 ? 'AM' : 'PM'}`;
              const id = `${dateString}-${hour}`;
              
              // Randomly mark some slots as unavailable
              const available = Math.random() > 0.3;
              
              slots.push({ id, time, available });
            }
          }
          
          setAvailableTimeSlots(prev => ({
            ...prev,
            [dateString]: slots
          }));
          
          setIsLoading(false);
        }, 500);
      }
    }
  }, [formData.date]);

  // Load technicians
  useEffect(() => {
    // Simulate API call to get technicians
    setTimeout(() => {
      setTechnicians([
        {
          id: 'tech-1',
          name: 'Michael Johnson',
          specialties: ['TV Mounting', 'Wire Concealment', 'Smart Home'],
          available: true
        },
        {
          id: 'tech-2',
          name: 'Sarah Williams',
          specialties: ['TV Mounting', 'Fireplace Installation', 'Soundbar Setup'],
          available: true
        },
        {
          id: 'tech-3',
          name: 'David Thompson',
          specialties: ['Smart Home', 'Video Doorbell', 'Floodlight Installation'],
          available: true
        },
        {
          id: 'tech-4',
          name: 'Jennifer Martinez',
          specialties: ['TV Mounting', 'Wire Concealment', 'Soundbar Setup'],
          available: false
        }
      ]);
    }, 300);
  }, []);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({
        ...prev,
        [name]: checked
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
    
    // Clear error when field is changed
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleDateSelect = (date: Date) => {
    // Don't allow selecting dates in the past
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (isBefore(date, today)) {
      return;
    }
    
    setFormData(prev => ({
      ...prev,
      date,
      timeSlot: '' // Reset time slot when date changes
    }));
    
    if (errors.date) {
      setErrors(prev => ({
        ...prev,
        date: ''
      }));
    }
  };

  const handleTimeSlotSelect = (slotId: string) => {
    setFormData(prev => ({
      ...prev,
      timeSlot: slotId
    }));
    
    if (errors.timeSlot) {
      setErrors(prev => ({
        ...prev,
        timeSlot: ''
      }));
    }
  };

  const handleTechnicianSelect = (techId: string) => {
    setFormData(prev => ({
      ...prev,
      preferredTechnician: techId
    }));
  };

  const handleReminderMethodChange = (method: 'email' | 'sms' | 'both') => {
    setFormData(prev => ({
      ...prev,
      reminderMethod: method
    }));
  };

  const nextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1));
  };

  const prevMonth = () => {
    setCurrentMonth(addMonths(currentMonth, -1));
  };

  const nextWeek = () => {
    setCurrentWeek(addWeeks(currentWeek, 1));
  };

  const prevWeek = () => {
    setCurrentWeek(subWeeks(currentWeek, 1));
  };

  const toggleCalendarView = () => {
    setCalendarView(prev => prev === 'month' ? 'week' : 'month');
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.date) {
      newErrors.date = 'Please select a date';
    }
    
    if (!formData.timeSlot) {
      newErrors.timeSlot = 'Please select a time slot';
    }
    
    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\d{10}$/.test(formData.phone.replace(/\D/g, ''))) {
      newErrors.phone = 'Please enter a valid 10-digit phone number';
    }
    
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (formData.sendReminders && formData.reminderMethod === 'email' && !formData.email) {
      newErrors.email = 'Email is required for email reminders';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      onContinue(formData);
    }
  };

  // Generate calendar days for month view
  const generateMonthDays = () => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(currentMonth);
    const startDate = startOfWeek(monthStart, { weekStartsOn: 0 });
    const endDate = addDays(startOfWeek(addDays(monthEnd, 1), { weekStartsOn: 0 }), 6);
    
    const days = eachDayOfInterval({ start: startDate, end: endDate });
    
    // Group days into weeks
    const weeks: Date[][] = [];
    let week: Date[] = [];
    
    days.forEach((day, i) => {
      week.push(day);
      if ((i + 1) % 7 === 0) {
        weeks.push(week);
        week = [];
      }
    });
    
    return weeks;
  };

  // Generate calendar days for week view
  const generateWeekDays = () => {
    const days: Date[] = [];
    for (let i = 0; i < 7; i++) {
      days.push(addDays(currentWeek, i));
    }
    return days;
  };

  // Check if a date is selectable (not in the past)
  const isDateSelectable = (date: Date): boolean => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return !isBefore(date, today);
  };

  // Get time slots for the selected date
  const getTimeSlots = (): TimeSlot[] => {
    if (!formData.date) return [];
    
    const dateString = format(formData.date, 'yyyy-MM-dd');
    return availableTimeSlots[dateString] || [];
  };

  // Get available technicians
  const getAvailableTechnicians = (): Technician[] => {
    return technicians.filter(tech => tech.available);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Schedule Your Appointment</h1>
        <p className="text-gray-600">
          Choose a convenient date and time for your installation
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Calendar Section */}
        <Card elevated className="mb-8">
          <CardBody className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-800 flex items-center">
                <CalendarIcon className="mr-2 text-brand-600" size={24} />
                Select a Date
              </h2>
              <div className="flex items-center space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={toggleCalendarView}
                >
                  {calendarView === 'month' ? 'Week View' : 'Month View'}
                </Button>
                {calendarView === 'month' ? (
                  <div className="flex items-center">
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={prevMonth}
                      className="p-1"
                    >
                      <ChevronLeft size={20} />
                    </Button>
                    <span className="mx-2 font-medium">
                      {format(currentMonth, 'MMMM yyyy')}
                    </span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={nextMonth}
                      className="p-1"
                    >
                      <ChevronRight size={20} />
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center">
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={prevWeek}
                      className="p-1"
                    >
                      <ChevronLeft size={20} />
                    </Button>
                    <span className="mx-2 font-medium">
                      {format(currentWeek, 'MMM d')} - {format(addDays(currentWeek, 6), 'MMM d, yyyy')}
                    </span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={nextWeek}
                      className="p-1"
                    >
                      <ChevronRight size={20} />
                    </Button>
                  </div>
                )}
              </div>
            </div>

            {errors.date && (
              <div className="mb-4 p-2 bg-red-50 text-red-600 rounded-md flex items-center">
                <AlertCircle size={16} className="mr-2" />
                {errors.date}
              </div>
            )}

            {/* Month View Calendar */}
            {calendarView === 'month' && (
              <div className="mb-4">
                <div className="grid grid-cols-7 gap-1 mb-2">
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                    <div key={day} className="text-center text-sm font-medium text-gray-500 py-2">
                      {day}
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-7 gap-1">
                  {generateMonthDays().flat().map((day, i) => {
                    const isSelected = formData.date && isSameDay(day, formData.date);
                    const isCurrentMonth = isSameMonth(day, currentMonth);
                    const selectable = isDateSelectable(day);
                    
                    return (
                      <button
                        key={i}
                        type="button"
                        onClick={() => selectable && handleDateSelect(day)}
                        className={`
                          h-12 rounded-md flex items-center justify-center
                          ${isSelected ? 'bg-brand-600 text-white' : ''}
                          ${!isCurrentMonth ? 'text-gray-300' : selectable ? 'text-gray-700' : 'text-gray-300'}
                          ${selectable && !isSelected ? 'hover:bg-gray-100' : ''}
                          ${!selectable ? 'cursor-not-allowed' : 'cursor-pointer'}
                        `}
                        disabled={!selectable}
                      >
                        {format(day, 'd')}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Week View Calendar */}
            {calendarView === 'week' && (
              <div className="mb-4">
                <div className="grid grid-cols-7 gap-2">
                  {generateWeekDays().map((day, i) => {
                    const isSelected = formData.date && isSameDay(day, formData.date);
                    const selectable = isDateSelectable(day);
                    const dayName = format(day, 'EEE');
                    const dayNumber = format(day, 'd');
                    
                    return (
                      <button
                        key={i}
                        type="button"
                        onClick={() => selectable && handleDateSelect(day)}
                        className={`
                          py-3 rounded-md flex flex-col items-center justify-center
                          ${isSelected ? 'bg-brand-600 text-white' : ''}
                          ${selectable ? 'text-gray-700' : 'text-gray-300'}
                          ${selectable && !isSelected ? 'hover:bg-gray-100' : ''}
                          ${!selectable ? 'cursor-not-allowed' : 'cursor-pointer'}
                        `}
                        disabled={!selectable}
                      >
                        <span className="text-sm font-medium">{dayName}</span>
                        <span className="text-lg">{dayNumber}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Time Slots */}
            {formData.date && (
              <div className="mt-6">
                <h3 className="text-lg font-medium text-gray-800 mb-3 flex items-center">
                  <Clock className="mr-2 text-brand-600" size={20} />
                  Available Time Slots for {format(formData.date, 'EEEE, MMMM d, yyyy')}
                </h3>
                
                {errors.timeSlot && (
                  <div className="mb-4 p-2 bg-red-50 text-red-600 rounded-md flex items-center">
                    <AlertCircle size={16} className="mr-2" />
                    {errors.timeSlot}
                  </div>
                )}
                
                {isLoading ? (
                  <div className="flex justify-center py-4">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600"></div>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                    {getTimeSlots().map(slot => (
                      <button
                        key={slot.id}
                        type="button"
                        onClick={() => slot.available && handleTimeSlotSelect(slot.id)}
                        className={`
                          py-2 px-3 rounded-md text-center
                          ${formData.timeSlot === slot.id ? 'bg-brand-600 text-white' : ''}
                          ${slot.available 
                            ? formData.timeSlot !== slot.id ? 'bg-gray-100 hover:bg-gray-200 text-gray-700' : ''
                            : 'bg-gray-100 text-gray-400 cursor-not-allowed'}
                        `}
                        disabled={!slot.available}
                      >
                        {slot.time}
                        {formData.timeSlot === slot.id && (
                          <Check size={16} className="ml-1 inline-block" />
                        )}
                      </button>
                    ))}
                  </div>
                )}
                
                {getTimeSlots().length === 0 && !isLoading && (
                  <div className="text-center py-4 text-gray-500">
                    No time slots available for this date. Please select another date.
                  </div>
                )}
              </div>
            )}
          </CardBody>
        </Card>

        {/* Contact Information */}
        <Card elevated className="mb-8">
          <CardBody className="p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
              <User className="mr-2 text-brand-600" size={24} />
              Contact Information
            </h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <Input
                label="Full Name"
                name="fullName"
                value={formData.fullName}
                onChange={handleInputChange}
                error={errors.fullName}
                leftIcon={<User size={18} />}
                isRequired
                fullWidth
              />
              
              <Input
                label="Phone Number"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                error={errors.phone}
                leftIcon={<Phone size={18} />}
                placeholder="(123) 456-7890"
                isRequired
                fullWidth
              />
              
              <Input
                label="Email Address"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                error={errors.email}
                leftIcon={<Mail size={18} />}
                placeholder="your@email.com"
                helperText="Required for email confirmations and reminders"
                fullWidth
              />
              
              <Select
                label="Preferred Technician (Optional)"
                name="preferredTechnician"
                value={formData.preferredTechnician}
                onChange={(value) => handleTechnicianSelect(value)}
                options={[
                  { value: '', label: 'No preference' },
                  ...getAvailableTechnicians().map(tech => ({
                    value: tech.id,
                    label: tech.name
                  }))
                ]}
                fullWidth
              />
            </div>
          </CardBody>
        </Card>

        {/* Appointment Preferences */}
        <Card elevated className="mb-8">
          <CardBody className="p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
              <Calendar className="mr-2 text-brand-600" size={24} />
              Appointment Preferences
            </h2>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Appointment Reminders
              </label>
              <div className="flex items-center mb-4">
                <Checkbox
                  label="Send me reminders before my appointment"
                  name="sendReminders"
                  checked={formData.sendReminders}
                  onChange={(checked) => {
                    setFormData(prev => ({
                      ...prev,
                      sendReminders: checked
                    }));
                  }}
                />
              </div>
              
              {formData.sendReminders && (
                <div className="ml-7 space-y-2">
                  <div className="flex items-center">
                    <input
                      type="radio"
                      id="reminder-email"
                      name="reminderMethod"
                      checked={formData.reminderMethod === 'email'}
                      onChange={() => handleReminderMethodChange('email')}
                      className="h-4 w-4 text-brand-600 focus:ring-brand-500 border-gray-300"
                    />
                    <label htmlFor="reminder-email" className="ml-2 text-sm text-gray-700">
                      Email only
                    </label>
                  </div>
                  <div className="flex items-center">
                    <input
                      type="radio"
                      id="reminder-sms"
                      name="reminderMethod"
                      checked={formData.reminderMethod === 'sms'}
                      onChange={() => handleReminderMethodChange('sms')}
                      className="h-4 w-4 text-brand-600 focus:ring-brand-500 border-gray-300"
                    />
                    <label htmlFor="reminder-sms" className="ml-2 text-sm text-gray-700">
                      SMS only
                    </label>
                  </div>
                  <div className="flex items-center">
                    <input
                      type="radio"
                      id="reminder-both"
                      name="reminderMethod"
                      checked={formData.reminderMethod === 'both'}
                      onChange={() => handleReminderMethodChange('both')}
                      className="h-4 w-4 text-brand-600 focus:ring-brand-500 border-gray-300"
                    />
                    <label htmlFor="reminder-both" className="ml-2 text-sm text-gray-700">
                      Both email and SMS
                    </label>
                  </div>
                </div>
              )}
            </div>
            
            <div>
              <Input
                label="Special Requests or Notes"
                name="specialRequests"
                value={formData.specialRequests}
                onChange={handleInputChange}
                leftIcon={<MessageSquare size={18} />}
                as="textarea"
                rows={4}
                placeholder="Any special instructions or requests for your appointment..."
                fullWidth
              />
            </div>
          </CardBody>
        </Card>

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-8">
          <Button 
            type="button" 
            onClick={onBack} 
            variant="outline"
          >
            Back
          </Button>
          <Button 
            type="submit" 
            variant="primary"
          >
            Continue to Review
          </Button>
        </div>
      </form>
    </motion.div>
  );
};

export default ScheduleForm;