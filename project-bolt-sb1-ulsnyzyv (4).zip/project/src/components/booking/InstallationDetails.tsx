import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Tv, Upload, Info, PlusCircle, MinusCircle, Cable } from 'lucide-react';
import Card, { CardBody } from '../ui/Card';
import Input from '../ui/Input';
import RadioGroup from '../ui/RadioGroup';
import Checkbox from '../ui/Checkbox';
import Select from '../ui/Select';
import Button from '../ui/Button';

interface TvMountingOption {
  location: 'wall' | 'fireplace';
  fireplaceType?: 'brick' | 'drywall';
  fireplacePhoto?: File | null;
  wireConcealment: boolean;
  soundbarInstallation: boolean;
}

interface InstallationDetailsFormData {
  // TV Mounting Options
  includeTvMounting: boolean;
  tvOptions: TvMountingOption[];
  // Mount Selection
  needsMounts: boolean;
  mountType: string;
  mountCount: number;
  // Additional Services
  wireConcealmentStandalone: boolean;
  wireConcealmentCount: number;
  smartFloodlight: boolean;
  smartFloodlightCount: number;
  smartVideoDoorbell: boolean;
  smartVideoDoorbellCount: number;
  customInstallation: string;
}

interface InstallationDetailsProps {
  formData: InstallationDetailsFormData;
  onChange: (data: InstallationDetailsFormData) => void;
  onBack: () => void;
  onContinue: () => void;
  selectedServices: string[];
}

const InstallationDetails: React.FC<InstallationDetailsProps> = ({
  formData,
  onChange,
  onBack,
  onContinue,
  selectedServices
}) => {
  const [errors, setErrors] = useState<Record<string, string>>({});

  const initialTvOption: TvMountingOption = {
    location: 'wall',
    wireConcealment: false,
    soundbarInstallation: false,
  };

  const handleChange = (
    field: keyof InstallationDetailsFormData,
    value: any
  ) => {
    onChange({
      ...formData,
      [field]: value
    });

    if (errors[field]) {
      setErrors((prev) => ({
        ...prev,
        [field]: '',
      }));
    }
  };

  const handleTvOptionChange = (
    index: number,
    field: keyof TvMountingOption,
    value: any
  ) => {
    const updatedTvOptions = [...formData.tvOptions];
    updatedTvOptions[index] = {
      ...updatedTvOptions[index],
      [field]: value,
    };

    if (field === 'location' && value === 'wall') {
      delete updatedTvOptions[index].fireplaceType;
      delete updatedTvOptions[index].fireplacePhoto;
    }

    onChange({
      ...formData,
      tvOptions: updatedTvOptions,
    });

    const errorKey = `tvOptions[${index}].${field}`;
    if (errors[errorKey]) {
      setErrors((prev) => ({
        ...prev,
        [errorKey]: '',
      }));
    }
  };

  const handleFireplacePhotoChange = (
    index: number,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    if (e.target.files && e.target.files.length > 0) {
      handleTvOptionChange(index, 'fireplacePhoto', e.target.files[0]);
    }
  };

  const addTvOption = () => {
    onChange({
      ...formData,
      tvOptions: [...formData.tvOptions, { ...initialTvOption }],
    });
  };

  const removeTvOption = (index: number) => {
    if (formData.tvOptions.length > 1) {
      const updatedTvOptions = [...formData.tvOptions];
      updatedTvOptions.splice(index, 1);
      onChange({
        ...formData,
        tvOptions: updatedTvOptions,
      });
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (formData.includeTvMounting) {
      formData.tvOptions.forEach((tv, index) => {
        if (tv.location === 'fireplace') {
          if (!tv.fireplaceType) {
            newErrors[`tvOptions[${index}].fireplaceType`] = 'Please select fireplace type';
          }
        }
      });
    }

    if (formData.needsMounts && formData.mountCount <= 0) {
      newErrors.mountCount = 'Please select at least 1 mount';
    }

    if (formData.wireConcealmentStandalone && formData.wireConcealmentCount <= 0) {
      newErrors.wireConcealmentCount = 'Please select at least 1';
    }

    if (formData.smartFloodlight && formData.smartFloodlightCount <= 0) {
      newErrors.smartFloodlightCount = 'Please select at least 1';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onContinue();
    }
  };

  // Check if specific services are selected
  const hasTvMounting = selectedServices.some(id => id.includes('basic-mounting') || id.includes('fireplace-mounting'));
  const hasMounts = selectedServices.some(id => id.includes('tv-mounts'));
  const hasWireConcealment = selectedServices.some(id => id.includes('wire-concealment'));
  const hasSoundbar = selectedServices.some(id => id.includes('soundbar-installation'));
  const hasSmartFloodlight = selectedServices.some(id => id.includes('smart-floodlight'));
  const hasSmartDoorbell = selectedServices.some(id => id.includes('smart-doorbell'));

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Installation Details</h1>
        <p className="text-gray-600">
          Tell us more about your specific installation needs
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        {/* TV Mounting Options */}
        {hasTvMounting && (
          <Card elevated className="mb-8">
            <CardBody className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-800 flex items-center">
                  <Tv className="mr-2 text-brand-600" size={24} />
                  TV Mounting Details
                </h2>
                <Button
                  type="button"
                  onClick={addTvOption}
                  variant="outline"
                  size="sm"
                  leftIcon={<PlusCircle size={16} />}
                >
                  Add Another TV
                </Button>
              </div>
              
              {formData.tvOptions.map((tv, index) => (
                <div
                  key={index}
                  className="mb-6 pb-6 border-b border-gray-200 last:border-b-0 last:mb-0 last:pb-0"
                >
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-gray-700">TV #{index + 1}</h3>
                    {formData.tvOptions.length > 1 && (
                      <Button
                        type="button"
                        onClick={() => removeTvOption(index)}
                        variant="outline"
                        size="sm"
                        className="text-red-500 border-red-300 hover:bg-red-50"
                        leftIcon={<MinusCircle size={16} />}
                      >
                        Remove
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <RadioGroup
                      name={`tv-${index}-location`}
                      label="Mounting Location"
                      options={[
                        { value: 'wall', label: 'Regular Wall' },
                        { value: 'fireplace', label: 'Above Fireplace' }
                      ]}
                      value={tv.location}
                      onChange={(value) => handleTvOptionChange(index, 'location', value)}
                      horizontal
                    />
                    
                    {tv.location === 'fireplace' && (
                      <RadioGroup
                        name={`tv-${index}-fireplace-type`}
                        label="Fireplace Type"
                        options={[
                          { value: 'drywall', label: 'Drywall' },
                          { value: 'brick', label: 'Brick/Stone' }
                        ]}
                        value={tv.fireplaceType || ''}
                        onChange={(value) => handleTvOptionChange(index, 'fireplaceType', value)}
                        error={errors[`tvOptions[${index}].fireplaceType`]}
                        isRequired
                        horizontal
                      />
                    )}
                    
                    {tv.location === 'fireplace' && (
                      <div className="md:col-span-2">
                        <label
                          htmlFor={`fireplacePhoto-${index}`}
                          className="block text-sm font-medium text-gray-700 mb-2 flex items-center"
                        >
                          <Upload size={18} className="mr-2 text-blue-500" />
                          Upload a photo of your fireplace
                        </label>
                        <div className="flex items-center mb-2 text-sm text-blue-600">
                          <Info size={16} className="mr-1" />
                          <span>
                            Uploading a picture helps us give a more accurate estimate!
                          </span>
                        </div>
                        <div
                          className={`border-2 border-dashed rounded-md p-4 text-center ${
                            errors[`tvOptions[${index}].fireplacePhoto`]
                              ? 'border-red-500'
                              : 'border-gray-300'
                          }`}
                        >
                          <input
                            type="file"
                            id={`fireplacePhoto-${index}`}
                            accept="image/*"
                            onChange={(e) => handleFireplacePhotoChange(index, e)}
                            className="hidden"
                          />
                          <label htmlFor={`fireplacePhoto-${index}`} className="cursor-pointer">
                            <div className="flex flex-col items-center justify-center py-3">
                              <Upload size={24} className="text-blue-500 mb-2" />
                              <p className="text-sm text-gray-600 mb-1">
                                {tv.fireplacePhoto
                                  ? `Selected: ${tv.fireplacePhoto.name}`
                                  : 'Click to upload or drag and drop'}
                              </p>
                              <p className="text-xs text-gray-500">
                                JPG, PNG or GIF (max. 5MB)
                              </p>
                            </div>
                          </label>
                        </div>
                      </div>
                    )}
                    
                    <Checkbox
                      label="Wire Concealment"
                      checked={tv.wireConcealment}
                      onChange={(checked) => handleTvOptionChange(index, 'wireConcealment', checked)}
                      helperText={tv.location === 'fireplace' 
                        ? "We will provide an in-person estimate for this service" 
                        : "$100 per TV"}
                    />
                    
                    <Checkbox
                      label="Soundbar Installation"
                      checked={tv.soundbarInstallation}
                      onChange={(checked) => handleTvOptionChange(index, 'soundbarInstallation', checked)}
                      helperText="$50 per TV (includes mounting with customer-provided mount)"
                    />
                  </div>
                </div>
              ))}
            </CardBody>
          </Card>
        )}

        {/* Mount Selection */}
        {hasMounts && (
          <Card elevated className="mb-8">
            <CardBody className="p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <Tv className="mr-2 text-green-600" size={24} />
                Mount Selection
              </h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                <Select
                  label="Type of Mount"
                  options={[
                    { value: 'small', label: 'Small Mount (32"-50") - $40' },
                    { value: 'medium', label: 'Medium Mount (51"-65") - $50' },
                    { value: 'large', label: 'Large Mount (66"-85") - $65' },
                    { value: 'fullMotion', label: 'Full-Motion Mount (Any size) - $80' }
                  ]}
                  value={formData.mountType}
                  onChange={(value) => handleChange('mountType', value)}
                />
                
                <Select
                  label="Number of Mounts"
                  options={[
                    { value: '0', label: 'Select quantity' },
                    { value: '1', label: '1 Mount' },
                    { value: '2', label: '2 Mounts' },
                    { value: '3', label: '3 Mounts' },
                    { value: '4', label: '4 Mounts' },
                    { value: '5', label: '5 Mounts' }
                  ]}
                  value={formData.mountCount.toString()}
                  onChange={(value) => handleChange('mountCount', parseInt(value))}
                  error={errors.mountCount}
                  isRequired
                />
              </div>
            </CardBody>
          </Card>
        )}

        {/* Additional Services */}
        {(hasWireConcealment || hasSmartFloodlight || hasSmartDoorbell) && (
          <Card elevated className="mb-8">
            <CardBody className="p-6">
              <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <Cable className="mr-2 text-purple-600" size={24} />
                Additional Services
              </h2>
              
              <div className="space-y-6">
                {hasWireConcealment && (
                  <div className="grid md:grid-cols-2 gap-6 items-center">
                    <Checkbox
                      label="Wire Concealment & Outlet Relocation"
                      checked={formData.wireConcealmentStandalone}
                      onChange={(checked) => handleChange('wireConcealmentStandalone', checked)}
                      helperText="$100 per location"
                    />
                    
                    {formData.wireConcealmentStandalone && (
                      <Select
                        options={[
                          { value: '0', label: 'Select quantity' },
                          { value: '1', label: '1 Location' },
                          { value: '2', label: '2 Locations' },
                          { value: '3', label: '3 Locations' },
                          { value: '4', label: '4 Locations' },
                          { value: '5', label: '5 Locations' }
                        ]}
                        value={formData.wireConcealmentCount.toString()}
                        onChange={(value) => handleChange('wireConcealmentCount', parseInt(value))}
                        error={errors.wireConcealmentCount}
                      />
                    )}
                  </div>
                )}

                {hasSmartFloodlight && (
                  <div className="grid md:grid-cols-2 gap-6 items-center">
                    <Checkbox
                      label="Smart Floodlight Installation"
                      checked={formData.smartFloodlight}
                      onChange={(checked) => handleChange('smartFloodlight', checked)}
                      helperText="$125 per floodlight"
                    />
                    
                    {formData.smartFloodlight && (
                      <Select
                        options={[
                          { value: '0', label: 'Select quantity' },
                          { value: '1', label: '1 Floodlight' },
                          { value: '2', label: '2 Floodlights' },
                          { value: '3', label: '3 Floodlights' },
                          { value: '4', label: '4 Floodlights' }
                        ]}
                        value={formData.smartFloodlightCount.toString()}
                        onChange={(value) => handleChange('smartFloodlightCount', parseInt(value))}
                        error={errors.smartFloodlightCount}
                      />
                    )}
                  </div>
                )}

                {hasSmartDoorbell && (
                  <div className="grid md:grid-cols-2 gap-6 items-center">
                    <Checkbox
                      label="Smart Video Doorbell Installation"
                      checked={formData.smartVideoDoorbell}
                      onChange={(checked) => handleChange('smartVideoDoorbell', checked)}
                      helperText="$85 per doorbell"
                    />
                    
                    {formData.smartVideoDoorbell && (
                      <Select
                        options={[
                          { value: '1', label: '1 Doorbell' },
                          { value: '2', label: '2 Doorbells' },
                          { value: '3', label: '3 Doorbells' }
                        ]}
                        value={formData.smartVideoDoorbellCount.toString()}
                        onChange={(value) => handleChange('smartVideoDoorbellCount', parseInt(value))}
                      />
                    )}
                  </div>
                )}
              </div>
            </CardBody>
          </Card>
        )}

        {/* Custom Installation Requests */}
        <Card elevated className="mb-8">
          <CardBody className="p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">
              Custom Installation Requests
            </h2>
            <Input
              label="Any special requirements or custom installation needs?"
              value={formData.customInstallation}
              onChange={(e) => handleChange('customInstallation', e.target.value)}
              fullWidth
              as="textarea"
              rows={4}
              placeholder="Describe any custom installation needs or special requirements..."
            />
          </CardBody>
        </Card>

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-8">
          <Button 
            type="button" 
            onClick={onBack} 
            variant="outline"
          >
            Back to Services
          </Button>
          <Button 
            type="submit" 
            variant="primary"
          >
            Continue to Schedule
          </Button>
        </div>
      </form>
    </motion.div>
  );
};

export default InstallationDetails;