import React from 'react';
import { motion } from 'framer-motion';
import { Tv, Flame, Cable, Volume2, Lightbulb, Video, Check } from 'lucide-react';
import Card, { CardBody } from '../ui/Card';
import Button from '../ui/Button';

interface Service {
  id: string;
  title: string;
  description: string;
  price: string | number;
  priceDisplay: string;
  priceNote?: string;
  category: 'mounting' | 'addon' | 'smart-home' | 'mount';
  icon: React.ElementType;
  iconBgColor: string;
  iconColor: string;
  borderColor: string;
  features: string[];
  options?: {
    id: string;
    name: string;
    price: number;
    priceDisplay: string;
  }[];
}

interface ServiceSelectionProps {
  services: Service[];
  selectedServices: string[];
  onServiceSelect: (service: Service, optionId?: string) => void;
  onContinue: () => void;
}

const ServiceSelection: React.FC<ServiceSelectionProps> = ({
  services,
  selectedServices,
  onServiceSelect,
  onContinue
}) => {
  // Check if a service is selected
  const isServiceSelected = (service: Service, optionId?: string) => {
    const serviceId = optionId ? `${service.id}-${optionId}` : service.id;
    return selectedServices.includes(serviceId);
  };

  // Group services by category
  const mountingServices = services.filter(s => s.category === 'mounting');
  const mountServices = services.filter(s => s.category === 'mount');
  const addonServices = services.filter(s => s.category === 'addon');
  const smartHomeServices = services.filter(s => s.category === 'smart-home');

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Select Your Services</h1>
        <p className="text-gray-600">
          Choose the services you need for your perfect TV installation
        </p>
      </div>

      {/* TV Mounting Services */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
          <Tv size={24} className="mr-2 text-brand-600" />
          TV Mounting Services
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          {mountingServices.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <Card 
                elevated 
                hoverEffect 
                topBorder 
                topBorderColor={service.borderColor}
                className="h-full"
              >
                <CardBody className="p-6">
                  <div className="flex items-center mb-4">
                    <div className={`${service.iconBgColor} p-3 rounded-full mr-4`}>
                      <service.icon className={service.iconColor} size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-gray-800">{service.title}</h3>
                  </div>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <div className="flex items-center justify-between mb-4">
                    <span className={`text-2xl font-bold ${service.iconColor}`}>{service.priceDisplay}</span>
                    {service.priceNote && <span className="text-sm text-gray-500">{service.priceNote}</span>}
                  </div>
                  
                  <ul className="mt-4 mb-6 space-y-2 text-sm text-gray-600">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start">
                        <span className="text-green-500 mr-2">✓</span>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  {/* Options if available */}
                  {service.options ? (
                    <div className="space-y-2 mb-6">
                      {service.options.map(option => (
                        <button
                          key={option.id}
                          onClick={() => onServiceSelect(service, option.id)}
                          className={`w-full py-2 px-4 rounded-md text-left flex justify-between items-center transition-colors duration-200 ${
                            isServiceSelected(service, option.id)
                              ? `${service.iconBgColor} ${service.iconColor} font-medium border border-current`
                              : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                          }`}
                        >
                          <span>{option.name}</span>
                          <div className="flex items-center">
                            <span className="font-medium">{option.priceDisplay}</span>
                            {isServiceSelected(service, option.id) && (
                              <Check size={18} className="ml-2" />
                            )}
                          </div>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <Button
                      onClick={() => onServiceSelect(service)}
                      variant={isServiceSelected(service) ? "outline" : "primary"}
                      fullWidth
                      className={isServiceSelected(service) ? `${service.iconColor} border-current` : ''}
                    >
                      {isServiceSelected(service) ? (
                        <span className="flex items-center justify-center">
                          <Check size={18} className="mr-2" />
                          Selected
                        </span>
                      ) : (
                        'Select Service'
                      )}
                    </Button>
                  )}
                </CardBody>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
      
      {/* TV Mounts */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
          <Tv size={24} className="mr-2 text-green-600" />
          TV Mounts
        </h2>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
        >
          {mountServices.map((service) => (
            <Card 
              key={service.id}
              elevated 
              hoverEffect 
              topBorder 
              topBorderColor={service.borderColor}
              className="mb-6"
            >
              <CardBody className="p-6">
                <div className="flex items-center mb-4">
                  <div className={`${service.iconBgColor} p-3 rounded-full mr-4`}>
                    <service.icon className={service.iconColor} size={24} />
                  </div>
                  <h3 className="text-xl font-bold text-gray-800">{service.title}</h3>
                </div>
                <p className="text-gray-600 mb-4">{service.description}</p>
                
                <ul className="mt-4 mb-6 space-y-2 text-sm text-gray-600">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start">
                      <span className="text-green-500 mr-2">✓</span>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {service.options?.map(option => (
                    <button
                      key={option.id}
                      onClick={() => onServiceSelect(service, option.id)}
                      className={`py-2 px-4 rounded-md text-left flex justify-between items-center transition-colors duration-200 ${
                        isServiceSelected(service, option.id)
                          ? `${service.iconBgColor} ${service.iconColor} font-medium border border-current`
                          : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                      }`}
                    >
                      <span>{option.name}</span>
                      <div className="flex items-center">
                        <span className="font-medium">{option.priceDisplay}</span>
                        {isServiceSelected(service, option.id) && (
                          <Check size={18} className="ml-2" />
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </CardBody>
            </Card>
          ))}
        </motion.div>
      </div>
      
      {/* Add-on Services */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
          <Cable size={24} className="mr-2 text-purple-600" />
          Add-on Services
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          {addonServices.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.3 + index * 0.1 }}
            >
              <Card 
                elevated 
                hoverEffect 
                topBorder 
                topBorderColor={service.borderColor}
                className="h-full"
              >
                <CardBody className="p-6">
                  <div className="flex items-center mb-4">
                    <div className={`${service.iconBgColor} p-3 rounded-full mr-4`}>
                      <service.icon className={service.iconColor} size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-gray-800">{service.title}</h3>
                  </div>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <div className="flex items-center justify-between mb-4">
                    <span className={`text-2xl font-bold ${service.iconColor}`}>{service.priceDisplay}</span>
                    {service.priceNote && <span className="text-sm text-gray-500">{service.priceNote}</span>}
                  </div>
                  
                  <ul className="mt-4 mb-6 space-y-2 text-sm text-gray-600">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start">
                        <span className="text-green-500 mr-2">✓</span>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button
                    onClick={() => onServiceSelect(service)}
                    variant={isServiceSelected(service) ? "outline" : "primary"}
                    fullWidth
                    className={isServiceSelected(service) ? `${service.iconColor} border-current` : ''}
                  >
                    {isServiceSelected(service) ? (
                      <span className="flex items-center justify-center">
                        <Check size={18} className="mr-2" />
                        Selected
                      </span>
                    ) : (
                      'Select Service'
                    )}
                  </Button>
                </CardBody>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
      
      {/* Smart Home Services */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
          <Lightbulb size={24} className="mr-2 text-yellow-600" />
          Smart Home Services
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          {smartHomeServices.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.4 + index * 0.1 }}
            >
              <Card 
                elevated 
                hoverEffect 
                topBorder 
                topBorderColor={service.borderColor}
                className="h-full"
              >
                <CardBody className="p-6">
                  <div className="flex items-center mb-4">
                    <div className={`${service.iconBgColor} p-3 rounded-full mr-4`}>
                      <service.icon className={service.iconColor} size={24} />
                    </div>
                    <h3 className="text-xl font-bold text-gray-800">{service.title}</h3>
                  </div>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <div className="flex items-center justify-between mb-4">
                    <span className={`text-2xl font-bold ${service.iconColor}`}>{service.priceDisplay}</span>
                    {service.priceNote && <span className="text-sm text-gray-500">{service.priceNote}</span>}
                  </div>
                  
                  <ul className="mt-4 mb-6 space-y-2 text-sm text-gray-600">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start">
                        <span className="text-green-500 mr-2">✓</span>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button
                    onClick={() => onServiceSelect(service)}
                    variant={isServiceSelected(service) ? "outline" : "primary"}
                    fullWidth
                    className={isServiceSelected(service) ? `${service.iconColor} border-current` : ''}
                  >
                    {isServiceSelected(service) ? (
                      <span className="flex items-center justify-center">
                        <Check size={18} className="mr-2" />
                        Selected
                      </span>
                    ) : (
                      'Select Service'
                    )}
                  </Button>
                </CardBody>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Continue Button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.5 }}
        className="mt-8 flex justify-center"
      >
        <Button 
          onClick={onContinue} 
          variant="primary" 
          size="lg"
          disabled={selectedServices.length === 0}
        >
          Continue to Installation Details
        </Button>
      </motion.div>
    </motion.div>
  );
};

export default ServiceSelection;