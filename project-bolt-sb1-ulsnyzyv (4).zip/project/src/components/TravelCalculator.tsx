import React, { useState, useEffect } from 'react';
import { MapPin, Clock, Car, DollarSign, Info } from 'lucide-react';

interface TravelCalculatorProps {
  onTravelFeeChange: (fee: number) => void;
}

const TravelCalculator: React.FC<TravelCalculatorProps> = ({ onTravelFeeChange }) => {
  const [address, setAddress] = useState<string>('');
  const [drivingTime, setDrivingTime] = useState<number>(0);
  const [travelFee, setTravelFee] = useState<number>(0);
  const [showDetails, setShowDetails] = useState<boolean>(false);
  const [calculationDetails, setCalculationDetails] = useState<{
    extraMinutes: number;
    extraDistance: number;
    fuelCost: number;
    laborSurcharge: number;
  }>({
    extraMinutes: 0,
    extraDistance: 0,
    fuelCost: 0,
    laborSurcharge: 0
  });

  // Constants
  const BASE_LOCATION = "4965 Flat Shoals Pkwy, Decatur, GA 30034";
  const THRESHOLD_MINUTES = 45;
  const AVG_SPEED_MPH = 40;
  const MPG = 20; // Miles per gallon for 2021 Volkswagen Atlas
  const FUEL_COST_PER_GALLON = 3;
  const LABOR_RATE_PER_MINUTE = 1.5;
  const MIN_TRAVEL_FEE = 25;

  // Simulate driving time calculation based on address input
  const simulateDrivingTime = (address: string): number => {
    if (!address.trim()) return 0;
    const addressLength = address.length;
    const randomFactor = Math.random() * 0.5 + 0.75;
    const simulatedTime = Math.floor(addressLength * 1.5 * randomFactor);
    return Math.max(10, Math.min(120, simulatedTime));
  };

  const calculateTravelFee = (minutes: number) => {
    if (minutes <= THRESHOLD_MINUTES) {
      setTravelFee(0);
      setCalculationDetails({
        extraMinutes: 0,
        extraDistance: 0,
        fuelCost: 0,
        laborSurcharge: 0
      });
      return;
    }
    const extraMinutes = minutes - THRESHOLD_MINUTES;
    const extraDistance = (extraMinutes / 60) * AVG_SPEED_MPH;
    const fuelCost = (extraDistance / MPG) * FUEL_COST_PER_GALLON;
    const laborSurcharge = extraMinutes * LABOR_RATE_PER_MINUTE;
    let calculatedFee = fuelCost + laborSurcharge;
    if (calculatedFee < MIN_TRAVEL_FEE && calculatedFee > 0) {
      calculatedFee = MIN_TRAVEL_FEE;
    }
    calculatedFee = Math.ceil(calculatedFee);
    setTravelFee(calculatedFee);
    setCalculationDetails({
      extraMinutes,
      extraDistance,
      fuelCost,
      laborSurcharge
    });
  };

  const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newAddress = e.target.value;
    setAddress(newAddress);
    const time = simulateDrivingTime(newAddress);
    setDrivingTime(time);
  };

  const handleDrivingTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseInt(e.target.value) || 0;
    setDrivingTime(time);
  };

  useEffect(() => {
    calculateTravelFee(drivingTime);
  }, [drivingTime]);

  // Notify parent when travel fee changes; dependency only on travelFee now
  useEffect(() => {
    onTravelFeeChange(travelFee);
  }, [travelFee]);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md border-t-4 border-blue-500 mb-8">
      <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
        <MapPin size={24} className="mr-2 text-blue-600" />
        Travel Information
      </h2>
      <div className="mb-4">
        <label htmlFor="address" className="block text-gray-700 font-medium mb-2 flex items-center">
          <MapPin size={18} className="mr-2 text-blue-500" />
          Your Address
        </label>
        <input
          type="text"
          id="address"
          value={address}
          onChange={handleAddressChange}
          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Enter your address"
        />
        <p className="text-sm text-gray-500 mt-1">Our base location: {BASE_LOCATION}</p>
      </div>
      <div className="mb-4">
        <label htmlFor="drivingTime" className="block text-gray-700 font-medium mb-2 flex items-center">
          <Clock size={18} className="mr-2 text-blue-500" />
          Estimated Driving Time (minutes)
        </label>
        <div className="flex items-center">
          <input
            type="number"
            id="drivingTime"
            value={drivingTime}
            onChange={handleDrivingTimeChange}
            min="0"
            max="180"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <div className="ml-2 text-gray-500">min</div>
        </div>
      </div>
      <div className={`p-4 rounded-md ${travelFee > 0 ? 'bg-amber-50 border border-amber-200' : 'bg-green-50 border border-green-200'}`}>
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Car size={20} className={travelFee > 0 ? 'text-amber-600 mr-2' : 'text-green-600 mr-2'} />
            <span className="font-medium">Travel Fee:</span>
          </div>
          <span className="text-xl font-bold">
            {travelFee > 0 ? `$${travelFee}` : 'No Fee'}
          </span>
        </div>
        {travelFee > 0 && (
          <div className="mt-2">
            <p className="text-sm text-gray-600">
              {drivingTime > THRESHOLD_MINUTES 
                ? `Your location is ${drivingTime - THRESHOLD_MINUTES} minutes beyond our standard service area.`
                : 'Your location is within our standard service area.'}
            </p>
            <button
              type="button"
              onClick={() => setShowDetails(!showDetails)}
              className="text-blue-600 text-sm mt-2 flex items-center hover:text-blue-800"
            >
              <Info size={16} className="mr-1" />
              {showDetails ? 'Hide calculation details' : 'Show calculation details'}
            </button>
            {showDetails && (
              <div className="mt-2 text-sm bg-white p-3 rounded border border-gray-200">
                <h4 className="font-medium mb-1">How we calculate travel fees:</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• Base service area: Up to {THRESHOLD_MINUTES} minutes driving time</li>
                  <li>• Extra driving time: {calculationDetails.extraMinutes.toFixed(0)} minutes</li>
                  <li>• Extra distance: {calculationDetails.extraDistance.toFixed(1)} miles</li>
                  <li>• Fuel cost: ${calculationDetails.fuelCost.toFixed(2)}</li>
                  <li>• Labor surcharge: ${calculationDetails.laborSurcharge.toFixed(2)}</li>
                  <li>• Minimum travel fee: ${MIN_TRAVEL_FEE}</li>
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default TravelCalculator;
