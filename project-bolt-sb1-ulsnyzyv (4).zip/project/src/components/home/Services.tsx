import React from 'react';
import { motion } from 'framer-motion';
import { Tv, Flame, Cable, Volume2, Lightbulb, Video, ArrowRight } from 'lucide-react';
import Card, { CardBody } from '../ui/Card';
import Button from '../ui/Button';

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  price: string;
  delay: number;
  onClick: () => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ icon, title, description, price, delay, onClick }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      viewport={{ once: true, margin: "-100px" }}
      className="h-full"
    >
      <Card elevated hoverEffect className="h-full flex flex-col">
        <CardBody className="p-6 flex flex-col h-full">
          <div className="bg-brand-100 p-3 rounded-lg w-fit mb-4">
            {icon}
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-3">{title}</h3>
          <p className="text-gray-600 mb-6 flex-grow">{description}</p>
          <div className="flex items-center justify-between mt-auto">
            <span className="text-brand-600 font-bold text-lg">{price}</span>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onClick}
              rightIcon={<ArrowRight size={16} />}
            >
              Learn More
            </Button>
          </div>
        </CardBody>
      </Card>
    </motion.div>
  );
};

interface ServicesProps {
  onServiceClick: (service: string) => void;
}

const Services: React.FC<ServicesProps> = ({ onServiceClick }) => {
  const services = [
    {
      icon: <Tv className="h-6 w-6 text-brand-600" />,
      title: 'TV Mounting',
      description: 'Professional installation on any wall type with clean cable management.',
      price: 'From $100',
      id: 'tv-mounting'
    },
    {
      icon: <Flame className="h-6 w-6 text-brand-600" />,
      title: 'Fireplace Mounting',
      description: 'Specialized mounting above fireplaces with heat protection.',
      price: 'From $200',
      id: 'fireplace-mounting'
    },
    {
      icon: <Cable className="h-6 w-6 text-brand-600" />,
      title: 'Wire Concealment',
      description: 'Hide all cables inside your wall for a clean, professional look.',
      price: '$100 per location',
      id: 'wire-concealment'
    },
    {
      icon: <Volume2 className="h-6 w-6 text-brand-600" />,
      title: 'Soundbar Installation',
      description: 'Mount and connect your soundbar for optimal audio performance.',
      price: '$50 per soundbar',
      id: 'soundbar-installation'
    },
    {
      icon: <Lightbulb className="h-6 w-6 text-brand-600" />,
      title: 'Smart Lighting',
      description: 'Installation of smart floodlights and lighting systems.',
      price: '$125 per light',
      id: 'smart-lighting'
    },
    {
      icon: <Video className="h-6 w-6 text-brand-600" />,
      title: 'Video Doorbell',
      description: 'Professional installation of smart video doorbells.',
      price: '$85 per doorbell',
      id: 'video-doorbell'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2 
            className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            Our Professional Services
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-600 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            Expert installation services to enhance your home entertainment experience
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={service.id}
              icon={service.icon}
              title={service.title}
              description={service.description}
              price={service.price}
              delay={index * 0.1}
              onClick={() => onServiceClick(service.id)}
            />
          ))}
        </div>

        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          viewport={{ once: true }}
        >
          <Button 
            variant="primary" 
            size="lg" 
            onClick={() => onServiceClick('all')}
            rightIcon={<ArrowRight size={18} />}
          >
            View All Services & Pricing
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;