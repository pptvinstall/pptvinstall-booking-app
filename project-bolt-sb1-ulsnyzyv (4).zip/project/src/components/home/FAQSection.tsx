import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface FAQ {
  question: string;
  answer: string;
}

const faqs: FAQ[] = [
  {
    question: "How long does a typical TV installation take?",
    answer: "Most standard TV installations take between 1-2 hours. Fireplace mountings or installations requiring wire concealment may take 2-3 hours. We'll provide a more specific timeframe when you book your appointment."
  },
  {
    question: "Do you provide the TV mount or do I need to purchase one?",
    answer: "We offer a variety of TV mounts that you can purchase directly from us, ranging from fixed to full-motion options for different TV sizes. You're also welcome to provide your own mount if you prefer."
  },
  {
    question: "Can you mount a TV above a fireplace?",
    answer: "Yes, we specialize in fireplace TV mounting for both brick/stone and drywall fireplaces. We take extra precautions to ensure proper heat protection and optimal viewing angles."
  },
  {
    question: "How do you hide the wires?",
    answer: "We offer professional wire concealment services where we run the cables through your wall, creating a clean, wire-free look. This involves creating small, neat holes behind your TV and near your outlets, then fishing the cables through the wall."
  },
  {
    question: "What areas do you service?",
    answer: "We service the greater Atlanta area, including Decatur, Brookhaven, Sandy Springs, Dunwoody, Marietta, and surrounding communities. A travel fee may apply for locations beyond our standard service area."
  },
  {
    question: "Do you offer a warranty on your installations?",
    answer: "Yes, all of our installations come with a 1-year warranty covering any issues related to our workmanship. This includes remounting if the TV becomes unlevel or if there are any issues with our wire concealment work."
  }
];

const FAQItem: React.FC<{ faq: FAQ; index: number }> = ({ faq, index }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.div 
      className="border-b border-gray-200 py-4"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true, margin: "-100px" }}
    >
      <button
        className="flex justify-between items-center w-full text-left focus:outline-none"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
      >
        <h3 className="text-lg font-medium text-gray-900">{faq.question}</h3>
        <span className="ml-6 flex-shrink-0">
          {isOpen ? (
            <ChevronUp className="h-5 w-5 text-brand-600" />
          ) : (
            <ChevronDown className="h-5 w-5 text-gray-500" />
          )}
        </span>
      </button>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
          className="mt-2 pr-12"
        >
          <p className="text-gray-600">{faq.answer}</p>
        </motion.div>
      )}
    </motion.div>
  );
};

const FAQSection: React.FC = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2 
            className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            Frequently Asked Questions
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-600 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            Find answers to common questions about our TV installation services
          </motion.p>
        </div>

        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <FAQItem key={index} faq={faq} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQSection;