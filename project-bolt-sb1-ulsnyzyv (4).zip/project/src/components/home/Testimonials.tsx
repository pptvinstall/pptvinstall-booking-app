import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import Card, { CardBody } from '../ui/Card';

interface Testimonial {
  id: string;
  name: string;
  location: string;
  rating: number;
  text: string;
  service: string;
  date: string;
}

const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Michael Johnson',
    location: 'Decatur, GA',
    rating: 5,
    text: 'The team at Picture Perfect did an amazing job mounting my 65" TV above the fireplace. They concealed all the wires and even helped set up my soundbar. Very professional and clean work!',
    service: 'Fireplace TV Mounting',
    date: '2 weeks ago'
  },
  {
    id: '2',
    name: 'Sarah Williams',
    location: 'Atlanta, GA',
    rating: 5,
    text: 'I had three TVs mounted in different rooms and they did a fantastic job with all of them. The technician was on time, professional, and made sure everything was perfect before leaving.',
    service: 'Multiple TV Installation',
    date: '1 month ago'
  },
  {
    id: '3',
    name: 'David Thompson',
    location: 'Brookhaven, GA',
    rating: 5,
    text: 'Great experience from start to finish. They mounted my TV and soundbar, concealed all wires, and even programmed my remote. The price was exactly as quoted with no surprises.',
    service: 'TV & Soundbar Installation',
    date: '3 weeks ago'
  },
  {
    id: '4',
    name: 'Jennifer Martinez',
    location: 'Sandy Springs, GA',
    rating: 5,
    text: 'They installed my video doorbell and smart floodlights. Everything works perfectly and they took the time to show me how to use the app. Highly recommend their smart home services!',
    service: 'Smart Home Installation',
    date: '2 months ago'
  },
  {
    id: '5',
    name: 'Robert Wilson',
    location: 'Marietta, GA',
    rating: 4,
    text: 'Very satisfied with my TV mounting service. The technician was knowledgeable and efficient. The only reason for 4 stars instead of 5 is they arrived a bit later than scheduled, but they did call ahead to let me know.',
    service: 'TV Mounting',
    date: '1 month ago'
  },
  {
    id: '6',
    name: 'Amanda Clark',
    location: 'Dunwoody, GA',
    rating: 5,
    text: 'I had them mount a TV in my bedroom and conceal all the wires. The work was impeccable and they cleaned up everything afterward. Will definitely use them again for my living room TV.',
    service: 'TV Mounting & Wire Concealment',
    date: '2 weeks ago'
  }
];

const TestimonialCard: React.FC<{ testimonial: Testimonial }> = ({ testimonial }) => {
  return (
    <Card elevated className="h-full">
      <CardBody className="flex flex-col h-full p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="font-bold text-gray-900">{testimonial.name}</h3>
            <p className="text-gray-500 text-sm">{testimonial.location}</p>
          </div>
          <div className="flex text-yellow-400">
            {[...Array(5)].map((_, i) => (
              <Star 
                key={i} 
                size={16} 
                fill={i < testimonial.rating ? "currentColor" : "none"} 
                className={i < testimonial.rating ? "" : "text-gray-300"}
              />
            ))}
          </div>
        </div>
        
        <div className="relative mb-4 flex-grow">
          <Quote className="absolute -top-2 -left-2 h-8 w-8 text-brand-100 opacity-50 transform -scale-x-100" />
          <p className="text-gray-600 relative z-10 pl-4">{testimonial.text}</p>
        </div>
        
        <div className="mt-auto pt-4 border-t border-gray-100 flex justify-between items-center">
          <span className="text-brand-600 text-sm font-medium">{testimonial.service}</span>
          <span className="text-gray-400 text-xs">{testimonial.date}</span>
        </div>
      </CardBody>
    </Card>
  );
};

const Testimonials: React.FC = () => {
  const [currentPage, setCurrentPage] = useState(0);
  const testimonialsPerPage = 3;
  const totalPages = Math.ceil(testimonials.length / testimonialsPerPage);

  const nextPage = () => {
    setCurrentPage((prev) => (prev + 1) % totalPages);
  };

  const prevPage = () => {
    setCurrentPage((prev) => (prev - 1 + totalPages) % totalPages);
  };

  const currentTestimonials = testimonials.slice(
    currentPage * testimonialsPerPage,
    (currentPage + 1) * testimonialsPerPage
  );

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2 
            className="text-3xl md:text-4xl font-bold text-gray-900 mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            What Our Customers Say
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-600 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            Don't just take our word for it — hear from our satisfied customers
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {currentTestimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true, margin: "-100px" }}
              className="h-full"
            >
              <TestimonialCard testimonial={testimonial} />
            </motion.div>
          ))}
        </div>

        <div className="flex justify-center items-center mt-12 space-x-4">
          <button
            onClick={prevPage}
            className="p-3 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors focus:outline-none focus:ring-2 focus:ring-brand-500"
            aria-label="Previous testimonials"
          >
            <ChevronLeft size={20} className="text-gray-600" />
          </button>
          
          <div className="flex space-x-3">
            {[...Array(totalPages)].map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentPage(i)}
                className={`w-3 h-3 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500 ${
                  i === currentPage ? 'bg-brand-600' : 'bg-gray-300 hover:bg-gray-400'
                }`}
                aria-label={`Go to page ${i + 1}`}
                aria-current={i === currentPage ? 'page' : undefined}
              />
            ))}
          </div>
          
          <button
            onClick={nextPage}
            className="p-3 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors focus:outline-none focus:ring-2 focus:ring-brand-500"
            aria-label="Next testimonials"
          >
            <ChevronRight size={20} className="text-gray-600" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;