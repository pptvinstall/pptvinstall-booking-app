import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Star, Shield, Clock } from 'lucide-react';
import Button from '../ui/Button';

interface HeroProps {
  onGetStarted: () => void;
}

const Hero: React.FC<HeroProps> = ({ onGetStarted }) => {
  return (
    <div className="relative bg-gradient-to-b from-gray-50 to-white overflow-hidden">
      <div className="container mx-auto px-4 py-20 md:py-28">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-xl"
          >
            <h1 className="text-4xl md:text-5xl font-display font-bold text-gray-900 leading-tight mb-6">
              Professional TV Installation <span className="text-brand-600">Done Right</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-lg">
              Expert TV mounting and home entertainment setup services in Atlanta. Clean, professional installations with no visible wires.
            </p>
            
            <div className="flex flex-wrap gap-6 mb-10">
              <div className="flex items-center">
                <div className="bg-brand-100 p-2 rounded-full mr-3">
                  <Star className="h-5 w-5 text-brand-600" />
                </div>
                <span className="text-gray-700 font-medium">5-Star Service</span>
              </div>
              <div className="flex items-center">
                <div className="bg-brand-100 p-2 rounded-full mr-3">
                  <Shield className="h-5 w-5 text-brand-600" />
                </div>
                <span className="text-gray-700 font-medium">Satisfaction Guaranteed</span>
              </div>
              <div className="flex items-center">
                <div className="bg-brand-100 p-2 rounded-full mr-3">
                  <Clock className="h-5 w-5 text-brand-600" />
                </div>
                <span className="text-gray-700 font-medium">Same-Week Appointments</span>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={onGetStarted} 
                variant="primary" 
                size="lg"
                rightIcon={<ArrowRight size={18} />}
              >
                Get Started
              </Button>
              <Button 
                onClick={() => window.location.href = 'tel:+14045551234'} 
                variant="outline" 
                size="lg"
              >
                Call (404) 555-1234
              </Button>
            </div>
          </motion.div>
          
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="relative"
          >
            <div className="relative rounded-lg overflow-hidden shadow-elevation-4">
              <img
                src="https://images.unsplash.com/photo-1593784991095-a205069470b6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1050&q=80"
                alt="Professional TV installation"
                className="w-full h-auto object-cover rounded-lg aspect-[4/3]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900/50 to-transparent"></div>
              <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-sm p-4 rounded-lg shadow-lg">
                <div className="flex items-center">
                  <div className="flex text-yellow-400 mr-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} size={16} fill="currentColor" />
                    ))}
                  </div>
                  <span className="text-gray-800 font-medium">500+ 5-star reviews</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Hero;