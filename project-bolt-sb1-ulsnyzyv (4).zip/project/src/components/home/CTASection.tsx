import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Calendar, Phone } from 'lucide-react';
import Button from '../ui/Button';

interface CTASectionProps {
  onBookNow: () => void;
}

const CTASection: React.FC<CTASectionProps> = ({ onBookNow }) => {
  return (
    <section className="py-20 bg-brand-600">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h2 
            className="text-3xl md:text-4xl font-bold text-white mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            Ready for a Professional TV Installation?
          </motion.h2>
          <motion.p 
            className="text-xl text-brand-100 mb-10"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            Book your appointment today and enjoy a perfectly mounted TV with no visible wires
          </motion.p>
          
          <motion.div 
            className="flex flex-col sm:flex-row justify-center gap-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <Button 
              onClick={onBookNow} 
              variant="primary" 
              size="lg"
              className="bg-white text-brand-600 hover:bg-brand-50"
              leftIcon={<Calendar size={18} />}
            >
              Book Now
            </Button>
            <Button 
              onClick={() => window.location.href = 'tel:+14045551234'} 
              variant="outline" 
              size="lg"
              className="border-white text-white hover:bg-brand-700"
              leftIcon={<Phone size={18} />}
            >
              Call (404) 555-1234
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;