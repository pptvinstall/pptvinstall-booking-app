className={`font-medium px-3 py-2 rounded-md ${
                      currentPage === 'faq'
                        ? 'text-brand-600 bg-brand-50'
                        : 'text-gray-700 hover:text-brand-600 hover:bg-gray-50'
                    }`}
                  >
                    FAQ
                  </a>
                  <div className="flex items-center space-x-2 pt-2 px-3">
                    <a
                      href="tel:+14045551234"
                      className="flex items-center text-brand-600 font-medium"
                    >
                      <Phone size={18} className="mr-2" />
                      (404) 555-1234
                    </a>
                  </div>
                  <Button
                    onClick={() => handleNavigate('booking')}
                    variant="primary"
                    size="lg"
                    fullWidth
                    className="mt-2"
                  >
                    Book Now
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </header>
      {/* Spacer to prevent content from being hidden under the fixed header */}
      <div className="h-16"></div>
    </>
  );
};

export default Header;