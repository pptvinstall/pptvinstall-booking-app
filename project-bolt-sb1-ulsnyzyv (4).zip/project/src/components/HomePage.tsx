import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import Hero from './home/Hero';
import Services from './home/Services';
import Testimonials from './home/Testimonials';
import FAQSection from './home/FAQSection';
import CTASection from './home/CTASection';
import PriceCalculator, { PriceItem } from './ui/PriceCalculator';
import Card, { CardBody } from './ui/Card';
import Button from './ui/Button';
import { motion, AnimatePresence } from 'framer-motion';

interface HomePageProps {
  onGetQuote: () => void;
}

function HomePage({ onGetQuote }: HomePageProps) {
  const [showQuickQuote, setShowQuickQuote] = useState(false);
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [travelFee, setTravelFee] = useState(0);
  const [zipCode, setZipCode] = useState('');
  const [zipCodeError, setZipCodeError] = useState('');
  
  // Quick quote service options
  const quickQuoteOptions = [
    {
      id: 'basic-tv-mounting',
      name: 'Basic TV Mounting',
      price: 100,
      category: 'TV Mounting',
      description: 'Standard installation on drywall'
    },
    {
      id: 'fireplace-mounting',
      name: 'Fireplace Mounting',
      price: 200,
      category: 'TV Mounting',
      description: 'Specialized mounting above fireplaces'
    },
    {
      id: 'wire-concealment',
      name: 'Wire Concealment',
      price: 100,
      category: 'Add-ons',
      description: 'Hide all cables inside your wall'
    },
    {
      id: 'soundbar-installation',
      name: 'Soundbar Installation',
      price: 50,
      category: 'Add-ons',
      description: 'Mount and connect your soundbar'
    },
    {
      id: 'smart-home-setup',
      name: 'Smart Home Setup',
      price: 85,
      category: 'Smart Home',
      description: 'Setup and configuration of smart devices'
    }
  ];
  
  // Convert selected services to price items
  const getPriceItems = (): PriceItem[] => {
    return selectedServices.map(id => {
      const service = quickQuoteOptions.find(option => option.id === id);
      return {
        id,
        name: service?.name || '',
        price: service?.price || 0,
        quantity: 1,
        category: service?.category
      };
    });
  };
  
  // Handle service selection
  const handleServiceSelect = (id: string) => {
    setSelectedServices(prev => {
      if (prev.includes(id)) {
        return prev.filter(serviceId => serviceId !== id);
      } else {
        return [...prev, id];
      }
    });
  };
  
  // Handle travel fee change
  const handleZipCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setZipCode(value);
    
    // Validate zip code
    if (value && !/^\d{5}(-\d{4})?$/.test(value)) {
      setZipCodeError('Please enter a valid zip code');
    } else {
      setZipCodeError('');
      calculateTravelFee(value);
    }
  };
  
  const calculateTravelFee = (zipCode: string) => {
    // Simple simulation based on zip code
    if (!zipCode) {
      setTravelFee(0);
      return;
    }
    
    const zipNum = parseInt(zipCode);
    if (isNaN(zipNum)) {
      setTravelFee(0);
      return;
    }
    
    // Generate a travel fee based on zip code
    // This is just for demonstration
    if (zipNum >= 30000 && zipNum < 30100) {
      setTravelFee(0); // No fee for local area
    } else if (zipNum >= 30100 && zipNum < 30200) {
      setTravelFee(25); // $25 fee for nearby areas
    } else {
      setTravelFee(50); // $50 fee for further areas
    }
  };
  
  // Handle get quote button click
  const handleGetQuote = () => {
    if (showQuickQuote) {
      onGetQuote();
    } else {
      setShowQuickQuote(true);
    }
  };

  // Group services by category
  const groupedServices = quickQuoteOptions.reduce((acc, service) => {
    if (!acc[service.category]) {
      acc[service.category] = [];
    }
    acc[service.category].push(service);
    return acc;
  }, {} as Record<string, typeof quickQuoteOptions>);

  return (
    <>
      {/* Hero Section */}
      <Hero onGetStarted={handleGetQuote} />
      
      {/* Quick Quote Calculator */}
      <AnimatePresence>
        {showQuickQuote && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
            className="container mx-auto px-4 py-16"
          >
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-10">
                <h2 className="text-3xl font-bold text-gray-900 mb-3">Get a Quick Quote</h2>
                <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                  Select the services you're interested in to see an estimated price
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-2">
                  <Card elevated>
                    <CardBody className="p-6">
                      {/* Service Selection */}
                      {Object.entries(groupedServices).map(([category, services]) => (
                        <div key={category} className="mb-8 last:mb-0">
                          <h3 className="text-lg font-bold text-gray-800 mb-4">{category}</h3>
                          <div className="space-y-3">
                            {services.map(option => (
                              <div 
                                key={option.id}
                                className={`p-4 rounded-lg border cursor-pointer transition-all duration-200 ${
                                  selectedServices.includes(option.id)
                                    ? 'border-brand-500 bg-brand-50 shadow-sm'
                                    : 'border-gray-200 hover:border-brand-300 hover:bg-gray-50'
                                }`}
                                onClick={() => handleServiceSelect(option.id)}
                              >
                                <div className="flex justify-between items-center mb-1">
                                  <span className="font-medium text-gray-800">{option.name}</span>
                                  <span className="text-brand-600 font-bold">${option.price}</span>
                                </div>
                                <p className="text-sm text-gray-500">{option.description}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                      
                      {/* Zip Code for Travel Fee */}
                      <div className="mb-6 pt-6 border-t border-gray-200">
                        <h3 className="text-lg font-bold text-gray-800 mb-4">Your Location</h3>
                        <div className="flex items-start flex-col sm:flex-row sm:items-center gap-4">
                          <div className="w-full max-w-xs">
                            <label htmlFor="zipCode" className="block text-sm font-medium text-gray-700 mb-1">
                              Zip Code
                            </label>
                            <input
                              type="text"
                              id="zipCode"
                              value={zipCode}
                              onChange={handleZipCodeChange}
                              className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-brand-500 ${
                                zipCodeError ? 'border-red-300' : 'border-gray-300'
                              }`}
                              placeholder="Enter your zip code"
                            />
                            {zipCodeError && (
                              <p className="mt-1 text-sm text-red-600">{zipCodeError}</p>
                            )}
                          </div>
                          
                          {travelFee > 0 && (
                            <div className="flex items-center bg-amber-50 px-4 py-2 rounded-md border border-amber-200">
                              <span className="text-amber-700">Travel Fee: ${travelFee}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {/* Continue Button */}
                      <div className="mt-8">
                        <Button
                          onClick={onGetQuote}
                          variant="primary" 
                          size="lg"
                          fullWidth
                          rightIcon={<ArrowRight size={18} />}
                          disabled={selectedServices.length === 0}
                        >
                          Continue to Booking
                        </Button>
                      </div>
                    </CardBody>
                  </Card>
                </div>
                
                {/* Price Calculator */}
                <div>
                  <PriceCalculator
                    items={getPriceItems()}
                    travelFee={travelFee}
                    tax={getPriceItems().reduce((sum, item) => sum + item.price, 0) * 0.07}
                    taxRate={0.07}
                    showDetails={true}
                    isSticky={true}
                  />
                  
                  {selectedServices.length === 0 && (
                    <div className="mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200 text-center">
                      <p className="text-gray-600">Select services to see pricing</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Services Section */}
      <Services onServiceClick={() => onGetQuote()} />
      
      {/* Testimonials Section */}
      <Testimonials />
      
      {/* FAQ Section */}
      <FAQSection />
      
      {/* CTA Section */}
      <CTASection onBookNow={onGetQuote} />
    </>
  );
}

export default HomePage;