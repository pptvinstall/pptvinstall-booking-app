import React, { useState, useEffect } from 'react';
import BookingSteps from './booking/BookingSteps';
import ServiceSelection from './booking/ServiceSelection';
import InstallationDetails from './booking/InstallationDetails';
import ScheduleForm from './booking/ScheduleForm';
import ReviewBooking from './booking/ReviewBooking';
import BookingConfirmation from './booking/BookingConfirmation';
import UserAccount from './booking/UserAccount';
import TravelCalculator from './TravelCalculator';
import PriceCalculator from './ui/PriceCalculator';
import FloatingPriceBar from './ui/FloatingPriceBar';
import usePriceCalculator from '../hooks/usePriceCalculator';
import { Tv, Flame, Cable, Volume2, Lightbulb, Video } from 'lucide-react';

// Define service type for passing between components
interface ServiceOption {
  id: string;
  title: string;
  description: string;
  price: number | string;
  priceDisplay: string;
  priceNote?: string;
  category: 'mounting' | 'addon' | 'smart-home' | 'mount';
  icon: React.ElementType;
  iconBgColor: string;
  iconColor: string;
  borderColor: string;
  features: string[];
  options?: {
    id: string;
    name: string;
    price: number;
    priceDisplay: string;
  }[];
}

// Define TV mounting option type
interface TvMountingOption {
  location: 'wall' | 'fireplace';
  fireplaceType?: 'brick' | 'drywall';
  fireplacePhoto?: File | null;
  wireConcealment: boolean;
  soundbarInstallation: boolean;
}

// Define installation details form data type
interface InstallationDetailsFormData {
  // TV Mounting Options
  includeTvMounting: boolean;
  tvOptions: TvMountingOption[];
  // Mount Selection
  needsMounts: boolean;
  mountType: string;
  mountCount: number;
  // Additional Services
  wireConcealmentStandalone: boolean;
  wireConcealmentCount: number;
  smartFloodlight: boolean;
  smartFloodlightCount: number;
  smartVideoDoorbell: boolean;
  smartVideoDoorbellCount: number;
  customInstallation: string;
}

// Define schedule form data type
interface ScheduleFormData {
  date: Date | null;
  timeSlot: string;
  fullName: string;
  email: string;
  phone: string;
  preferredTechnician: string;
  specialRequests: string;
  sendReminders: boolean;
  reminderMethod: 'email' | 'sms' | 'both';
}

// Define service summary type
interface ServiceSummary {
  name: string;
  price: number;
  quantity: number;
}

function BookingPage() {
  // Define booking steps
  const STEPS = {
    SERVICES: 'services',
    DETAILS: 'details',
    SCHEDULE: 'schedule',
    REVIEW: 'review',
    CONFIRMATION: 'confirmation',
    ACCOUNT: 'account'
  };

  // State for current step
  const [currentStep, setCurrentStep] = useState(STEPS.SERVICES);
  
  // State for selected services
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  
  // State for installation details
  const initialTvOption: TvMountingOption = {
    location: 'wall',
    wireConcealment: false,
    soundbarInstallation: false,
  };

  const initialInstallationDetails: InstallationDetailsFormData = {
    includeTvMounting: true,
    tvOptions: [{ ...initialTvOption }],
    needsMounts: false,
    mountType: 'small',
    mountCount: 0,
    wireConcealmentStandalone: false,
    wireConcealmentCount: 0,
    smartFloodlight: false,
    smartFloodlightCount: 0,
    smartVideoDoorbell: false,
    smartVideoDoorbellCount: 1,
    customInstallation: '',
  };

  const [installationDetails, setInstallationDetails] = useState<InstallationDetailsFormData>(initialInstallationDetails);
  
  // State for schedule form data
  const initialScheduleData: ScheduleFormData = {
    date: null,
    timeSlot: '',
    fullName: '',
    email: '',
    phone: '',
    preferredTechnician: '',
    specialRequests: '',
    sendReminders: true,
    reminderMethod: 'both',
  };

  const [scheduleData, setScheduleData] = useState<ScheduleFormData>(initialScheduleData);
  
  // State for travel fee
  const [travelFee, setTravelFee] = useState(0);
  
  // State for booking ID
  const [bookingId, setBookingId] = useState('');
  
  // State for price calculator details visibility
  const [showPriceDetails, setShowPriceDetails] = useState(false);

  // Available services
  const services: ServiceOption[] = [
    {
      id: 'basic-mounting',
      title: 'Basic TV Mounting',
      description: 'Standard installation on drywall with customer-provided mount',
      price: 100,
      priceDisplay: '$100',
      priceNote: 'Per TV',
      category: 'mounting',
      icon: Tv,
      iconBgColor: 'bg-blue-100',
      iconColor: 'text-blue-600',
      borderColor: 'border-blue-500',
      features: [
        'Professional installation',
        'Level mounting',
        'Basic cable management',
        'Hardware included'
      ]
    },
    {
      id: 'fireplace-mounting',
      title: 'Fireplace Mounting',
      description: 'Specialized mounting above fireplaces',
      price: 'varies',
      priceDisplay: 'From $200',
      category: 'mounting',
      icon: Flame,
      iconBgColor: 'bg-orange-100',
      iconColor: 'text-orange-600',
      borderColor: 'border-orange-500',
      features: [
        'Heat-resistant installation',
        'Special mounting hardware',
        'Optimal viewing angle'
      ],
      options: [
        {
          id: 'drywall',
          name: 'Drywall Fireplace',
          price: 200,
          priceDisplay: '$200'
        },
        {
          id: 'brick',
          name: 'Brick/Stone Fireplace',
          price: 250,
          priceDisplay: '$250'
        }
      ]
    },
    {
      id: 'tv-mounts',
      title: 'TV Mounts',
      description: 'High-quality mounts for any TV size',
      price: 'varies',
      priceDisplay: 'From $40',
      category: 'mount',
      icon: Tv,
      iconBgColor: 'bg-green-100',
      iconColor: 'text-green-600',
      borderColor: 'border-green-500',
      features: [
        'Various sizes available',
        'Full-motion options',
        'Weight-rated for safety',
        'Installation included with TV mounting'
      ],
      options: [
        {
          id: 'small',
          name: 'Small Mount (32"-50")',
          price: 40,
          priceDisplay: '$40'
        },
        {
          id: 'medium',
          name: 'Medium Mount (51"-65")',
          price: 50,
          priceDisplay: '$50'
        },
        {
          id: 'large',
          name: 'Large Mount (66"-85")',
          price: 65,
          priceDisplay: '$65'
        },
        {
          id: 'fullMotion',
          name: 'Full-Motion Mount (Any size)',
          price: 80,
          priceDisplay: '$80'
        }
      ]
    },
    {
      id: 'wire-concealment',
      title: 'Wire Concealment & Outlet',
      description: 'Clean, professional wire management and power solutions',
      price: 100,
      priceDisplay: '$100',
      priceNote: 'Per location',
      category: 'addon',
      icon: Cable,
      iconBgColor: 'bg-purple-100',
      iconColor: 'text-purple-600',
      borderColor: 'border-purple-500',
      features: [
        'In-wall cable routing',
        'Power outlet installation',
        'Clean, professional finish',
        'Works with any mounted TV'
      ]
    },
    {
      id: 'soundbar-installation',
      title: 'Soundbar Installation',
      description: 'Professional soundbar mounting and setup',
      price: 50,
      priceDisplay: '$50',
      priceNote: 'Per soundbar',
      category: 'addon',
      icon: Volume2,
      iconBgColor: 'bg-indigo-100',
      iconColor: 'text-indigo-600',
      borderColor: 'border-indigo-500',
      features: [
        'Secure mounting',
        'Cable management',
        'Basic audio setup',
        'Mount included with customer-provided soundbar'
      ]
    },
    {
      id: 'smart-floodlight',
      title: 'Smart Floodlight Installation',
      description: 'Professional installation of smart floodlights',
      price: 125,
      priceDisplay: '$125',
      priceNote: 'Per floodlight',
      category: 'smart-home',
      icon: Lightbulb,
      iconBgColor: 'bg-yellow-100',
      iconColor: 'text-yellow-600',
      borderColor: 'border-yellow-500',
      features: [
        'Secure mounting',
        'Wiring installation',
        'App setup assistance',
        'Works with existing wiring or wireless options'
      ]
    },
    {
      id: 'smart-doorbell',
      title: 'Smart Video Doorbell',
      description: 'Professional installation of video doorbells',
      price: 85,
      priceDisplay: '$85',
      priceNote: 'Per doorbell',
      category: 'smart-home',
      icon: Video,
      iconBgColor: 'bg-red-100',
      iconColor: 'text-red-600',
      borderColor: 'border-red-500',
      features: [
        'Secure mounting',
        'Wiring setup',
        'App configuration',
        'Testing and demonstration'
      ]
    }
  ];

  // Use price calculator hook
  const {
    priceItems,
    discounts,
    tax,
    taxRate,
    totalPrice
  } = usePriceCalculator(selectedServices, services, travelFee, {
    applyDiscounts: true,
    applyTax: true,
    taxRate: 0.07 // 7% tax rate
  });

  // Handle service selection
  const handleServiceSelect = (service: ServiceOption, optionId?: string) => {
    const serviceId = optionId ? `${service.id}-${optionId}` : service.id;
    
    setSelectedServices(prev => {
      if (prev.includes(serviceId)) {
        return prev.filter(id => id !== serviceId);
      } else {
        return [...prev, serviceId];
      }
    });
  };

  // Handle installation details update
  const handleInstallationDetailsChange = (data: InstallationDetailsFormData) => {
    setInstallationDetails(data);
  };

  // Handle schedule form update
  const handleScheduleFormChange = (data: ScheduleFormData) => {
    setScheduleData(data);
  };

  // Handle travel fee update
  const handleTravelFeeChange = (fee: number) => {
    setTravelFee(fee);
  };

  // Handle booking confirmation
  const handleConfirmBooking = () => {
    // Generate a random booking ID
    const newBookingId = `BK${Math.floor(10000 + Math.random() * 90000)}`;
    setBookingId(newBookingId);
    
    // Move to confirmation step
    setCurrentStep(STEPS.CONFIRMATION);
  };

  // Handle navigation between steps
  const navigateToStep = (step: string) => {
    setCurrentStep(step);
  };

  // Handle editing a specific section
  const handleEditSection = (section: 'services' | 'details' | 'schedule') => {
    switch (section) {
      case 'services':
        setCurrentStep(STEPS.SERVICES);
        break;
      case 'details':
        setCurrentStep(STEPS.DETAILS);
        break;
      case 'schedule':
        setCurrentStep(STEPS.SCHEDULE);
        break;
    }
  };

  // Handle booking another service
  const handleBookAnother = () => {
    // Reset form data
    setSelectedServices([]);
    setInstallationDetails(initialInstallationDetails);
    setScheduleData(initialScheduleData);
    setTravelFee(0);
    
    // Navigate to services step
    setCurrentStep(STEPS.SERVICES);
  };

  // Handle view account
  const handleViewAccount = () => {
    setCurrentStep(STEPS.ACCOUNT);
  };

  // Handle logout
  const handleLogout = () => {
    // Reset form data
    setSelectedServices([]);
    setInstallationDetails(initialInstallationDetails);
    setScheduleData(initialScheduleData);
    setTravelFee(0);
    
    // Navigate to services step
    setCurrentStep(STEPS.SERVICES);
  };

  // Get time slot display
  const getTimeSlotDisplay = (): string => {
    if (!scheduleData.timeSlot) return '';
    
    // Extract time from the time slot ID (format: yyyy-MM-dd-HH)
    const hour = parseInt(scheduleData.timeSlot.split('-')[3]);
    return `${hour % 12 || 12}:00 ${hour < 12 ? 'AM' : 'PM'}`;
  };

  // Get service names for confirmation
  const getServiceNames = (): string[] => {
    return priceItems.map(item => 
      item.quantity > 1 
        ? `${item.name} (x${item.quantity})` 
        : item.name
    );
  };

  // Determine if floating price bar should be visible
  const shouldShowFloatingBar = selectedServices.length > 0 && 
                               currentStep !== STEPS.CONFIRMATION && 
                               currentStep !== STEPS.ACCOUNT;

  // Get continue text based on current step
  const getContinueText = () => {
    switch (currentStep) {
      case STEPS.SERVICES:
        return 'Continue to Details';
      case STEPS.DETAILS:
        return 'Continue to Schedule';
      case STEPS.SCHEDULE:
        return 'Review Booking';
      case STEPS.REVIEW:
        return 'Confirm Booking';
      default:
        return 'Continue';
    }
  };

  // Handle continue button click in floating bar
  const handleFloatingBarContinue = () => {
    switch (currentStep) {
      case STEPS.SERVICES:
        navigateToStep(STEPS.DETAILS);
        break;
      case STEPS.DETAILS:
        navigateToStep(STEPS.SCHEDULE);
        break;
      case STEPS.SCHEDULE:
        navigateToStep(STEPS.REVIEW);
        break;
      case STEPS.REVIEW:
        handleConfirmBooking();
        break;
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* Show booking steps for main booking flow */}
      {currentStep !== STEPS.CONFIRMATION && currentStep !== STEPS.ACCOUNT && (
        <BookingSteps currentStep={currentStep} />
      )}
      
      {/* Service Selection Step */}
      {currentStep === STEPS.SERVICES && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <ServiceSelection
              services={services}
              selectedServices={selectedServices}
              onServiceSelect={handleServiceSelect}
              onContinue={() => navigateToStep(STEPS.DETAILS)}
            />
            
            {/* Travel Calculator */}
            <TravelCalculator onTravelFeeChange={handleTravelFeeChange} />
          </div>
          
          {/* Price Calculator (Desktop) */}
          <div className="hidden md:block">
            {selectedServices.length > 0 && (
              <PriceCalculator
                items={priceItems}
                travelFee={travelFee}
                tax={tax}
                taxRate={taxRate}
                discounts={discounts}
                showDetails={true}
                isSticky={true}
              />
            )}
          </div>
        </div>
      )}
      
      {/* Installation Details Step */}
      {currentStep === STEPS.DETAILS && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <InstallationDetails
              formData={installationDetails}
              onChange={handleInstallationDetailsChange}
              onBack={() => navigateToStep(STEPS.SERVICES)}
              onContinue={() => navigateToStep(STEPS.SCHEDULE)}
              selectedServices={selectedServices}
            />
          </div>
          
          {/* Price Calculator (Desktop) */}
          <div className="hidden md:block">
            <PriceCalculator
              items={priceItems}
              travelFee={travelFee}
              tax={tax}
              taxRate={taxRate}
              discounts={discounts}
              showDetails={true}
              isSticky={true}
            />
          </div>
        </div>
      )}
      
      {/* Schedule Step */}
      {currentStep === STEPS.SCHEDULE && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <ScheduleForm
              initialData={scheduleData}
              onBack={() => navigateToStep(STEPS.DETAILS)}
              onContinue={(data) => {
                setScheduleData(data);
                navigateToStep(STEPS.REVIEW);
              }}
              selectedServices={selectedServices}
            />
          </div>
          
          {/* Price Calculator (Desktop) */}
          <div className="hidden md:block">
            <PriceCalculator
              items={priceItems}
              travelFee={travelFee}
              tax={tax}
              taxRate={taxRate}
              discounts={discounts}
              showDetails={true}
              isSticky={true}
            />
          </div>
        </div>
      )}
      
      {/* Review Step */}
      {currentStep === STEPS.REVIEW && (
        <ReviewBooking
          scheduleData={scheduleData}
          selectedServices={selectedServices}
          serviceSummary={priceItems}
          travelFee={travelFee}
          totalPrice={totalPrice}
          onBack={() => navigateToStep(STEPS.SCHEDULE)}
          onConfirm={handleConfirmBooking}
          onEdit={handleEditSection}
          tax={tax}
          taxRate={taxRate}
          discounts={discounts}
        />
      )}
      
      {/* Confirmation Step */}
      {currentStep === STEPS.CONFIRMATION && (
        <BookingConfirmation
          bookingId={bookingId}
          appointmentDate={scheduleData.date!}
          appointmentTime={getTimeSlotDisplay()}
          customerName={scheduleData.fullName}
          customerPhone={scheduleData.phone}
          customerEmail={scheduleData.email}
          services={getServiceNames()}
          totalPrice={totalPrice}
          onBookAnother={handleBookAnother}
          onViewAccount={handleViewAccount}
        />
      )}
      
      {/* User Account Step */}
      {currentStep === STEPS.ACCOUNT && (
        <UserAccount
          onBookNew={handleBookAnother}
          onLogout={handleLogout}
        />
      )}
      
      {/* Floating Price Bar (Mobile) */}
      <FloatingPriceBar
        items={priceItems}
        travelFee={travelFee}
        tax={tax}
        discounts={discounts}
        isVisible={shouldShowFloatingBar}
        onDetailsClick={() => setShowPriceDetails(true)}
        onContinueClick={handleFloatingBarContinue}
        continueText={getContinueText()}
      />
      
      {/* Full-screen Price Details Modal (Mobile) */}
      {showPriceDetails && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 md:hidden">
          <div className="bg-white rounded-lg w-full max-w-md max-h-[80vh] overflow-y-auto">
            <div className="p-4">
              <PriceCalculator
                items={priceItems}
                travelFee={travelFee}
                tax={tax}
                taxRate={taxRate}
                discounts={discounts}
                showDetails={true}
              />
              <button
                onClick={() => setShowPriceDetails(false)}
                className="w-full mt-4 py-2 px-4 bg-gray-200 rounded-md text-gray-800 font-medium"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default BookingPage;