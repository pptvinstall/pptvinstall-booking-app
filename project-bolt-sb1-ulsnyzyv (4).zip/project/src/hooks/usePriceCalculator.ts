import { useState, useEffect, useMemo } from 'react';
import { PriceItem } from '../components/ui/PriceCalculator';

interface DiscountRule {
  id: string;
  name: string;
  description: string;
  calculate: (items: PriceItem[], travelFee: number) => number;
  appliesTo?: string[];
}

interface TaxConfig {
  enabled: boolean;
  rate: number;
}

interface PriceCalculatorOptions {
  applyDiscounts?: boolean;
  applyTax?: boolean;
  taxRate?: number;
}

export const usePriceCalculator = (
  selectedServices: string[] = [],
  serviceOptions: any[] = [],
  travelFee: number = 0,
  options: PriceCalculatorOptions = {}
) => {
  const [priceItems, setPriceItems] = useState<PriceItem[]>([]);
  const [discounts, setDiscounts] = useState<PriceItem[]>([]);
  const [tax, setTax] = useState<number>(0);

  const { applyDiscounts = true, applyTax = true, taxRate = 0.07 } = options;

  const discountRules: DiscountRule[] = [
    {
      id: 'multi-service-discount',
      name: 'Multi-Service Discount',
      description: 'Save $10 for each additional service',
      calculate: (items) => {
        const serviceCount = items.length;
        return serviceCount > 1 ? (serviceCount - 1) * 10 : 0;
      }
    },
    {
      id: 'mount-bundle-discount',
      name: 'Mount Bundle Discount',
      description: 'Save $5 per mount when purchasing multiple mounts',
      appliesTo: ['tv-mounts'],
      calculate: (items) => {
        const mounts = items.filter(item => item.category === 'Mounts');
        const mountCount = mounts.reduce((count, mount) => count + mount.quantity, 0);
        return mountCount > 1 ? (mountCount - 1) * 5 : 0;
      }
    },
    {
      id: 'smart-home-bundle',
      name: 'Smart Home Bundle',
      description: 'Save $15 when installing multiple smart home devices',
      appliesTo: ['smart-floodlight', 'smart-doorbell'],
      calculate: (items) => {
        const smartDevices = items.filter(item => 
          item.category === 'Smart Home' && item.quantity > 0
        );
        return smartDevices.length > 1 ? 15 : 0;
      }
    }
  ];

  useEffect(() => {
    if (!selectedServices.length || !serviceOptions.length) {
      setPriceItems([]);
      return;
    }

    const items: PriceItem[] = [];
    const serviceMap: Record<string, PriceItem> = {};

    selectedServices.forEach(serviceId => {
      const [baseId, optionId] = serviceId.split('-');
      const service = serviceOptions.find(s => s.id === baseId);
      
      if (service) {
        if (optionId && service.options) {
          const option = service.options.find((o: any) => o.id === optionId);
          if (option && typeof option.price === 'number') {
            const itemId = `${service.id}-${option.id}`;
            const name = `${service.title} - ${option.name}`;
            if (serviceMap[itemId]) {
              serviceMap[itemId].quantity += 1;
            } else {
              serviceMap[itemId] = {
                id: itemId,
                name,
                price: option.price,
                quantity: 1,
                category: service.category === 'mounting' ? 'TV Mounting' : 
                          service.category === 'addon' ? 'Add-ons' : 
                          service.category === 'smart-home' ? 'Smart Home' : 
                          service.category === 'mount' ? 'Mounts' : 'Other'
              };
            }
          }
        } else if (typeof service.price === 'number') {
          if (serviceMap[service.id]) {
            serviceMap[service.id].quantity += 1;
          } else {
            serviceMap[service.id] = {
              id: service.id,
              name: service.title,
              price: service.price,
              quantity: 1,
              category: service.category === 'mounting' ? 'TV Mounting' : 
                        service.category === 'addon' ? 'Add-ons' : 
                        service.category === 'smart-home' ? 'Smart Home' : 
                        service.category === 'mount' ? 'Mounts' : 'Other'
            };
          }
        }
      }
    });

    Object.values(serviceMap).forEach(item => {
      items.push(item);
    });

    setPriceItems(items);
  }, [selectedServices, serviceOptions]);

  useEffect(() => {
    if (!applyDiscounts) {
      setDiscounts([]);
      return;
    }

    const applicableDiscounts: PriceItem[] = [];

    discountRules.forEach(rule => {
      const discountAmount = rule.calculate(priceItems, travelFee);
      if (discountAmount > 0) {
        applicableDiscounts.push({
          id: rule.id,
          name: rule.name,
          price: -discountAmount,
          quantity: 1,
          isDiscount: true
        });
      }
    });

    setDiscounts(applicableDiscounts);
  }, [priceItems, travelFee, applyDiscounts]);

  useEffect(() => {
    if (!applyTax) {
      setTax(0);
      return;
    }

    const subtotal = priceItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const discountTotal = discounts.reduce((sum, discount) => sum + discount.price, 0);
    const taxableAmount = subtotal + discountTotal;
    
    setTax(taxableAmount * taxRate);
  }, [priceItems, discounts, taxRate, applyTax]);

  const totalPrice = useMemo(() => {
    const subtotal = priceItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const discountTotal = discounts.reduce((sum, discount) => sum + discount.price, 0);
    return subtotal + discountTotal + travelFee + tax;
  }, [priceItems, discounts, travelFee, tax]);

  const subtotal = useMemo(() => {
    return priceItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }, [priceItems]);

  return {
    priceItems,
    discounts,
    travelFee,
    tax,
    taxRate,
    subtotal,
    totalPrice
  };
};

export default usePriceCalculator;
