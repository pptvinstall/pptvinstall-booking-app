import React, { useState } from 'react';
import { Tv, Menu, X } from 'lucide-react';
import HomePage from './components/HomePage';
import PricingPage from './components/PricingPage';
import BookingPage from './components/BookingPage';
import Layout from './components/layout/Layout';

// Define service type for passing between components
interface ServiceOption {
  id: string;
  title: string;
  description: string;
  price: number | string;
  priceDisplay: string;
  priceNote?: string;
  category: 'mounting' | 'addon' | 'smart-home' | 'mount';
  icon: React.ElementType;
  iconBgColor: string;
  iconColor: string;
  borderColor: string;
  features: string[];
  options?: {
    id: string;
    name: string;
    price: number;
    priceDisplay: string;
  }[];
}

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  
  const handleGetQuote = () => {
    setCurrentPage('booking');
  };

  const handleBookNow = () => {
    setCurrentPage('booking');
  };

  const navigateTo = (page: string) => {
    setCurrentPage(page);
  };
  
  // Handle service selection from pricing page
  const handleServiceSelect = (service: ServiceOption, optionId?: string) => {
    const serviceId = optionId ? `${service.id}-${optionId}` : service.id;
    
    setSelectedServices(prev => {
      if (prev.includes(serviceId)) {
        return prev.filter(id => id !== serviceId);
      } else {
        return [...prev, serviceId];
      }
    });
    
    // Automatically navigate to booking page after selecting a service
    if (currentPage === 'pricing') {
      setTimeout(() => {
        setCurrentPage('booking');
      }, 500);
    }
  };

  return (
    <Layout currentPage={currentPage} onNavigate={navigateTo}>
      {/* Main Content */}
      <main className="flex-grow">
        {currentPage === 'home' && <HomePage onGetQuote={handleGetQuote} />}
        {currentPage === 'pricing' && (
          <PricingPage 
            onServiceSelect={handleServiceSelect} 
            selectedServices={selectedServices} 
          />
        )}
        {currentPage === 'booking' && <BookingPage />}
      </main>
    </Layout>
  );
}

export default App;