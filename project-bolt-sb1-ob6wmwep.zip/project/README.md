# PPTV Website - Staging Environment

This is the staging environment for the PPTV (Picture Perfect TV Install) website. The staging environment provides a fully functional frontend with disabled backend functionality for testing and demonstration purposes.

## Features

- **Staging Mode Banner**: Clearly indicates when the site is running in staging mode
- **Feature Flags**: Toggle features on/off directly from the UI
- **Simulated Backend**: Provides realistic feedback without actual backend integration
- **Coming Soon Indicators**: Shows which features are not yet available
- **Admin Dashboard**: Preview of the admin interface with limited functionality

## Getting Started

1. Clone the repository
2. Install dependencies: `npm install`
3. Start the development server: `npm run dev`

## Environment Configuration

Copy the `.env.example` file to `.env` to configure the environment:

```
cp .env.example .env
```

Edit the `.env` file to configure the staging environment settings.

## Feature Flags

The following features can be toggled in the staging environment:

- **enableBooking**: Enable/disable the booking functionality
- **enablePayments**: Enable/disable payment processing
- **enableAdminDashboard**: Enable/disable admin dashboard features
- **enableNotifications**: Enable/disable notification system
- **enableContactForm**: Enable/disable contact form submission

## Deployment

The staging environment can be deployed to Netlify for demonstration purposes. All backend calls are safely disabled or simulated.

## Project Structure

- `/src/components`: UI components
- `/src/pages`: Page components
- `/src/hooks`: Custom React hooks
- `/src/config`: Configuration files including feature flags
- `/src/lib`: Utility functions

## Future Integration

The codebase is structured for easy integration with a backend API:

- Environment variable templates are provided
- Components are designed to work with real API endpoints
- Feature flags allow for gradual feature rollout