import React from 'react';
import { Link } from 'react-router-dom';
import { Tv, Home, Shield, Zap, ArrowRight, Star, Check } from 'lucide-react';
import Button from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';

const HomePage: React.FC = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gray-900 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1593784991095-a205069470b6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
            alt="TV Installation" 
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-gray-900 via-gray-900/95 to-gray-900/80"></div>
        </div>
        
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="max-w-3xl animate-fadeIn">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
              Professional TV Mounting & Smart Home Installation
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Transform your home entertainment experience with our expert installation services. Clean, professional, and hassle-free.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/booking">
                <Button size="lg" className="transition-all hover:shadow-glow">
                  Book Now
                </Button>
              </Link>
              <Link to="/services">
                <Button variant="outline" size="lg" className="transition-all">
                  Explore Services
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="bg-gray-900 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Our Services</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              We offer a range of professional installation services to enhance your home entertainment and security.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-gray-800 border-gray-700 hover:border-blue-500 transition-all duration-300 transform hover:scale-[1.02] hover:shadow-md card-hover">
              <CardContent className="p-6 flex flex-col items-center text-center">
                <div className="bg-blue-500/20 p-4 rounded-full mb-4">
                  <Tv className="h-8 w-8 text-blue-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">TV Mounting</h3>
                <p className="text-gray-400 mb-4">
                  Professional TV mounting services for all types of TVs and mounts, including over-fireplace installations.
                </p>
                <Link to="/services/tv-mounting" className="text-blue-500 hover:text-blue-400 inline-flex items-center mt-auto transition-colors">
                  Learn more <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 hover:border-blue-500 transition-all duration-300 transform hover:scale-[1.02] hover:shadow-md card-hover">
              <CardContent className="p-6 flex flex-col items-center text-center">
                <div className="bg-blue-500/20 p-4 rounded-full mb-4">
                  <Home className="h-8 w-8 text-blue-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Smart Home Installation</h3>
                <p className="text-gray-400 mb-4">
                  Setup and installation of smart home devices, including speakers, lighting, and home automation systems.
                </p>
                <Link to="/services/smart-home" className="text-blue-500 hover:text-blue-400 inline-flex items-center mt-auto transition-colors">
                  Learn more <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 hover:border-blue-500 transition-all duration-300 transform hover:scale-[1.02] hover:shadow-md card-hover">
              <CardContent className="p-6 flex flex-col items-center text-center">
                <div className="bg-blue-500/20 p-4 rounded-full mb-4">
                  <Shield className="h-8 w-8 text-blue-500" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Security Camera Installation</h3>
                <p className="text-gray-400 mb-4">
                  Professional installation of security cameras, doorbell cameras, and complete security systems.
                </p>
                <Link to="/services/security-cameras" className="text-blue-500 hover:text-blue-400 inline-flex items-center mt-auto transition-colors">
                  Learn more <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-gray-800 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">How It Works</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Our simple process makes getting your installation done quick and easy.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center group">
              <div className="bg-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold transition-transform group-hover:scale-110">1</div>
              <h3 className="text-xl font-semibold text-white mb-2">Book Online</h3>
              <p className="text-gray-400">
                Select your services and choose a convenient date and time.
              </p>
            </div>

            <div className="text-center group">
              <div className="bg-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold transition-transform group-hover:scale-110">2</div>
              <h3 className="text-xl font-semibold text-white mb-2">Confirmation</h3>
              <p className="text-gray-400">
                Receive confirmation and appointment details via email.
              </p>
            </div>

            <div className="text-center group">
              <div className="bg-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold transition-transform group-hover:scale-110">3</div>
              <h3 className="text-xl font-semibold text-white mb-2">Installation</h3>
              <p className="text-gray-400">
                Our professional technicians arrive and complete the installation.
              </p>
            </div>

            <div className="text-center group">
              <div className="bg-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold transition-transform group-hover:scale-110">4</div>
              <h3 className="text-xl font-semibold text-white mb-2">Enjoy</h3>
              <p className="text-gray-400">
                Sit back and enjoy your perfectly installed entertainment system.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-gray-900 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">What Our Customers Say</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Don't just take our word for it. Here's what our satisfied customers have to say.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-gray-800 border-gray-700 hover:shadow-lg transition-all duration-300 card-hover">
              <CardContent className="p-6">
                <div className="flex text-yellow-500 mb-4">
                  <Star className="fill-current h-5 w-5" />
                  <Star className="fill-current h-5 w-5" />
                  <Star className="fill-current h-5 w-5" />
                  <Star className="fill-current h-5 w-5" />
                  <Star className="fill-current h-5 w-5" />
                </div>
                <p className="text-gray-300 mb-4">
                  "The technician was professional, on time, and did an amazing job mounting our TV above the fireplace. Highly recommend!"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold mr-3">
                    JD
                  </div>
                  <div>
                    <p className="text-white font-medium">John D.</p>
                    <p className="text-gray-500 text-sm">TV Mounting Customer</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 hover:shadow-lg transition-all duration-300 card-hover">
              <CardContent className="p-6">
                <div className="flex text-yellow-500 mb-4">
                  <Star className="fill-current h-5 w-5" />
                  <Star className="fill-current h-5 w-5" />
                  <Star className="fill-current h-5 w-5" />
                  <Star className="fill-current h-5 w-5" />
                  <Star className="fill-current h-5 w-5" />
                </div>
                <p className="text-gray-300 mb-4">
                  "PPTV installed our entire smart home system. Everything works perfectly, and they were very patient in explaining how to use everything."
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold mr-3">
                    SM
                  </div>
                  <div>
                    <p className="text-white font-medium">Sarah M.</p>
                    <p className="text-gray-500 text-sm">Smart Home Customer</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700 hover:shadow-lg transition-all duration-300 card-hover">
              <CardContent className="p-6">
                <div className="flex text-yellow-500 mb-4">
                  <Star className="fill-current h-5 w-5" />
                  <Star className="fill-current h-5 w-5" />
                  <Star className="fill-current h-5 w-5" />
                  <Star className="fill-current h-5 w-5" />
                  <Star className="fill-current h-5 w-5" />
                </div>
                <p className="text-gray-300 mb-4">
                  "Quick, efficient, and reasonably priced. They installed security cameras around our home and set up the app for monitoring. Great service!"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold mr-3">
                    RJ
                  </div>
                  <div>
                    <p className="text-white font-medium">Robert J.</p>
                    <p className="text-gray-500 text-sm">Security Camera Customer</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-gray-800 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Why Choose Us</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              We pride ourselves on delivering exceptional service and quality installations.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="flex items-start">
              <div className="bg-blue-500/20 p-3 rounded-full mr-4">
                <Check className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">Professional Installation</h3>
                <p className="text-gray-400">
                  Our technicians are highly trained and experienced in all types of installations.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-blue-500/20 p-3 rounded-full mr-4">
                <Check className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">Quality Equipment</h3>
                <p className="text-gray-400">
                  We use only high-quality mounts and equipment for all installations.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-blue-500/20 p-3 rounded-full mr-4">
                <Check className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">Competitive Pricing</h3>
                <p className="text-gray-400">
                  Our rates are transparent and competitive, with no hidden fees.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-blue-500/20 p-3 rounded-full mr-4">
                <Check className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">Satisfaction Guaranteed</h3>
                <p className="text-gray-400">
                  We're not satisfied until you're completely happy with our work.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-blue-500/20 p-3 rounded-full mr-4">
                <Check className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">Fast Service</h3>
                <p className="text-gray-400">
                  Most installations can be completed within a few hours.
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-blue-500/20 p-3 rounded-full mr-4">
                <Check className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">Warranty</h3>
                <p className="text-gray-400">
                  All our installations come with a satisfaction guarantee.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Transform Your Home?</h2>
          <p className="text-blue-100 max-w-2xl mx-auto mb-8">
            Book your installation today and experience the difference of professional service.
          </p>
          <Link to="/booking">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 transition-all hover:shadow-lg">
              Book Your Installation
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;