import React from 'react';
import { Link } from 'react-router-dom';
import PricingCalculator from '../components/pricing/PricingCalculator';
import Button from '../components/ui/Button';

const PricingPage: React.FC = () => {
  return (
    <div className="bg-gray-900 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">Pricing</h1>
          <p className="text-xl text-gray-300">
            Calculate the cost of your installation services with our interactive pricing tool.
          </p>
        </div>

        <PricingCalculator />

        <div className="mt-16 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Frequently Asked Questions</h2>
          <div className="max-w-3xl mx-auto space-y-6">
            <div>
              <h3 className="text-xl font-semibold text-white mb-2">Do you provide the TV mount?</h3>
              <p className="text-gray-300">
                We can install your own mount or provide one for an additional fee. We offer a variety of mounts suitable for different TV sizes and installation locations.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-white mb-2">What is your service area?</h3>
              <p className="text-gray-300">
                We currently serve the greater metropolitan area and surrounding suburbs within a 30-mile radius of the city center.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-white mb-2">Do you offer a warranty?</h3>
              <p className="text-gray-300">
                Yes, all of our installations come with a 1-year warranty on workmanship. If there are any issues with the installation, we'll fix it at no additional cost.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-white mb-2">What payment methods do you accept?</h3>
              <p className="text-gray-300">
                We accept all major credit cards, digital payments (Apple Pay, Google Pay), and cash. A $20 deposit is required at booking, with the balance due upon completion.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <Link to="/booking">
            <Button size="lg">Book Your Installation</Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default PricingPage;