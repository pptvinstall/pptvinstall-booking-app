import React from 'react';
import { Mail, Phone, MapPin, Clock, Facebook, Instagram, BookText as TikTok } from 'lucide-react';
import { Card, CardContent } from '../components/ui/Card';
import ContactForm from '../components/contact/ContactForm';

const ContactPage: React.FC = () => {
  return (
    <div className="bg-gray-900 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">Contact Us</h1>
          <p className="text-xl text-gray-300">
            Have questions or need assistance? We're here to help.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <ContactForm />

          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Contact Information</h2>
            
            <div className="space-y-6">
              <Card className="bg-gray-800 border-gray-700 hover:shadow-md transition-all">
                <CardContent className="p-6">
                  <div className="flex items-start">
                    <div className="bg-blue-500/20 p-3 rounded-full mr-4">
                      <Phone className="h-6 w-6 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-1">Phone</h3>
                      <a href="tel:4047024748" className="text-gray-300 hover:text-blue-400 transition-colors">
                        (404) 702-4748
                      </a>
                      <p className="text-gray-400 text-sm mt-1">Monday-Friday: 8am-6pm</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700 hover:shadow-md transition-all">
                <CardContent className="p-6">
                  <div className="flex items-start">
                    <div className="bg-blue-500/20 p-3 rounded-full mr-4">
                      <Mail className="h-6 w-6 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-1">Email</h3>
                      <a href="mailto:pptvinstall@gmail.com" className="text-gray-300 hover:text-blue-400 transition-colors">
                        pptvinstall@gmail.com
                      </a>
                      <p className="text-gray-400 text-sm mt-1">We'll respond within 24 hours</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700 hover:shadow-md transition-all">
                <CardContent className="p-6">
                  <div className="flex items-start">
                    <div className="bg-blue-500/20 p-3 rounded-full mr-4">
                      <MapPin className="h-6 w-6 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-1">Address</h3>
                      <p className="text-gray-300">Decatur, GA 30034</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700 hover:shadow-md transition-all">
                <CardContent className="p-6">
                  <div className="flex items-start">
                    <div className="bg-blue-500/20 p-3 rounded-full mr-4">
                      <Clock className="h-6 w-6 text-blue-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-1">Business Hours</h3>
                      <p className="text-gray-300">Monday-Friday: 8am-6pm</p>
                      <p className="text-gray-300">Saturday: 9am-4pm</p>
                      <p className="text-gray-300">Sunday: Closed</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-gray-800 border-gray-700 hover:shadow-md transition-all">
                <CardContent className="p-6">
                  <div className="flex items-start">
                    <div className="bg-blue-500/20 p-3 rounded-full mr-4 flex items-center justify-center">
                      <Facebook className="h-6 w-6 text-blue-500" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-white mb-1">Social Media</h3>
                      <div className="grid grid-cols-1 gap-2 mt-2">
                        <a 
                          href="https://www.facebook.com/PPTVInstall/" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center text-gray-300 hover:text-blue-400 transition-colors"
                        >
                          <Facebook className="h-4 w-4 mr-2" />
                          <span>facebook.com/PPTVInstall</span>
                        </a>
                        <a 
                          href="https://www.instagram.com/pptvinstall/" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center text-gray-300 hover:text-blue-400 transition-colors"
                        >
                          <Instagram className="h-4 w-4 mr-2" />
                          <span>instagram.com/pptvinstall</span>
                        </a>
                        <a 
                          href="https://www.tiktok.com/@pptvinstall" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center text-gray-300 hover:text-blue-400 transition-colors"
                        >
                          <TikTok className="h-4 w-4 mr-2" />
                          <span>tiktok.com/@pptvinstall</span>
                        </a>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;