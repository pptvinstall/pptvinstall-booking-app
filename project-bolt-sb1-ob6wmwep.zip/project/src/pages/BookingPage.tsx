import React from 'react';
import BookingWizard from '../components/booking/BookingWizard';
import ComingSoonBadge from '../components/common/ComingSoonBadge';
import { useStaging } from '../hooks/useStaging';

const BookingPage: React.FC = () => {
  const { isFeatureEnabled } = useStaging();
  
  return (
    <div className="bg-gray-900 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="flex justify-center items-center gap-2 mb-4">
            <h1 className="text-4xl font-bold text-white">Book Your Service</h1>
            {!isFeatureEnabled('enableBooking') && (
              <ComingSoonBadge />
            )}
          </div>
          <p className="text-xl text-gray-300">
            Schedule your TV mounting or smart home installation with our easy step-by-step booking system.
          </p>
        </div>

        <BookingWizard />
        
        <div className="mt-16 max-w-3xl mx-auto">
          <h2 className="text-2xl font-bold text-white mb-4 text-center">Booking Information</h2>
          <div className="bg-gray-800 rounded-lg p-6 space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Deposit & Payment</h3>
              <p className="text-gray-300">
                A $20 deposit is required to confirm your booking. The remaining balance will be due upon completion of the service. 
                We accept cash, Zelle, and Apple Pay.
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Cancellation Policy</h3>
              <p className="text-gray-300">
                Cancellations made at least 24 hours before your scheduled appointment will receive a full refund of the deposit. 
                Cancellations with less than 24 hours notice may not be eligible for a refund.
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">What to Expect</h3>
              <p className="text-gray-300">
                Our technicians will arrive within the scheduled time window. Please ensure that the installation area is accessible 
                and clear of obstacles. All TVs and equipment should be on-site and unpacked before the technician arrives.
              </p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Travel Fees</h3>
              <p className="text-gray-300">
                Service is free within 20 miles of our location. Beyond that, a travel fee of $1 per mile applies (calculated as distance beyond 20 miles).
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingPage;