import React from 'react';
import { Link } from 'react-router-dom';
import { Tv, Home, Shield, ArrowRight } from 'lucide-react';
import { Card, CardContent } from '../components/ui/Card';
import Button from '../components/ui/Button';

const ServicesPage: React.FC = () => {
  return (
    <div className="bg-gray-900 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">Our Services</h1>
          <p className="text-xl text-gray-300">
            Professional TV mounting and smart home installation services tailored to your needs.
          </p>
        </div>

        {/* TV Mounting Section */}
        <section className="mb-20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-white mb-4">TV Mounting</h2>
              <p className="text-gray-300 mb-6">
                Our professional TV mounting service ensures your television is securely installed at the perfect height and angle for optimal viewing. We handle all types of mounts and TVs, from small bedroom installations to large living room setups.
              </p>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="bg-blue-500/20 p-2 rounded-full mr-3 mt-1">
                    <Tv className="h-4 w-4 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">Basic TV Mounting</h3>
                    <p className="text-gray-400">
                      Installation using customer-provided mount. Includes cord concealment and setup.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-500/20 p-2 rounded-full mr-3 mt-1">
                    <Tv className="h-4 w-4 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">Over-Fireplace Mounting</h3>
                    <p className="text-gray-400">
                      Specialized installation above fireplaces with proper heat protection and optimal viewing angle.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-500/20 p-2 rounded-full mr-3 mt-1">
                    <Tv className="h-4 w-4 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">Outlet Relocation</h3>
                    <p className="text-gray-400">
                      Moving power outlets to better accommodate your TV setup for a cleaner look.
                    </p>
                  </div>
                </div>
              </div>
              <div className="mt-8">
                <Link to="/pricing">
                  <Button>View Pricing</Button>
                </Link>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1593784991095-a205069470b6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80" 
                alt="TV Mounting Service" 
                className="w-full h-auto object-cover"
              />
            </div>
          </div>
        </section>

        {/* Smart Home Installation Section */}
        <section className="mb-20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1 rounded-lg overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1558002038-1055907df827?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80" 
                alt="Smart Home Installation" 
                className="w-full h-auto object-cover"
              />
            </div>
            <div className="order-1 md:order-2">
              <h2 className="text-3xl font-bold text-white mb-4">Smart Home Installation</h2>
              <p className="text-gray-300 mb-6">
                Transform your home with integrated smart technology. We install and configure a wide range of smart home devices to create a seamless, connected living experience.
              </p>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="bg-blue-500/20 p-2 rounded-full mr-3 mt-1">
                    <Home className="h-4 w-4 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">Smart Speaker Setup</h3>
                    <p className="text-gray-400">
                      Installation and configuration of smart speakers and voice assistants throughout your home.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-500/20 p-2 rounded-full mr-3 mt-1">
                    <Home className="h-4 w-4 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">Smart Lighting</h3>
                    <p className="text-gray-400">
                      Setup of smart bulbs, switches, and lighting systems with custom scenes and automation.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-500/20 p-2 rounded-full mr-3 mt-1">
                    <Home className="h-4 w-4 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">Home Automation</h3>
                    <p className="text-gray-400">
                      Integration of various smart devices into a cohesive system with custom routines and controls.
                    </p>
                  </div>
                </div>
              </div>
              <div className="mt-8">
                <Link to="/pricing">
                  <Button>View Pricing</Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Security Camera Installation Section */}
        <section className="mb-20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-white mb-4">Security Camera Installation</h2>
              <p className="text-gray-300 mb-6">
                Enhance your home security with professionally installed camera systems. We offer complete setup of various security cameras with proper placement for optimal coverage.
              </p>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="bg-blue-500/20 p-2 rounded-full mr-3 mt-1">
                    <Shield className="h-4 w-4 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">Doorbell Cameras</h3>
                    <p className="text-gray-400">
                      Installation of smart doorbell cameras with video monitoring and mobile notifications.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-500/20 p-2 rounded-full mr-3 mt-1">
                    <Shield className="h-4 w-4 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">Floodlight Cameras</h3>
                    <p className="text-gray-400">
                      Setup of motion-activated floodlight cameras for enhanced security around your property.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="bg-blue-500/20 p-2 rounded-full mr-3 mt-1">
                    <Shield className="h-4 w-4 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">Multi-Camera Systems</h3>
                    <p className="text-gray-400">
                      Complete installation of multiple security cameras with centralized monitoring and storage.
                    </p>
                  </div>
                </div>
              </div>
              <div className="mt-8">
                <Link to="/pricing">
                  <Button>View Pricing</Button>
                </Link>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1557317605-3d2a8e7e6f24?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80" 
                alt="Security Camera Installation" 
                className="w-full h-auto object-cover"
              />
            </div>
          </div>
        </section>

        {/* Service Process Section */}
        <section>
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Our Service Process</h2>
            <p className="text-gray-300 max-w-2xl mx-auto">
              We follow a streamlined process to ensure your installation is completed efficiently and to your satisfaction.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="bg-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">1</div>
                <h3 className="text-xl font-semibold text-white mb-2">Consultation</h3>
                <p className="text-gray-400">
                  We discuss your needs and preferences to determine the best installation approach.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="bg-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">2</div>
                <h3 className="text-xl font-semibold text-white mb-2">Scheduling</h3>
                <p className="text-gray-400">
                  We arrange a convenient time for our technicians to perform the installation.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="bg-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">3</div>
                <h3 className="text-xl font-semibold text-white mb-2">Installation</h3>
                <p className="text-gray-400">
                  Our professional technicians complete the installation with attention to detail.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="bg-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">4</div>
                <h3 className="text-xl font-semibold text-white mb-2">Final Review</h3>
                <p className="text-gray-400">
                  We ensure everything is working perfectly and provide guidance on usage.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* CTA Section */}
        <section className="mt-20 text-center">
          <div className="bg-blue-600 rounded-lg p-8 md:p-12">
            <h2 className="text-3xl font-bold text-white mb-4">Ready to Get Started?</h2>
            <p className="text-blue-100 max-w-2xl mx-auto mb-8">
              Book your installation today and experience the difference of professional service.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/booking">
                <Button className="bg-white text-blue-600 hover:bg-gray-100">
                  Book Now
                </Button>
              </Link>
              <Link to="/pricing">
                <Button variant="outline" className="border-white text-white hover:bg-blue-700">
                  View Pricing
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default ServicesPage;