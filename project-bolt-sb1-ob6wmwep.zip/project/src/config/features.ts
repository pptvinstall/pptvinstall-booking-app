/**
 * Feature flag configuration for the PPTV website
 * This allows for easy toggling of features in the staging environment
 */

export interface FeatureFlags {
  enableBooking: boolean;
  enablePayments: boolean;
  enableAdminDashboard: boolean;
  enableNotifications: boolean;
  enableContactForm: boolean;
}

// Default feature configuration for staging environment
const defaultFeatures: FeatureFlags = {
  enableBooking: false,
  enablePayments: false,
  enableAdminDashboard: true,
  enableNotifications: false,
  enableContactForm: true,
};

// Get feature flags, with ability to override from localStorage
export const getFeatureFlags = (): FeatureFlags => {
  try {
    const storedFlags = localStorage.getItem('pptv_feature_flags');
    if (storedFlags) {
      return { ...defaultFeatures, ...JSON.parse(storedFlags) };
    }
  } catch (error) {
    console.error('Error loading feature flags:', error);
  }
  
  return defaultFeatures;
};

// Set a specific feature flag
const setFeatureFlag = (key: keyof FeatureFlags, value: boolean): void => {
  try {
    const currentFlags = getFeatureFlags();
    const updatedFlags = { ...currentFlags, [key]: value };
    localStorage.setItem('pptv_feature_flags', JSON.stringify(updatedFlags));
  } catch (error) {
    console.error('Error saving feature flag:', error);
  }
};

// Toggle a feature flag
export const toggleFeatureFlag = (key: keyof FeatureFlags): boolean => {
  const currentFlags = getFeatureFlags();
  const newValue = !currentFlags[key];
  setFeatureFlag(key, newValue);
  return newValue;
};