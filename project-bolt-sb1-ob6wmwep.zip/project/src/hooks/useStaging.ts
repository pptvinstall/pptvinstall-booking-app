import { useState } from 'react';
import { getFeatureFlags } from '../config/features';

interface StagingHookReturn {
  isFeatureEnabled: (featureName: string) => boolean;
  showFeedback: (title: string, message: string, type?: 'success' | 'error' | 'info') => void;
  feedbackState: {
    isOpen: boolean;
    title: string;
    message: string;
    type: 'success' | 'error' | 'info';
  };
  closeFeedback: () => void;
  simulateBackendCall: <T>(data: T, shouldSucceed?: boolean, delay?: number) => Promise<T>;
}

export const useStaging = (): StagingHookReturn => {
  const [feedbackState, setFeedbackState] = useState({
    isOpen: false,
    title: '',
    message: '',
    type: 'info' as const
  });

  const isFeatureEnabled = (featureName: string): boolean => {
    const features = getFeatureFlags();
    return features[featureName as keyof typeof features] || false;
  };

  const showFeedback = (
    title: string, 
    message: string, 
    type: 'success' | 'error' | 'info' = 'info'
  ) => {
    setFeedbackState({
      isOpen: true,
      title,
      message,
      type
    });
    
    // Log to console for development tracking
    console.log(`[${type.toUpperCase()}] ${title}: ${message}`);
  };

  const closeFeedback = () => {
    setFeedbackState(prev => ({ ...prev, isOpen: false }));
  };

  // Simulate backend API calls with configurable success/failure and delay
  const simulateBackendCall = <T>(data: T, shouldSucceed = true, delay = 1000): Promise<T> => {
    console.log('[STAGING] Simulating backend call with data:', data);
    
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (shouldSucceed) {
          console.log('[STAGING] Backend call succeeded');
          resolve(data);
        } else {
          console.log('[STAGING] Backend call failed');
          reject(new Error('Simulated backend error'));
        }
      }, delay);
    });
  };

  return {
    isFeatureEnabled,
    showFeedback,
    feedbackState,
    closeFeedback,
    simulateBackendCall
  };
};