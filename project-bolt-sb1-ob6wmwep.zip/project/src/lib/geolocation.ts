/**
 * Geolocation utilities for calculating distances
 */

// Decatur, GA coordinates
const DECATUR_LAT = 33.7748;
const DECATUR_LNG = -84.2963;

/**
 * Calculate distance from Decatur, GA to a given address
 * @param address Full address string (e.g., "123 Main St, Atlanta, GA 30303")
 * @returns Distance in miles (rounded to nearest integer)
 */
export const calculateDistanceFromDecatur = async (address: string): Promise<number> => {
  try {
    // In a real implementation, this would call a geocoding API
    // For this staging environment, we'll simulate the API call
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Parse the address to extract city and state
    const addressParts = address.split(',');
    if (addressParts.length < 2) {
      return 0; // Invalid address format
    }
    
    const cityState = addressParts[1].trim();
    const zipCode = addressParts[addressParts.length - 1].trim().split(' ')[1];
    
    // Simulate distance calculation based on city or zip code
    // This is just for demonstration - in production, use a real geocoding API
    let distance = 0;
    
    if (cityState.includes('Atlanta') || zipCode?.startsWith('303')) {
      distance = 10 + Math.random() * 15; // 10-25 miles
    } else if (cityState.includes('Marietta') || zipCode?.startsWith('300')) {
      distance = 20 + Math.random() * 10; // 20-30 miles
    } else if (cityState.includes('Alpharetta') || zipCode?.startsWith('300')) {
      distance = 25 + Math.random() * 10; // 25-35 miles
    } else if (cityState.includes('Decatur') || zipCode?.startsWith('300')) {
      distance = 0 + Math.random() * 5; // 0-5 miles
    } else {
      // For any other location, generate a random distance between 5 and 50 miles
      distance = 5 + Math.random() * 45;
    }
    
    return Math.round(distance);
  } catch (error) {
    console.error('Error calculating distance:', error);
    return 0;
  }
};

/**
 * Calculate distance between two coordinates using the Haversine formula
 * @param lat1 Latitude of first point
 * @param lng1 Longitude of first point
 * @param lat2 Latitude of second point
 * @param lng2 Longitude of second point
 * @returns Distance in miles
 */
export const calculateHaversineDistance = (
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number => {
  // Convert latitude and longitude from degrees to radians
  const toRadians = (degrees: number) => degrees * Math.PI / 180;
  
  const dLat = toRadians(lat2 - lat1);
  const dLng = toRadians(lng2 - lng1);
  
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * 
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  
  // Earth's radius in miles
  const earthRadius = 3958.8;
  
  // Calculate the distance
  return earthRadius * c;
};

/**
 * In a production environment, this would use a real geocoding API
 * For this staging environment, we're simulating the API call
 */
export const geocodeAddress = async (address: string): Promise<{ lat: number; lng: number } | null> => {
  try {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // For demonstration purposes, return coordinates near Decatur
    // with some random variation to simulate different addresses
    return {
      lat: DECATUR_LAT + (Math.random() - 0.5) * 0.1,
      lng: DECATUR_LNG + (Math.random() - 0.5) * 0.1
    };
  } catch (error) {
    console.error('Error geocoding address:', error);
    return null;
  }
};