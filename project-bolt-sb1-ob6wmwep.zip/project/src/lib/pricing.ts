import { BookingFormData } from '../components/booking/BookingWizard';

// TV Mounting Base Prices
const TV_MOUNTING_PRICES = {
  'standard': 100, // Basic TV Mounting (Customer provides mount)
  'fireplace': 100, // Additional fee for over fireplace installation
  'ceiling': 175, // Ceiling TV Mount Installation
};

// TV Mount Prices (Optional Add-on)
const MOUNT_PRICES = {
  // Fixed Mount (No Tilt, No Swivel)
  'fixed-small': 40, // Small (32"-55")
  'fixed-large': 60, // Large (56"+)
  
  // Tilt Mount (Up/Down Adjustment)
  'tilt-small': 50, // Small (32"-55")
  'tilt-large': 70, // Large (56"+)
  
  // Full Motion Mount (Swivel, Tilt, Extend)
  'full-motion-small': 80, // Small (32"-55")
  'full-motion-large': 100, // Large (56"+)
};

// Updated Wire Concealment & Electrical Services with only two specific options
const WIRE_CONCEALMENT_PRICES = {
  'no-concealment': 0, // No in-wall concealment (free option)
  'outlet-relocation': 100, // Outlet relocation with wire concealment
};

// Smart Home Installation Prices
const SMART_HOME_PRICES = {
  'doorbell': 75, // Smart Doorbell Installation
  'doorbell-brick': 85, // Smart Doorbell on Brick (+$10)
  'floodlight': 100, // Floodlight Installation
  'camera-standard': 75, // Smart Camera Installation (below 8 feet)
  'camera-high': 100, // Smart Camera Installation (8-12 feet)
  'camera-very-high': 125, // Smart Camera Installation (12-16 feet)
};

// Updated Additional Services Prices
const ADDITIONAL_SERVICE_PRICES = {
  'tv-unmounting': 50, // TV Unmounting Service (per TV)
  'soundbar-basic': 50, // Soundbar Mounting (No Cables Hidden)
  'soundbar-concealed': 75, // Soundbar Mounting + Wire Concealment
  'shelf-installation': 50, // Shelf Installation (per shelf)
};

// Travel Fees
const TRAVEL_BASE_DISTANCE = 20; // Free within 20 miles
const TRAVEL_RATE_PER_MILE = 1; // $1 per mile beyond 20 miles

// Discounts
const LABOR_DISCOUNT_PER_ADDITIONAL_TV = 10; // $10 off per additional TV
const MOUNT_DISCOUNT_PER_ADDITIONAL_MOUNT = 5; // $5 off per additional mount

interface PriceCalculationResult {
  breakdown: Record<string, number>;
  total: number;
}

export const calculateTotalPrice = (data: BookingFormData): PriceCalculationResult => {
  const breakdown: Record<string, number> = {
    basePrice: 0,
    mountsPrice: 0,
    wireConcealment: 0,
    additionalServices: 0,
    smartHomeServices: 0,
    tvUnmounting: 0, // New category for TV unmounting
    travelFee: 0,
    discount: 0,
  };
  
  // Calculate base price for TV mounting
  if (data.mountLocations && data.mountLocations.length > 0) {
    // Start with the base price for each TV
    data.mountLocations.forEach((location, index) => {
      // Base price for standard wall mounting
      breakdown.basePrice += TV_MOUNTING_PRICES.standard;
      
      // Additional fee for special mounting locations
      if (location === 'fireplace') {
        breakdown.basePrice += TV_MOUNTING_PRICES.fireplace;
      } else if (location === 'ceiling') {
        // Replace standard price with ceiling price
        breakdown.basePrice += (TV_MOUNTING_PRICES.ceiling - TV_MOUNTING_PRICES.standard);
      }
    });
  }
  
  // Calculate mount prices if customer needs mounts
  if (data.needsMounts && data.mountTypes && Object.keys(data.mountTypes).length > 0) {
    Object.entries(data.mountTypes).forEach(([index, mountInfo]) => {
      if (mountInfo) { // Add null check here
        const parts = mountInfo.split('-');
        const mountType = parts[0];
        const sizeCategory = parts.length > 1 ? parts[1] : '';
        const mountKey = `${mountType}-${sizeCategory}` as keyof typeof MOUNT_PRICES;
        
        if (MOUNT_PRICES[mountKey]) {
          breakdown.mountsPrice += MOUNT_PRICES[mountKey];
        }
      }
    });
    
    // Apply mount discount for additional mounts
    if (Object.keys(data.mountTypes).length > 1) {
      const additionalMounts = Object.keys(data.mountTypes).length - 1;
      breakdown.discount += additionalMounts * MOUNT_DISCOUNT_PER_ADDITIONAL_MOUNT;
    }
  }
  
  // Cable management
  if (data.cableManagement) {
    breakdown.wireConcealment = WIRE_CONCEALMENT_PRICES[data.cableManagement as keyof typeof WIRE_CONCEALMENT_PRICES] || 0;
  }
  
  // TV Unmounting Service - calculate based on quantity
  if (data.tvUnmountingCount && data.tvUnmountingCount > 0) {
    breakdown.tvUnmounting = data.tvUnmountingCount * ADDITIONAL_SERVICE_PRICES['tv-unmounting'];
  }
  
  // Additional services (excluding TV unmounting which is handled separately)
  if (data.additionalServices && data.additionalServices.length > 0) {
    data.additionalServices.forEach(service => {
      if (service !== 'tv-unmounting') { // Skip TV unmounting as it's calculated based on quantity
        breakdown.additionalServices += ADDITIONAL_SERVICE_PRICES[service as keyof typeof ADDITIONAL_SERVICE_PRICES] || 0;
      }
    });
  }
  
  // Smart home services
  if (data.smartHomeServices && data.smartHomeServices.length > 0) {
    data.smartHomeServices.forEach(service => {
      breakdown.smartHomeServices += SMART_HOME_PRICES[service as keyof typeof SMART_HOME_PRICES] || 0;
    });
  }
  
  // Travel fee (if applicable)
  if (data.distance && data.distance > TRAVEL_BASE_DISTANCE) {
    const extraDistance = data.distance - TRAVEL_BASE_DISTANCE;
    breakdown.travelFee = extraDistance * TRAVEL_RATE_PER_MILE;
  }
  
  // Multi-TV labor discount
  if (data.tvCount && data.tvCount > 1) {
    const additionalTVs = data.tvCount - 1;
    breakdown.discount += additionalTVs * LABOR_DISCOUNT_PER_ADDITIONAL_TV;
  }
  
  // Calculate total
  const total = Object.values(breakdown).reduce((sum, price) => sum + price, 0);
  
  return {
    breakdown,
    total
  };
};

// Helper function to get the price for a specific service
export const getServicePrice = (serviceType: string, variant: string = ''): number => {
  switch (serviceType) {
    case 'tv-mounting':
      return TV_MOUNTING_PRICES.standard;
    case 'fireplace-mounting':
      return TV_MOUNTING_PRICES.standard + TV_MOUNTING_PRICES.fireplace;
    case 'ceiling-mounting':
      return TV_MOUNTING_PRICES.ceiling;
    case 'mount':
      return MOUNT_PRICES[variant as keyof typeof MOUNT_PRICES] || 0;
    case 'wire-concealment':
      return WIRE_CONCEALMENT_PRICES[variant as keyof typeof WIRE_CONCEALMENT_PRICES] || 0;
    case 'smart-home':
      return SMART_HOME_PRICES[variant as keyof typeof SMART_HOME_PRICES] || 0;
    case 'additional-service':
      return ADDITIONAL_SERVICE_PRICES[variant as keyof typeof ADDITIONAL_SERVICE_PRICES] || 0;
    case 'tv-unmounting':
      return ADDITIONAL_SERVICE_PRICES['tv-unmounting'];
    default:
      return 0;
  }
};

// Helper function to format price display
export const formatServicePrice = (price: number, prefix: string = ''): string => {
  return `${prefix}${price > 0 ? '$' + price.toFixed(0) : 'Included'}`;
};