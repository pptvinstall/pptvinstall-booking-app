import React, { useState, useEffect } from 'react';
import { formatCurrency, calculateDiscount } from '../../lib/utils';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { Link } from 'react-router-dom';
import { useStaging } from '../../hooks/useStaging';

interface Service {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

const PricingCalculator: React.FC = () => {
  const [services, setServices] = useState<Service[]>([
    { id: 'basic-tv', name: 'Basic TV Mounting (Customer-provided mount)', price: 100, quantity: 0 },
    { id: 'additional-tv', name: 'Additional TV Mounting', price: 90, quantity: 0 },
    { id: 'fireplace-tv', name: 'Over-fireplace TV Mounting', price: 150, quantity: 0 },
    { id: 'outlet-relocation', name: 'Outlet Relocation (non-fireplace)', price: 50, quantity: 0 },
    { id: 'floodlight-camera', name: 'Floodlight Camera Installation', price: 120, quantity: 0 },
    { id: 'doorbell-camera', name: 'Doorbell Camera Installation', price: 100, quantity: 0 },
    { id: 'security-camera', name: 'Security Camera Installation', price: 110, quantity: 0 },
  ]);

  const [subtotal, setSubtotal] = useState(0);
  const [discount, setDiscount] = useState(0);
  const [total, setTotal] = useState(0);
  const [deposit, setDeposit] = useState(20);
  
  const { showFeedback } = useStaging();

  useEffect(() => {
    // Calculate subtotal
    const newSubtotal = services.reduce((sum, service) => sum + (service.price * service.quantity), 0);
    setSubtotal(newSubtotal);

    // Calculate discount ($10 per additional service)
    const serviceCount = services.reduce((count, service) => count + (service.quantity > 0 ? 1 : 0), 0);
    const newDiscount = calculateDiscount(serviceCount);
    setDiscount(newDiscount);

    // Calculate total
    setTotal(newSubtotal - newDiscount);
  }, [services]);

  const handleQuantityChange = (id: string, quantity: number) => {
    setServices(services.map(service => 
      service.id === id ? { ...service, quantity } : service
    ));
    
    // Log for development tracking
    console.log(`Service ${id} quantity updated to ${quantity}`);
  };
  
  const handleProceedToBooking = () => {
    // Check if any services are selected
    const hasServices = services.some(service => service.quantity > 0);
    
    if (!hasServices) {
      showFeedback(
        'No Services Selected',
        'Please select at least one service before proceeding to booking.',
        'error'
      );
      return;
    }
    
    // Store selected services in localStorage for use in booking form
    localStorage.setItem('pptv_selected_services', JSON.stringify({
      services: services.filter(s => s.quantity > 0),
      subtotal,
      discount,
      total,
      deposit
    }));
    
    console.log('Proceeding to booking with services:', services.filter(s => s.quantity > 0));
  };

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle>Service Pricing Calculator</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {services.map((service) => (
            <div key={service.id} className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-white">{service.name}</p>
                <p className="text-sm text-gray-400">{formatCurrency(service.price)} per unit</p>
              </div>
              <div className="w-24">
                <Input
                  type="number"
                  min="0"
                  value={service.quantity}
                  onChange={(e) => handleQuantityChange(service.id, parseInt(e.target.value) || 0)}
                  className="text-center"
                />
              </div>
            </div>
          ))}

          <div className="mt-6 space-y-2">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>{formatCurrency(subtotal)}</span>
            </div>
            <div className="flex justify-between text-green-500">
              <span>Discount:</span>
              <span>-{formatCurrency(discount)}</span>
            </div>
            <div className="flex justify-between font-bold">
              <span>Total:</span>
              <span>{formatCurrency(total)}</span>
            </div>
            <div className="flex justify-between text-sm text-gray-400">
              <span>Required Deposit ({deposit}%):</span>
              <span>{formatCurrency(total * (deposit / 100))}</span>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-end space-x-4">
        <Link to="/booking">
          <Button onClick={handleProceedToBooking}>
            Proceed to Booking
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
};

export default PricingCalculator;