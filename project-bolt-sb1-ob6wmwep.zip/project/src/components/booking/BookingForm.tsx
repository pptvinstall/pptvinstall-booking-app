import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Select from '../ui/Select';
import { formatCurrency } from '../../lib/utils';
import { useStaging } from '../../hooks/useStaging';
import ComingSoonBadge from '../common/ComingSoonBadge';

interface BookingFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  serviceDate: string;
  serviceTime: string;
  serviceType: string;
  additionalInfo: string;
}

const BookingForm: React.FC = () => {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { isFeatureEnabled, showFeedback, simulateBackendCall } = useStaging();
  
  const { register, handleSubmit, formState: { errors } } = useForm<BookingFormData>();
  
  const timeSlots = [
    { value: '9:00', label: '9:00 AM' },
    { value: '10:00', label: '10:00 AM' },
    { value: '11:00', label: '11:00 AM' },
    { value: '12:00', label: '12:00 PM' },
    { value: '13:00', label: '1:00 PM' },
    { value: '14:00', label: '2:00 PM' },
    { value: '15:00', label: '3:00 PM' },
    { value: '16:00', label: '4:00 PM' },
  ];
  
  const serviceTypes = [
    { value: 'tv-mounting', label: 'TV Mounting' },
    { value: 'smart-home', label: 'Smart Home Installation' },
    { value: 'multiple', label: 'Multiple Services' },
  ];
  
  const states = [
    { value: 'AL', label: 'Alabama' },
    { value: 'AK', label: 'Alaska' },
    { value: 'AZ', label: 'Arizona' },
    // Add more states as needed
    { value: 'WY', label: 'Wyoming' },
  ];

  const onSubmit = async (data: BookingFormData) => {
    setIsSubmitting(true);
    
    // Check if booking feature is enabled
    if (!isFeatureEnabled('enableBooking')) {
      setTimeout(() => {
        setIsSubmitting(false);
        showFeedback(
          'Booking Unavailable',
          'Online booking is currently disabled in this staging environment. Your booking details have been logged to the console.',
          'info'
        );
        console.log('Booking form data:', data);
      }, 1000);
      return;
    }
    
    try {
      // Simulate API call to backend
      await simulateBackendCall(data, true, 1500);
      
      // Move to confirmation step
      setIsSubmitting(false);
      setStep(3);
    } catch (error) {
      setIsSubmitting(false);
      showFeedback(
        'Booking Error',
        'There was an error processing your booking. Please try again later.',
        'error'
      );
    }
  };

  const handlePayment = async () => {
    setIsSubmitting(true);
    
    if (!isFeatureEnabled('enablePayments')) {
      setTimeout(() => {
        setIsSubmitting(false);
        showFeedback(
          'Payment Processing Disabled',
          'Payment processing is currently disabled in this staging environment. In a production environment, this would connect to Square for payment processing.',
          'info'
        );
      }, 1000);
      return;
    }
    
    try {
      // Simulate payment processing
      await simulateBackendCall({ amount: 20, status: 'success' }, true, 1500);
      
      setIsSubmitting(false);
      showFeedback(
        'Booking Confirmed',
        'Your booking has been confirmed! You will receive a confirmation email shortly.',
        'success'
      );
    } catch (error) {
      setIsSubmitting(false);
      showFeedback(
        'Payment Error',
        'There was an error processing your payment. Please try again later.',
        'error'
      );
    }
  };

  const nextStep = () => setStep(step + 1);
  const prevStep = () => setStep(step - 1);

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Book Your Service</CardTitle>
          {!isFeatureEnabled('enableBooking') && (
            <ComingSoonBadge />
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <div className={`h-2 w-1/3 rounded-full ${step >= 1 ? 'bg-blue-500' : 'bg-gray-700'}`}></div>
            <div className={`h-2 w-1/3 rounded-full mx-1 ${step >= 2 ? 'bg-blue-500' : 'bg-gray-700'}`}></div>
            <div className={`h-2 w-1/3 rounded-full ${step >= 3 ? 'bg-blue-500' : 'bg-gray-700'}`}></div>
          </div>
          <div className="flex justify-between text-xs text-gray-400">
            <span>Personal Info</span>
            <span>Service Details</span>
            <span>Payment</span>
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)}>
          {step === 1 && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="First Name"
                  {...register('firstName', { required: 'First name is required' })}
                  error={errors.firstName?.message}
                />
                <Input
                  label="Last Name"
                  {...register('lastName', { required: 'Last name is required' })}
                  error={errors.lastName?.message}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Email"
                  type="email"
                  {...register('email', { 
                    required: 'Email is required',
                    pattern: {
                      value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                      message: 'Invalid email address'
                    }
                  })}
                  error={errors.email?.message}
                />
                <Input
                  label="Phone"
                  type="tel"
                  {...register('phone', { required: 'Phone number is required' })}
                  error={errors.phone?.message}
                />
              </div>
              <Input
                label="Street Address"
                {...register('address', { required: 'Address is required' })}
                error={errors.address?.message}
              />
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Input
                  label="City"
                  {...register('city', { required: 'City is required' })}
                  error={errors.city?.message}
                />
                <Select
                  label="State"
                  options={states}
                  {...register('state', { required: 'State is required' })}
                  error={errors.state?.message}
                />
                <Input
                  label="ZIP Code"
                  {...register('zipCode', { required: 'ZIP code is required' })}
                  error={errors.zipCode?.message}
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="Service Date"
                  type="date"
                  {...register('serviceDate', { required: 'Service date is required' })}
                  error={errors.serviceDate?.message}
                />
                <Select
                  label="Preferred Time"
                  options={timeSlots}
                  {...register('serviceTime', { required: 'Service time is required' })}
                  error={errors.serviceTime?.message}
                />
              </div>
              <Select
                label="Service Type"
                options={serviceTypes}
                {...register('serviceType', { required: 'Service type is required' })}
                error={errors.serviceType?.message}
              />
              <div>
                <label className="block text-sm font-medium text-gray-200 mb-1">
                  Additional Information
                </label>
                <textarea
                  className="flex w-full rounded-md border border-gray-700 bg-gray-800 px-3 py-2 text-sm text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows={4}
                  placeholder="Tell us more about your needs..."
                  {...register('additionalInfo')}
                ></textarea>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="bg-gray-800 p-4 rounded-md">
                <h3 className="text-lg font-medium text-white mb-4">Order Summary</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Service:</span>
                    <span className="text-white">TV Mounting</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Date & Time:</span>
                    <span className="text-white">June 15, 2025 at 10:00 AM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Total:</span>
                    <span className="text-white">{formatCurrency(150)}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-gray-700 mt-2">
                    <span className="text-gray-300">Deposit Due Now:</span>
                    <span className="text-white font-medium">{formatCurrency(20)}</span>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium text-white">Payment Information</h3>
                  {!isFeatureEnabled('enablePayments') && (
                    <ComingSoonBadge />
                  )}
                </div>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 gap-4">
                    <Input
                      label="Card Number"
                      placeholder="1234 5678 9012 3456"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      label="Expiration Date"
                      placeholder="MM/YY"
                    />
                    <Input
                      label="CVC"
                      placeholder="123"
                    />
                  </div>
                  <div>
                    <Input
                      label="Name on Card"
                      placeholder="John Doe"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </form>
      </CardContent>
      <CardFooter className="flex justify-between">
        {step > 1 && (
          <Button variant="outline" onClick={prevStep} disabled={isSubmitting}>
            Back
          </Button>
        )}
        {step < 3 ? (
          <Button onClick={nextStep}>
            Continue
          </Button>
        ) : (
          <Button 
            onClick={handlePayment} 
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Processing...' : 'Complete Booking'}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default BookingForm;