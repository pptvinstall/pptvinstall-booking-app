import React from 'react';
import { cn } from '../../lib/utils';

interface Step {
  id: string;
  title: string;
}

interface StepIndicatorProps {
  steps: Step[];
  currentStep: number;
}

const StepIndicator: React.FC<StepIndicatorProps> = ({ steps, currentStep }) => {
  return (
    <div className="mt-6">
      <div className="flex items-center justify-between mb-2">
        {steps.map((step, index) => (
          <React.Fragment key={step.id}>
            {/* Step circle */}
            <div className="flex flex-col items-center">
              <div 
                className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-300",
                  index < currentStep 
                    ? "bg-blue-500 text-white" 
                    : index === currentStep 
                      ? "bg-blue-500 text-white ring-2 ring-blue-300 ring-opacity-50 scale-110" 
                      : "bg-gray-700 text-gray-400"
                )}
              >
                {index + 1}
              </div>
              <span 
                className={cn(
                  "text-xs mt-1 transition-all duration-300",
                  index === currentStep ? "text-blue-400 font-medium" : "text-gray-500"
                )}
              >
                {step.title}
              </span>
            </div>
            
            {/* Connector line */}
            {index < steps.length - 1 && (
              <div 
                className={cn(
                  "h-1 flex-1 mx-2 transition-all duration-500",
                  index < currentStep ? "bg-blue-500" : "bg-gray-700"
                )}
              />
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

export default StepIndicator;