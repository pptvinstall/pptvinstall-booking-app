import React, { useEffect } from 'react';
import { useFormContext, Controller } from 'react-hook-form';
import { BookingFormData } from '../BookingWizard';
import { Card, CardContent } from '../../ui/Card';
import Tooltip from '../../ui/Tooltip';
import { formatCurrency } from '../../../lib/utils';
import { HelpCircle, Info, Check } from 'lucide-react';

// Mount types with pricing based on TV size
const mountTypes = [
  { 
    type: 'fixed',
    label: 'Fixed Mount',
    description: 'Slim profile, no tilt or swivel',
    compatibleWith: ['drywall', 'brick', 'concrete'],
    prices: {
      'small': 40, // Small (32"-55")
      'large': 60, // Large (56"+)
    }
  },
  { 
    type: 'tilt',
    label: 'Tilting Mount',
    description: 'Allows vertical tilt adjustment',
    compatibleWith: ['drywall', 'brick', 'concrete', 'fireplace'],
    prices: {
      'small': 50, // Small (32"-55")
      'large': 70, // Large (56"+)
    }
  },
  { 
    type: 'full-motion',
    label: 'Full-Motion Mount',
    description: 'Extends, tilts, and swivels',
    compatibleWith: ['drywall', 'brick', 'concrete'],
    prices: {
      'small': 80, // Small (32"-55")
      'large': 100, // Large (56"+)
    }
  },
];

// Special mounts for specific locations
const specialMounts = [
  {
    type: 'ceiling',
    label: 'Ceiling Mount',
    description: 'Hangs from ceiling, adjustable',
    compatibleWith: ['ceiling'],
    price: 100,
  },
  {
    type: 'fireplace-pulldown',
    label: 'Fireplace Pull-Down',
    description: 'Pulls down for eye-level viewing',
    compatibleWith: ['fireplace'],
    price: 150,
  },
];

// Updated cable management options with only two specific choices
const cableManagementOptions = [
  { 
    value: 'no-concealment', 
    label: 'No In-Wall Wire Concealment', 
    price: 0, 
    description: 'Basic cable management without in-wall concealment. Cables will be neatly organized but visible.' 
  },
  { 
    value: 'outlet-relocation', 
    label: 'Outlet Relocation with Wire Concealment', 
    price: 100, 
    description: 'Concealment of cables through the wall with outlet relocation for a clean, wire-free look.' 
  }
];

const EquipmentSelection: React.FC = () => {
  const { control, watch, setValue } = useFormContext<BookingFormData>();
  const tvCount = watch('tvCount');
  const mountLocations = watch('mountLocations');
  const tvSizes = watch('tvSizes');
  const mountTypesSelected = watch('mountTypes');
  const needsMounts = watch('needsMounts');
  const primaryService = watch('primaryService');
  
  // Skip this step if smart-home only is selected
  useEffect(() => {
    if (primaryService === 'smart-home') {
      // Set default values to avoid undefined errors
      setValue('needsMounts', false);
      setValue('cableManagement', 'no-concealment');
    }
  }, [primaryService, setValue]);
  
  // If there are no TVs, don't show TV equipment options
  if (tvCount === 0 || primaryService === 'smart-home') {
    return (
      <div className="bg-gray-800 p-6 rounded-lg animate-fadeIn">
        <h2 className="text-xl font-semibold text-white mb-4">Equipment Selection</h2>
        <p className="text-gray-400 mb-4">
          {primaryService === 'smart-home' 
            ? 'No TV equipment needed for Smart Home Installation. Please proceed to the next step.'
            : 'No TVs selected. Please go back and select at least one TV or choose Smart Home Installation.'}
        </p>
      </div>
    );
  }
  
  // Get compatible mounts based on location and TV size
  const getCompatibleMounts = (locationValue: string, tvSize: string) => {
    // First check for special mounts that are location-specific
    const specialCompatibleMounts = specialMounts.filter(mount => 
      mount.compatibleWith.includes(locationValue)
    );
    
    // Then get standard mounts compatible with this location
    const standardCompatibleMounts = mountTypes.filter(mount => 
      mount.compatibleWith.includes(locationValue)
    );
    
    return [...specialCompatibleMounts, ...standardCompatibleMounts];
  };
  
  // Get price for a mount based on type and TV size
  const getMountPrice = (mountType: string, tvSize: string): number => {
    // Check if it's a special mount
    const specialMount = specialMounts.find(m => m.type === mountType);
    if (specialMount) {
      return specialMount.price;
    }
    
    // Otherwise get price based on type and size
    const mount = mountTypes.find(m => m.type === mountType);
    if (mount && mount.prices[tvSize as keyof typeof mount.prices]) {
      return mount.prices[tvSize as keyof typeof mount.prices];
    }
    
    return 0;
  };
  
  return (
    <div className="space-y-8 animate-fadeIn">
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-white">TV Mounts</h2>
          <Controller
            name="needsMounts"
            control={control}
            render={({ field }) => (
              <div className="flex items-center">
                <span className="text-sm text-gray-400 mr-2">I need mounts:</span>
                <label className="inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={field.value}
                    onChange={(e) => {
                      field.onChange(e.target.checked);
                      // Clear mount types if unchecked
                      if (!e.target.checked) {
                        setValue('mountTypes', {});
                      }
                    }}
                  />
                  <div className="relative w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            )}
          />
        </div>
        
        {needsMounts ? (
          <div className="space-y-4">
            {mountLocations.map((location, index) => {
              const tvSize = tvSizes[index] || 'small';
              const compatibleMounts = getCompatibleMounts(location, tvSize);
              
              return (
                <div key={index} className="bg-gray-800 p-4 rounded-lg transition-all">
                  <h3 className="text-white font-medium mb-3">
                    TV #{index + 1} - {mountingLocationLabel(location)} ({tvSizeLabel(tvSize)})
                  </h3>
                  
                  <Controller
                    name={`mountTypes.${index}`}
                    control={control}
                    render={({ field }) => (
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                        {compatibleMounts.map((mount) => {
                          // For special mounts, we just use the type
                          const isSpecialMount = 'price' in mount;
                          const mountValue = isSpecialMount ? mount.type : `${mount.type}-${tvSize}`;
                          const mountPrice = isSpecialMount 
                            ? (mount as typeof specialMounts[0]).price 
                            : getMountPrice(mount.type, tvSize);
                          
                          const isSelected = field.value === mountValue;
                          
                          return (
                            <div
                              key={mountValue}
                              className={`p-3 rounded-lg border cursor-pointer transition-all ${
                                isSelected 
                                  ? 'border-blue-500 bg-blue-900/20' 
                                  : 'border-gray-700 hover:border-gray-600'
                              }`}
                              onClick={() => {
                                const newMountTypes = { ...mountTypesSelected };
                                newMountTypes[index] = mountValue;
                                setValue('mountTypes', newMountTypes);
                              }}
                            >
                              <div className="flex justify-between items-start mb-1">
                                <span className="text-white font-medium flex items-center">
                                  {mount.label}
                                  {isSelected && <Check className="h-3 w-3 ml-1 text-blue-400" />}
                                </span>
                                <span className="text-sm text-blue-400">{formatCurrency(mountPrice)}</span>
                              </div>
                              <p className="text-xs text-gray-400">{mount.description}</p>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  />
                </div>
              );
            })}
            
            {/* Mount discount info */}
            {tvCount > 1 && (
              <div className="bg-blue-900/30 border border-blue-800 rounded-md p-3 flex items-start">
                <Info className="h-5 w-5 text-blue-400 mr-2 mt-0.5 flex-shrink-0" />
                <p className="text-blue-300 text-sm">
                  Multi-mount discount: $5 off per additional mount will be applied automatically.
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-gray-800 p-4 rounded-lg">
            <p className="text-gray-400">You'll be using your own mounts. Please have them ready on installation day.</p>
          </div>
        )}
      </div>
      
      <div>
        <div className="flex items-center mb-4">
          <h2 className="text-xl font-semibold text-white mr-2">Cable Management</h2>
          <Tooltip content="How your TV cables will be organized and hidden">
            <HelpCircle className="h-4 w-4 text-gray-400" />
          </Tooltip>
        </div>
        
        <Controller
          name="cableManagement"
          control={control}
          render={({ field }) => (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {cableManagementOptions.map((option) => {
                const isSelected = field.value === option.value;
                
                return (
                  <Card 
                    key={option.value}
                    className={`cursor-pointer transition-all ${
                      isSelected
                        ? 'border-blue-500 bg-blue-900/20 transform scale-[1.02]' 
                        : 'border-gray-700 hover:border-gray-500'
                    }`}
                    onClick={() => field.onChange(option.value)}
                  >
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-medium text-white flex items-center">
                          {option.label}
                          {isSelected && <Check className="h-3 w-3 ml-1 text-blue-400" />}
                        </h3>
                        <span className="text-blue-400">{formatCurrency(option.price)}</span>
                      </div>
                      <p className="text-sm text-gray-400">{option.description}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        />
        
        {/* Special note for over-fireplace installations */}
        {mountLocations.includes('fireplace') && (
          <div className="mt-4 bg-yellow-900/30 border border-yellow-800 rounded-md p-3 flex items-start">
            <Info className="h-5 w-5 text-yellow-400 mr-2 mt-0.5 flex-shrink-0" />
            <div className="text-yellow-300 text-sm">
              <p className="font-medium">Over Fireplace Wire Concealment</p>
              <p className="mt-1">For over-fireplace installations, wire concealment may require custom solutions. Please submit a picture of your fireplace and nearest outlet for a custom quote.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Helper function to get the label for a mounting location
const mountingLocationLabel = (locationValue: string): string => {
  const locations = {
    'drywall': 'Standard Wall',
    'fireplace': 'Over Fireplace',
    'brick': 'Brick/Stone Wall',
    'concrete': 'Concrete Wall',
    'ceiling': 'Ceiling Mount'
  };
  return locations[locationValue as keyof typeof locations] || locationValue;
};

// Helper function to get the label for a TV size
const tvSizeLabel = (sizeValue: string): string => {
  const sizes = {
    'small': 'Small (32"-55")',
    'large': 'Large (56"+)'
  };
  return sizes[sizeValue as keyof typeof sizes] || sizeValue;
};

export default EquipmentSelection;