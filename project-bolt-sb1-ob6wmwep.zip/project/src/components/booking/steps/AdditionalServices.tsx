import React from 'react';
import { useFormContext, Controller } from 'react-hook-form';
import { BookingFormData } from '../BookingWizard';
import { Card, CardContent } from '../../ui/Card';
import { Check, HelpCircle, Info } from 'lucide-react';
import Tooltip from '../../ui/Tooltip';
import { formatCurrency } from '../../../lib/utils';

// Updated additional services - removed "Old TV Removal" and renamed "Solo Unmounting Service" to "TV Unmounting"
const additionalServices = [
  { 
    value: 'tv-unmounting', 
    label: 'TV Unmounting', 
    price: 50,
    description: 'Professional removal of TV from wall mount',
    requiresTv: false
  },
  { 
    value: 'soundbar-basic', 
    label: 'Soundbar Mounting (No Cables Hidden)', 
    price: 50,
    description: 'Mount your soundbar below or above your TV',
    requiresTv: true
  },
  { 
    value: 'soundbar-concealed', 
    label: 'Soundbar Mounting + Wire Concealment', 
    price: 75,
    description: 'Mount your soundbar with concealed wiring',
    requiresTv: true
  },
  { 
    value: 'shelf-installation', 
    label: 'Shelf Installation', 
    price: 50,
    description: 'Install shelf for cable box/gaming console (per shelf)',
    requiresTv: true
  },
];

const smartHomeServices = [
  { 
    value: 'doorbell', 
    label: 'Smart Doorbell Installation', 
    price: 75,
    description: 'Installation of wired or wireless smart doorbell'
  },
  { 
    value: 'doorbell-brick', 
    label: 'Smart Doorbell (Brick Installation)', 
    price: 85,
    description: 'Installation on brick surface (+$10 extra)'
  },
  { 
    value: 'floodlight', 
    label: 'Floodlight Installation', 
    price: 100,
    description: 'Installation with wiring to existing junction box'
  },
  { 
    value: 'camera-standard', 
    label: 'Smart Camera (Below 8 feet)', 
    price: 75,
    description: 'Standard height camera installation'
  },
  { 
    value: 'camera-high', 
    label: 'Smart Camera (8-12 feet)', 
    price: 100,
    description: 'High mounting position (+$25)'
  },
  { 
    value: 'camera-very-high', 
    label: 'Smart Camera (12-16 feet)', 
    price: 125,
    description: 'Very high mounting position (+$50)'
  },
];

const AdditionalServices: React.FC = () => {
  const { control, watch, setValue } = useFormContext<BookingFormData>();
  const primaryService = watch('primaryService');
  const tvCount = watch('tvCount');
  const tvUnmountingCount = watch('tvUnmountingCount') || 0;
  const additionalServicesSelected = watch('additionalServices') || [];
  
  // Determine which additional services to show based on service type
  const showTvServices = primaryService === 'tv-mounting' || (primaryService === 'multi-service' && tvCount > 0);
  const showSmartHomeServices = primaryService === 'smart-home' || primaryService === 'multi-service';
  
  // Filter additional services based on TV selection
  const filteredAdditionalServices = additionalServices.filter(service => 
    !service.requiresTv || showTvServices
  );
  
  // Handle TV unmounting quantity change
  const handleTvUnmountingChange = (quantity: number) => {
    setValue('tvUnmountingCount', quantity);
    
    // Add or remove from additionalServices array
    const currentServices = additionalServicesSelected || [];
    if (quantity > 0) {
      if (!currentServices.includes('tv-unmounting')) {
        setValue('additionalServices', [...currentServices, 'tv-unmounting']);
      }
    } else {
      setValue('additionalServices', currentServices.filter(s => s !== 'tv-unmounting'));
    }
  };
  
  // Check if TV unmounting is selected
  const isTvUnmountingSelected = additionalServicesSelected.includes('tv-unmounting');
  
  return (
    <div className="space-y-8 animate-fadeIn">
      {/* TV Unmounting Section - Prominently displayed at the top */}
      <div className="bg-gray-800 p-6 rounded-lg border border-gray-700 shadow-md">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-xl font-semibold text-white">TV Unmounting Service</h2>
            <p className="text-gray-400 mt-1">Need existing TVs removed from the wall? Our technicians can safely unmount them.</p>
          </div>
          <div className="text-blue-400 font-medium">
            {formatCurrency(50)} per TV
          </div>
        </div>
        
        <div className="flex items-center mt-4">
          <button
            type="button"
            className="w-10 h-10 rounded-full bg-gray-700 text-white flex items-center justify-center border border-gray-600 hover:bg-gray-600 transition-colors"
            onClick={() => handleTvUnmountingChange(Math.max(0, tvUnmountingCount - 1))}
          >
            -
          </button>
          <span className="text-xl font-medium text-white w-12 text-center">{tvUnmountingCount}</span>
          <button
            type="button"
            className="w-10 h-10 rounded-full bg-gray-700 text-white flex items-center justify-center border border-gray-600 hover:bg-gray-600 transition-colors"
            onClick={() => handleTvUnmountingChange(tvUnmountingCount + 1)}
          >
            +
          </button>
          <span className="text-gray-400 ml-3">
            {tvUnmountingCount === 0 ? 'No TVs to unmount' : 
             tvUnmountingCount === 1 ? '1 TV to unmount' : `${tvUnmountingCount} TVs to unmount`}
          </span>
          
          {tvUnmountingCount > 0 && (
            <span className="ml-auto text-blue-400">
              {formatCurrency(tvUnmountingCount * 50)}
            </span>
          )}
        </div>
        
        {tvUnmountingCount > 0 && (
          <div className="mt-4 bg-blue-900/30 border border-blue-800 rounded-md p-3 flex items-start">
            <Info className="h-5 w-5 text-blue-400 mr-2 mt-0.5 flex-shrink-0" />
            <p className="text-blue-300 text-sm">
              Our technicians will carefully remove your TV(s) from the wall mount and place them in a safe location of your choice.
            </p>
          </div>
        )}
      </div>
      
      <div>
        <h2 className="text-xl font-semibold text-white mb-4">Additional Services</h2>
        <p className="text-gray-400 mb-4">Select any additional services you need:</p>
        
        <Controller
          name="additionalServices"
          control={control}
          render={({ field }) => (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredAdditionalServices.filter(service => service.value !== 'tv-unmounting').map((service) => {
                const isSelected = field.value?.includes(service.value);
                
                return (
                  <Card 
                    key={service.value}
                    className={`transition-all duration-200 ${
                      isSelected
                        ? 'border-blue-500 bg-blue-900/20 cursor-pointer transform scale-[1.02]' 
                        : 'border-gray-700 hover:border-gray-500 cursor-pointer'
                    }`}
                    onClick={() => {
                      const newValue = isSelected
                        ? field.value?.filter(v => v !== service.value)
                        : [...(field.value || []), service.value];
                      field.onChange(newValue);
                    }}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start">
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center mr-3 mt-0.5 transition-colors ${
                          isSelected ? 'bg-blue-500 text-white' : 'bg-gray-700'
                        }`}>
                          {isSelected && <Check className="h-3 w-3" />}
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <h3 className="font-medium text-white">{service.label}</h3>
                            <span className="text-blue-400 ml-2">{formatCurrency(service.price)}</span>
                          </div>
                          <p className="text-sm text-gray-400 mt-1">{service.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        />
      </div>
      
      {showSmartHomeServices && (
        <div className="animate-fadeIn">
          <h2 className="text-xl font-semibold text-white mb-4">Smart Home Services</h2>
          <p className="text-gray-400 mb-4">Select the smart home devices you need installed:</p>
          
          <Controller
            name="smartHomeServices"
            control={control}
            render={({ field }) => (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {smartHomeServices.map((service) => {
                  const isSelected = field.value?.includes(service.value);
                  
                  return (
                    <Card 
                      key={service.value}
                      className={`cursor-pointer transition-all duration-200 ${
                        isSelected
                          ? 'border-blue-500 bg-blue-900/20 transform scale-[1.02]' 
                          : 'border-gray-700 hover:border-gray-500'
                      }`}
                      onClick={() => {
                        const newValue = isSelected
                          ? field.value?.filter(v => v !== service.value)
                          : [...(field.value || []), service.value];
                        field.onChange(newValue);
                      }}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start">
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center mr-3 mt-0.5 transition-colors ${
                            isSelected ? 'bg-blue-500 text-white' : 'bg-gray-700'
                          }`}>
                            {isSelected && <Check className="h-3 w-3" />}
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between items-start">
                              <h3 className="font-medium text-white">{service.label}</h3>
                              <span className="text-blue-400 ml-2">{formatCurrency(service.price)}</span>
                            </div>
                            <p className="text-sm text-gray-400 mt-1">{service.description}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          />
          
          <div className="mt-4 bg-blue-900/30 border border-blue-800 rounded-md p-3 flex items-start">
            <Info className="h-5 w-5 text-blue-400 mr-2 mt-0.5 flex-shrink-0" />
            <p className="text-blue-300 text-sm">
              Custom pricing is available for multi-camera setups. Please note your requirements in the special instructions.
            </p>
          </div>
        </div>
      )}
      
      {/* Additional Labor Disclaimer */}
      <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
        <div className="flex items-start">
          <Info className="h-5 w-5 text-blue-400 mr-3 mt-1 flex-shrink-0" />
          <div>
            <h3 className="text-lg font-medium text-white mb-2">Additional Labor</h3>
            <p className="text-gray-300 text-sm">
              For tasks beyond our standard scope (such as picture hanging or furniture assembly), additional labor is available at $100 per hour (minimum 1 hour, with additional time billed in 30-minute increments). For example, 2.5 hours of extra work would add an additional $250 to your bill.
            </p>
          </div>
        </div>
      </div>
      
      <div className="bg-gray-800 p-6 rounded-lg border border-gray-700">
        <h2 className="text-lg font-semibold text-white mb-3">Deposit & Payment</h2>
        <div className="space-y-2 text-sm text-gray-300">
          <p>• $20 deposit required to book your appointment</p>
          <p>• Remaining balance due after installation</p>
          <p>• Accepted payment methods: Cash, Zelle, Apple Pay</p>
        </div>
        
        <div className="mt-4 pt-4 border-t border-gray-700">
          <h3 className="text-white font-medium mb-2">Disclaimer</h3>
          <p className="text-xs text-gray-400">
            Picture Perfect TV Install is not responsible for any damages resulting from pre-existing wall conditions, 
            incorrect mount selection, or improper TV weight distribution.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdditionalServices;