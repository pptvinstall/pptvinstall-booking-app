import React, { useEffect } from 'react';
import { useFormContext, Controller } from 'react-hook-form';
import { BookingFormData } from '../BookingWizard';
import { Card, CardContent } from '../../ui/Card';
import { Tv, Home, Wrench, Info, Check } from 'lucide-react';
import Tooltip from '../../ui/Tooltip';
import { formatCurrency } from '../../../lib/utils';
import { getServicePrice, formatServicePrice } from '../../../lib/pricing';

const primaryServices = [
  { value: 'tv-mounting', label: 'TV Mounting', icon: Tv, description: 'Professional TV mounting on various surfaces' },
  { value: 'smart-home', label: 'Smart Home Installation', icon: Home, description: 'Setup and configuration of smart home devices' },
  { value: 'multi-service', label: 'Multiple Services', icon: Wrench, description: 'Combination of TV mounting and smart home services' },
];

const mountingLocations = [
  { value: 'drywall', label: 'Standard Wall (Drywall)', price: 100, description: 'Standard drywall installation for any TV size' },
  { value: 'fireplace', label: 'Over Fireplace', price: 200, description: 'Additional $100 fee due to increased complexity' },
  { value: 'brick', label: 'Brick/Stone Wall', price: 150, description: 'Mounting on brick or stone surfaces' },
  { value: 'concrete', label: 'Concrete Wall', price: 175, description: 'Mounting on concrete surfaces' },
  { value: 'ceiling', label: 'Ceiling Mount', price: 175, description: 'Requires proper ceiling support' },
];

const tvSizeOptions = [
  { value: 'small', label: 'Small (32"-55")', description: 'Standard size for bedrooms and smaller spaces' },
  { value: 'large', label: 'Large (56"+)', description: 'Larger TVs for living rooms and entertainment spaces' },
];

const ServiceSelection: React.FC = () => {
  const { control, watch, setValue, getValues, reset } = useFormContext<BookingFormData>();
  const tvCount = watch('tvCount');
  const mountLocations = watch('mountLocations');
  const tvSizes = watch('tvSizes') || {};
  const primaryService = watch('primaryService');
  
  // Update mount locations when TV count changes
  useEffect(() => {
    if (mountLocations.length > tvCount) {
      setValue('mountLocations', mountLocations.slice(0, tvCount));
    }
  }, [tvCount, mountLocations, setValue]);
  
  // Reset TV-related fields when switching to smart-home only
  useEffect(() => {
    if (primaryService === 'smart-home') {
      setValue('tvCount', 0);
      setValue('mountLocations', []);
      setValue('tvSizes', {});
      setValue('mountTypes', {});
      setValue('needsMounts', false);
      setValue('cableManagement', '');
    } else if (primaryService === 'tv-mounting' && tvCount === 0) {
      setValue('tvCount', 1);
    }
  }, [primaryService, setValue, tvCount]);
  
  // Handle removing TV services from multi-service
  const handleRemoveTvServices = () => {
    if (primaryService === 'multi-service') {
      setValue('tvCount', 0);
      setValue('mountLocations', []);
      setValue('tvSizes', {});
      setValue('mountTypes', {});
      setValue('needsMounts', false);
      setValue('cableManagement', '');
    }
  };
  
  // Handle adding TV services to multi-service
  const handleAddTvServices = () => {
    if (primaryService === 'multi-service' && tvCount === 0) {
      setValue('tvCount', 1);
    }
  };
  
  // Show TV-related options only for TV mounting or multi-service
  const showTvOptions = primaryService === 'tv-mounting' || primaryService === 'multi-service';

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold text-white mb-4">Select Your Primary Service</h2>
        <Controller
          name="primaryService"
          control={control}
          render={({ field }) => (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {primaryServices.map((service) => {
                const Icon = service.icon;
                const isSelected = field.value === service.value;
                
                return (
                  <Card 
                    key={service.value}
                    className={`cursor-pointer transition-all duration-300 transform hover:scale-[1.02] ${
                      isSelected 
                        ? 'border-blue-500 bg-blue-900/20 shadow-md shadow-blue-900/20' 
                        : 'border-gray-700 hover:border-gray-500'
                    }`}
                    onClick={() => field.onChange(service.value)}
                  >
                    <CardContent className="p-4">
                      <div className="flex flex-col items-center text-center p-4">
                        <div className={`p-3 rounded-full mb-3 transition-all ${
                          isSelected 
                            ? 'bg-blue-500/30 text-blue-400 scale-110' 
                            : 'bg-gray-800 text-gray-400'
                        }`}>
                          <Icon className="h-6 w-6" />
                        </div>
                        <h3 className="font-medium text-white mb-2 flex items-center">
                          {service.label}
                          {isSelected && <Check className="h-4 w-4 ml-1 text-blue-400" />}
                        </h3>
                        <p className="text-sm text-gray-400">{service.description}</p>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        />
      </div>
      
      {primaryService === 'multi-service' && (
        <div className="bg-blue-900/30 border border-blue-800 rounded-md p-4 animate-fadeIn">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-white font-medium">Multiple Services Selected</h3>
              <p className="text-sm text-blue-300 mt-1">
                You can include both TV mounting and smart home services
              </p>
            </div>
            <div className="flex space-x-2">
              {tvCount === 0 ? (
                <button
                  type="button"
                  onClick={handleAddTvServices}
                  className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white text-sm rounded transition-colors"
                >
                  Add TV Services
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleRemoveTvServices}
                  className="px-3 py-1 bg-blue-800 hover:bg-blue-700 text-white text-sm rounded transition-colors"
                >
                  Remove TV Services
                </button>
              )}
            </div>
          </div>
        </div>
      )}
      
      {showTvOptions && tvCount > 0 && (
        <div className="animate-fadeIn">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-white">Number of TVs</h2>
              <Tooltip content={
                <div className="max-w-xs">
                  <p>Multi-TV Discounts:</p>
                  <ul className="list-disc pl-4 mt-1">
                    <li>$10 off per additional TV service</li>
                    <li>$5 off per additional mount purchased</li>
                  </ul>
                </div>
              }>
                <div className="text-sm text-blue-400 flex items-center cursor-help">
                  <Info className="h-4 w-4 mr-1" />
                  Multi-TV Discount Available
                </div>
              </Tooltip>
            </div>
            
            <Controller
              name="tvCount"
              control={control}
              rules={{ min: 1, max: 10 }}
              render={({ field }) => (
                <div className="flex items-center space-x-4">
                  <button
                    type="button"
                    className="w-10 h-10 rounded-full bg-gray-800 text-white flex items-center justify-center border border-gray-700 hover:bg-gray-700 transition-colors"
                    onClick={() => field.onChange(Math.max(1, field.value - 1))}
                  >
                    -
                  </button>
                  <span className="text-xl font-medium text-white w-8 text-center">{field.value}</span>
                  <button
                    type="button"
                    className="w-10 h-10 rounded-full bg-gray-800 text-white flex items-center justify-center border border-gray-700 hover:bg-gray-700 transition-colors"
                    onClick={() => field.onChange(Math.min(10, field.value + 1))}
                  >
                    +
                  </button>
                  <span className="text-gray-400 ml-2">
                    {field.value === 1 ? '1 TV' : `${field.value} TVs`}
                  </span>
                </div>
              )}
            />
          </div>
          
          <div className="mt-8">
            <h2 className="text-xl font-semibold text-white mb-4">TV Details</h2>
            <p className="text-gray-400 mb-4">Select the size and mounting location for each TV:</p>
            
            <div className="space-y-6">
              {Array.from({ length: tvCount }).map((_, index) => (
                <div key={index} className="bg-gray-800 p-4 rounded-lg transition-all">
                  <h3 className="text-white font-medium mb-4">TV #{index + 1}</h3>
                  
                  {/* TV Size Selection */}
                  <div className="mb-4">
                    <h4 className="text-gray-300 text-sm mb-2">TV Size:</h4>
                    <Controller
                      name={`tvSizes.${index}`}
                      control={control}
                      render={({ field }) => (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {tvSizeOptions.map((size) => {
                            const isSelected = field.value === size.value;
                            
                            return (
                              <div
                                key={size.value}
                                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                                  isSelected 
                                    ? 'border-blue-500 bg-blue-900/20' 
                                    : 'border-gray-700 hover:border-gray-600'
                                }`}
                                onClick={() => {
                                  const newSizes = { ...tvSizes };
                                  newSizes[index] = size.value;
                                  setValue('tvSizes', newSizes);
                                }}
                              >
                                <div className="flex justify-between items-start">
                                  <div>
                                    <span className="text-white flex items-center">
                                      {size.label}
                                      {isSelected && <Check className="h-3 w-3 ml-1 text-blue-400" />}
                                    </span>
                                    <p className="text-xs text-gray-400 mt-1">{size.description}</p>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    />
                  </div>
                  
                  {/* Mounting Location Selection */}
                  <div>
                    <h4 className="text-gray-300 text-sm mb-2">Mounting Location:</h4>
                    <Controller
                      name={`mountLocations.${index}`}
                      control={control}
                      render={({ field }) => (
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                          {mountingLocations.map((location) => {
                            const isSelected = field.value === location.value;
                            
                            return (
                              <div
                                key={location.value}
                                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                                  isSelected 
                                    ? 'border-blue-500 bg-blue-900/20' 
                                    : 'border-gray-700 hover:border-gray-600'
                                }`}
                                onClick={() => {
                                  const newLocations = [...mountLocations];
                                  newLocations[index] = location.value;
                                  setValue('mountLocations', newLocations);
                                }}
                              >
                                <div className="flex justify-between items-start mb-1">
                                  <span className="text-white flex items-center">
                                    {location.label}
                                    {isSelected && <Check className="h-3 w-3 ml-1 text-blue-400" />}
                                  </span>
                                  <span className="text-sm text-blue-400">{formatCurrency(location.price)}</span>
                                </div>
                                <p className="text-xs text-gray-400">{location.description}</p>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    />
                  </div>
                </div>
              ))}
            </div>
            
            {/* Travel Distance */}
            <div className="mt-6 bg-gray-800 p-4 rounded-lg">
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center">
                  <h4 className="text-white font-medium">Travel Distance</h4>
                  <Tooltip content="Free within 20 miles. $1 per mile beyond 20 miles (round-trip charge).">
                    <Info className="h-4 w-4 text-gray-400 ml-2 cursor-help" />
                  </Tooltip>
                </div>
              </div>
              
              <Controller
                name="distance"
                control={control}
                render={({ field }) => (
                  <div className="flex items-center">
                    <input
                      type="range"
                      min="0"
                      max="100"
                      step="1"
                      value={field.value}
                      onChange={(e) => field.onChange(parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                    />
                    <span className="ml-3 text-white min-w-16 text-right">
                      {field.value} miles
                      {field.value > 20 && (
                        <span className="block text-xs text-blue-400">
                          +${field.value - 20} fee
                        </span>
                      )}
                    </span>
                  </div>
                )}
              />
              <p className="text-xs text-gray-400 mt-2">
                {watch('distance') <= 20 
                  ? 'No travel fee within 20 miles' 
                  : `Travel fee applies: $${watch('distance') - 20} (${watch('distance') - 20} miles beyond free range)`}
              </p>
            </div>
          </div>
        </div>
      )}
      
      {primaryService === 'smart-home' && (
        <div className="bg-gray-800 p-6 rounded-lg animate-fadeIn">
          <h2 className="text-xl font-semibold text-white mb-4">Smart Home Installation</h2>
          <p className="text-gray-400 mb-4">
            You've selected Smart Home Installation. In the next step, you'll be able to select specific smart home devices to install.
          </p>
          <div className="flex items-center text-blue-400 mt-2">
            <Info className="h-5 w-5 mr-2" />
            <p>TV mounting options are not applicable for this service type.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ServiceSelection;