import React from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '../../ui/Card';
import Button from '../../ui/Button';
import { Calendar, Clock, DollarSign, CheckCircle, User, MapPin, ArrowRight, Mail, Phone } from 'lucide-react';
import { formatCurrency } from '../../../lib/utils';
import { Link } from 'react-router-dom';

interface BookingConfirmedProps {
  bookingReference: string;
  customerName: string;
  bookingDate: string;
  bookingTime: string;
  totalPrice: number;
  depositAmount: number;
  onNewBooking: () => void;
}

const BookingConfirmed: React.FC<BookingConfirmedProps> = ({
  bookingReference,
  customerName,
  bookingDate,
  bookingTime,
  totalPrice,
  depositAmount,
  onNewBooking
}) => {
  // Format the date for display
  const formatDate = (dateString: string): string => {
    if (!dateString) return 'Not specified';
    
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch (e) {
      return dateString;
    }
  };
  
  // Format the time for display
  const formatTime = (timeString: string): string => {
    if (!timeString) return 'Not specified';
    
    // If it's in 24-hour format (e.g., "14:00"), convert to 12-hour
    if (timeString.includes(':')) {
      const [hour, minute] = timeString.split(':').map(Number);
      const period = hour >= 12 ? 'PM' : 'AM';
      const hour12 = hour % 12 || 12;
      return `${hour12}:${minute.toString().padStart(2, '0')} ${period}`;
    }
    
    return timeString;
  };
  
  return (
    <div className="max-w-3xl mx-auto animate-fadeIn">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-500/20 mb-6 animate-bounce-once">
          <CheckCircle className="h-10 w-10 text-green-500" />
        </div>
        <h1 className="text-3xl font-bold text-white mb-3">Thanks for Booking!</h1>
        <p className="text-xl text-gray-300">
          Your service has been successfully scheduled
        </p>
      </div>
      
      <Card className="mb-8 shadow-lg border-green-700/30">
        <CardHeader className="bg-gray-800/50">
          <CardTitle>Booking Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 p-6">
          <div className="flex justify-between items-center pb-4 border-b border-gray-700">
            <div className="flex items-center">
              <div className="bg-blue-500/20 p-3 rounded-full mr-4">
                <Calendar className="h-6 w-6 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-gray-400">Booking Reference</p>
                <p className="text-lg font-medium text-white">{bookingReference}</p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-start">
              <div className="bg-blue-500/20 p-3 rounded-full mr-4 mt-1">
                <User className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-gray-400">Customer</p>
                <p className="text-lg font-medium text-white">{customerName || 'Not specified'}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-blue-500/20 p-3 rounded-full mr-4 mt-1">
                <MapPin className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-gray-400">Service Type</p>
                <p className="text-lg font-medium text-white">TV Mounting & Installation</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-blue-500/20 p-3 rounded-full mr-4 mt-1">
                <Calendar className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-gray-400">Appointment Date</p>
                <p className="text-lg font-medium text-white">{formatDate(bookingDate)}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-blue-500/20 p-3 rounded-full mr-4 mt-1">
                <Clock className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-gray-400">Appointment Time</p>
                <p className="text-lg font-medium text-white">{formatTime(bookingTime)}</p>
              </div>
            </div>
          </div>
          
          <div className="pt-4 border-t border-gray-700">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-300">Total Amount:</span>
              <span className="text-xl font-semibold text-white">{formatCurrency(totalPrice)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Deposit Due:</span>
              <span className="text-green-400 font-medium">{formatCurrency(depositAmount)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Balance Due at Installation:</span>
              <span className="text-gray-300">{formatCurrency(totalPrice - depositAmount)}</span>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <div className="bg-blue-900/30 border border-blue-800 rounded-lg p-6 mb-8 shadow-md">
        <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
          <DollarSign className="h-5 w-5 mr-2" />
          Next Steps
        </h2>
        <div className="space-y-4 text-blue-100">
          <div className="flex items-start">
            <Mail className="h-5 w-5 mr-3 mt-1 text-blue-400" />
            <div>
              <p className="font-medium">Check Your Email</p>
              <p className="text-sm mt-1">
                A confirmation email has been sent with all booking details and payment instructions.
              </p>
            </div>
          </div>
          
          <div className="flex items-start">
            <DollarSign className="h-5 w-5 mr-3 mt-1 text-blue-400" />
            <div>
              <p className="font-medium">Complete Your Deposit</p>
              <p className="text-sm mt-1">
                Please complete your deposit payment of {formatCurrency(depositAmount)} to confirm your booking.
                The remaining balance of {formatCurrency(totalPrice - depositAmount)} will be due upon completion of the service.
              </p>
            </div>
          </div>
          
          <div className="flex items-start">
            <Phone className="h-5 w-5 mr-3 mt-1 text-blue-400" />
            <div>
              <p className="font-medium">Expect a Call</p>
              <p className="text-sm mt-1">
                Our team will call you 24 hours before your appointment to confirm the details.
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row justify-center gap-4">
        <Button onClick={onNewBooking} variant="outline" className="transition-all hover:bg-gray-800">
          Book Another Service
        </Button>
        <Link to="/" className="inline-block">
          <Button className="transition-all">
            Return to Homepage
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default BookingConfirmed;