import React, { useState, useEffect } from 'react';
import { useFormContext } from 'react-hook-form';
import { BookingFormData } from '../BookingWizard';
import Input from '../../ui/Input';
import Select from '../../ui/Select';
import { AlertTriangle, MapPin, Info } from 'lucide-react';
import { calculateDistanceFromDecatur } from '../../../lib/geolocation';

const CustomerInfo: React.FC = () => {
  const { register, formState: { errors }, watch, setValue } = useFormContext<BookingFormData>();
  const [isCalculatingDistance, setIsCalculatingDistance] = useState(false);
  const [addressError, setAddressError] = useState('');
  
  const address = watch('address');
  const city = watch('city');
  const state = watch('state');
  const zipCode = watch('zipCode');
  
  // Calculate distance when address is complete
  useEffect(() => {
    const calculateDistance = async () => {
      if (address && city && state && zipCode) {
        setIsCalculatingDistance(true);
        setAddressError('');
        
        try {
          const fullAddress = `${address}, ${city}, ${state} ${zipCode}`;
          const distance = await calculateDistanceFromDecatur(fullAddress);
          
          if (distance > 0) {
            setValue('distance', Math.round(distance));
            setAddressError('');
          } else {
            setAddressError('Unable to calculate distance. Please check your address.');
          }
        } catch (error) {
          console.error('Error calculating distance:', error);
          setAddressError('Error calculating distance. Please check your address and try again.');
        } finally {
          setIsCalculatingDistance(false);
        }
      }
    };
    
    calculateDistance();
  }, [address, city, state, zipCode, setValue]);
  
  // Generate time slots from 8 AM to 6 PM
  const generateTimeSlots = () => {
    const slots = [];
    for (let hour = 8; hour <= 18; hour++) {
      const hourFormatted = hour > 12 ? hour - 12 : hour;
      const amPm = hour >= 12 ? 'PM' : 'AM';
      slots.push({ 
        value: `${hour}:00`, 
        label: `${hourFormatted}:00 ${amPm}` 
      });
      
      if (hour < 18) {
        slots.push({ 
          value: `${hour}:30`, 
          label: `${hourFormatted}:30 ${amPm}` 
        });
      }
    }
    return slots;
  };
  
  // Generate dates for the next 14 days
  const generateAvailableDates = () => {
    const dates = [];
    const today = new Date();
    
    for (let i = 1; i <= 14; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      
      // Skip Sundays (0 is Sunday in JavaScript's getDay())
      if (date.getDay() !== 0) {
        const formattedDate = date.toISOString().split('T')[0];
        const displayDate = date.toLocaleDateString('en-US', { 
          weekday: 'short', 
          month: 'short', 
          day: 'numeric' 
        });
        
        dates.push({
          value: formattedDate,
          label: displayDate
        });
      }
    }
    
    return dates;
  };
  
  const states = [
    { value: 'AL', label: 'Alabama' },
    { value: 'AK', label: 'Alaska' },
    { value: 'AZ', label: 'Arizona' },
    { value: 'AR', label: 'Arkansas' },
    { value: 'CA', label: 'California' },
    { value: 'CO', label: 'Colorado' },
    { value: 'CT', label: 'Connecticut' },
    { value: 'DE', label: 'Delaware' },
    { value: 'FL', label: 'Florida' },
    { value: 'GA', label: 'Georgia' },
    { value: 'HI', label: 'Hawaii' },
    { value: 'ID', label: 'Idaho' },
    { value: 'IL', label: 'Illinois' },
    { value: 'IN', label: 'Indiana' },
    { value: 'IA', label: 'Iowa' },
    { value: 'KS', label: 'Kansas' },
    { value: 'KY', label: 'Kentucky' },
    { value: 'LA', label: 'Louisiana' },
    { value: 'ME', label: 'Maine' },
    { value: 'MD', label: 'Maryland' },
    { value: 'MA', label: 'Massachusetts' },
    { value: 'MI', label: 'Michigan' },
    { value: 'MN', label: 'Minnesota' },
    { value: 'MS', label: 'Mississippi' },
    { value: 'MO', label: 'Missouri' },
    { value: 'MT', label: 'Montana' },
    { value: 'NE', label: 'Nebraska' },
    { value: 'NV', label: 'Nevada' },
    { value: 'NH', label: 'New Hampshire' },
    { value: 'NJ', label: 'New Jersey' },
    { value: 'NM', label: 'New Mexico' },
    { value: 'NY', label: 'New York' },
    { value: 'NC', label: 'North Carolina' },
    { value: 'ND', label: 'North Dakota' },
    { value: 'OH', label: 'Ohio' },
    { value: 'OK', label: 'Oklahoma' },
    { value: 'OR', label: 'Oregon' },
    { value: 'PA', label: 'Pennsylvania' },
    { value: 'RI', label: 'Rhode Island' },
    { value: 'SC', label: 'South Carolina' },
    { value: 'SD', label: 'South Dakota' },
    { value: 'TN', label: 'Tennessee' },
    { value: 'TX', label: 'Texas' },
    { value: 'UT', label: 'Utah' },
    { value: 'VT', label: 'Vermont' },
    { value: 'VA', label: 'Virginia' },
    { value: 'WA', label: 'Washington' },
    { value: 'WV', label: 'West Virginia' },
    { value: 'WI', label: 'Wisconsin' },
    { value: 'WY', label: 'Wyoming' },
  ];
  
  const distance = watch('distance') || 0;
  const travelFee = distance > 20 ? (distance - 20) : 0;
  
  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h2 className="text-xl font-semibold text-white mb-4">Your Information</h2>
        <p className="text-gray-400 mb-4">Please provide your contact details and preferred installation time:</p>
        
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="First Name"
              {...register('firstName', { required: 'First name is required' })}
              error={errors.firstName?.message}
            />
            <Input
              label="Last Name"
              {...register('lastName', { required: 'Last name is required' })}
              error={errors.lastName?.message}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Email"
              type="email"
              {...register('email', { 
                required: 'Email is required',
                pattern: {
                  value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                  message: 'Invalid email address'
                }
              })}
              error={errors.email?.message}
            />
            <Input
              label="Phone"
              type="tel"
              {...register('phone', { required: 'Phone number is required' })}
              error={errors.phone?.message}
            />
          </div>
          
          <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
            <div className="flex items-center mb-3">
              <MapPin className="h-5 w-5 text-blue-400 mr-2" />
              <h3 className="text-lg font-medium text-white">Service Address</h3>
            </div>
            
            <div className="space-y-4">
              <Input
                label="Street Address"
                {...register('address', { required: 'Address is required' })}
                error={errors.address?.message}
              />
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Input
                  label="City"
                  {...register('city', { required: 'City is required' })}
                  error={errors.city?.message}
                />
                <Select
                  label="State"
                  options={states}
                  {...register('state', { required: 'State is required' })}
                  error={errors.state?.message}
                />
                <Input
                  label="ZIP Code"
                  {...register('zipCode', { required: 'ZIP code is required' })}
                  error={errors.zipCode?.message}
                />
              </div>
              
              {isCalculatingDistance && (
                <div className="flex items-center text-blue-400 text-sm">
                  <svg className="animate-spin -ml-1 mr-3 h-4 w-4 text-blue-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Calculating distance from Decatur, GA...
                </div>
              )}
              
              {addressError && (
                <div className="text-red-400 text-sm flex items-center">
                  <AlertTriangle className="h-4 w-4 mr-1" />
                  {addressError}
                </div>
              )}
              
              {distance > 0 && !isCalculatingDistance && !addressError && (
                <div className="bg-blue-900/30 border border-blue-800 rounded-md p-3 flex items-start">
                  <Info className="h-5 w-5 text-blue-400 mr-2 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-blue-300 text-sm">
                      <span className="font-medium">Distance from Decatur, GA: {distance} miles</span>
                      {distance > 20 && (
                        <>
                          <br />
                          <span>Travel fee: ${travelFee} (${distance - 20} miles beyond 20-mile free range)</span>
                        </>
                      )}
                      {distance <= 20 && (
                        <>
                          <br />
                          <span>No travel fee within 20 miles</span>
                        </>
                      )}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <div>
        <h2 className="text-xl font-semibold text-white mb-4">Preferred Installation Time</h2>
        
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select
              label="Preferred Date"
              options={generateAvailableDates()}
              {...register('preferredDate', { required: 'Date is required' })}
              error={errors.preferredDate?.message}
            />
            <Select
              label="Preferred Time"
              options={generateTimeSlots()}
              {...register('preferredTime', { required: 'Time is required' })}
              error={errors.preferredTime?.message}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-200 mb-1">
              Special Instructions (Optional)
            </label>
            <textarea
              className="flex w-full rounded-md border border-gray-700 bg-gray-800 px-3 py-2 text-sm text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              rows={4}
              placeholder="Any special instructions or notes for the installation team..."
              {...register('specialInstructions')}
            ></textarea>
          </div>
        </div>
      </div>
      
      <div className="bg-blue-900/30 border border-blue-800 rounded-md p-4 flex">
        <AlertTriangle className="h-5 w-5 text-blue-400 mr-3 mt-0.5 flex-shrink-0" />
        <div>
          <p className="text-blue-300 text-sm">
            By completing this booking, you agree to our terms of service. A deposit will be required to confirm your appointment, with the balance due upon completion of service.
          </p>
        </div>
      </div>
    </div>
  );
};

export default CustomerInfo;