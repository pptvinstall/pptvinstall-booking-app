import React from 'react';
import { useFormContext } from 'react-hook-form';
import { BookingFormData } from '../BookingWizard';
import { formatCurrency } from '../../../lib/utils';
import { Card, CardContent } from '../../ui/Card';
import { Check, AlertTriangle } from 'lucide-react';

interface BookingSummaryProps {
  priceBreakdown: Record<string, number>;
}

const BookingSummary: React.FC<BookingSummaryProps> = ({ priceBreakdown }) => {
  const { watch } = useFormContext<BookingFormData>();
  
  const formData = watch();
  const totalPrice = Object.values(priceBreakdown).reduce((sum, price) => sum + price, 0);
  const depositAmount = Math.max(20, totalPrice * 0.2); // 20% deposit or minimum $20
  
  // Helper function to get service name from value
  const getServiceName = (value: string): string => {
    const services: Record<string, string> = {
      'tv-mounting': 'TV Mounting',
      'smart-home': 'Smart Home Installation',
      'multi-service': 'Multiple Services',
      'tv-unmounting': 'TV Unmounting',
      'soundbar-basic': 'Soundbar Mounting (Basic)',
      'soundbar-concealed': 'Soundbar Mounting with Wire Concealment',
      'shelf-installation': 'Shelf Installation',
      'doorbell': 'Smart Doorbell Installation',
      'doorbell-brick': 'Smart Doorbell (Brick Installation)',
      'floodlight': 'Floodlight Installation',
      'camera-standard': 'Smart Camera (Below 8 feet)',
      'camera-high': 'Smart Camera (8-12 feet)',
      'camera-very-high': 'Smart Camera (12-16 feet)',
    };
    
    return services[value] || value;
  };
  
  // Helper function to get mount type name
  const getMountTypeName = (value: string): string => {
    if (!value) return 'Not specified';
    
    if (value.includes('-')) {
      const [type, size] = value.split('-');
      
      const mountTypes: Record<string, string> = {
        'fixed': 'Fixed Mount',
        'tilt': 'Tilting Mount',
        'full-motion': 'Full-Motion Mount',
        'ceiling': 'Ceiling Mount',
        'fireplace-pulldown': 'Fireplace Pull-Down Mount',
      };
      
      const sizeLabels: Record<string, string> = {
        'small': 'Small (32"-55")',
        'large': 'Large (56"+)',
      };
      
      return `${mountTypes[type] || type} - ${sizeLabels[size] || size}`;
    }
    
    // For special mounts that don't have size
    const specialMounts: Record<string, string> = {
      'ceiling': 'Ceiling Mount',
      'fireplace-pulldown': 'Fireplace Pull-Down Mount',
    };
    
    return specialMounts[value] || value;
  };
  
  // Helper function to get location name
  const getLocationName = (value: string): string => {
    const locations: Record<string, string> = {
      'drywall': 'Standard Wall (Drywall)',
      'fireplace': 'Over Fireplace',
      'brick': 'Brick/Stone Wall',
      'concrete': 'Concrete Wall',
      'ceiling': 'Ceiling Mount'
    };
    
    return locations[value] || value;
  };
  
  // Helper function to get cable management name
  const getCableManagementName = (value: string): string => {
    const options: Record<string, string> = {
      'no-concealment': 'No In-Wall Wire Concealment',
      'partial-concealment': 'Partial Wire Concealment',
      'full-concealment': 'Full Wire Concealment',
      'basic': 'Basic Cable Management',
      'concealed': 'Concealed Cable Management',
      'raceway': 'Cable Raceway',
      'none': 'No Cable Management',
    };
    
    return options[value] || value;
  };
  
  // Helper function to get TV size name
  const getTvSizeName = (value: string): string => {
    const sizes: Record<string, string> = {
      'small': 'Small (32"-55")',
      'large': 'Large (56"+)'
    };
    return sizes[value] || value;
  };
  
  // Determine if we have TV services
  const hasTvServices = formData.primaryService === 'tv-mounting' || 
                        (formData.primaryService === 'multi-service' && formData.tvCount > 0);
  
  // Determine if we have smart home services
  const hasSmartHomeServices = formData.primaryService === 'smart-home' || 
                              (formData.primaryService === 'multi-service' && formData.smartHomeServices?.length > 0);
  
  // Check if TV unmounting is selected
  const hasTvUnmounting = formData.tvUnmountingCount > 0;
  
  return (
    <div className="space-y-6 animate-fadeIn">
      <div>
        <h2 className="text-xl font-semibold text-white mb-4">Booking Summary</h2>
        <p className="text-gray-400 mb-4">Review your selections before proceeding to checkout:</p>
        
        <div className="space-y-4">
          <Card className="border-gray-700 shadow-md hover:shadow-lg transition-shadow">
            <CardContent className="p-4">
              <h3 className="font-medium text-white mb-3">Selected Services</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-300">Primary Service:</span>
                  <span className="text-white">{getServiceName(formData.primaryService)}</span>
                </div>
                
                {hasTvServices && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Number of TVs:</span>
                      <span className="text-white">{formData.tvCount}</span>
                    </div>
                    
                    <div className="pt-2 border-t border-gray-700 mt-2">
                      <span className="text-gray-300">TV Details:</span>
                      <ul className="mt-1 space-y-1">
                        {formData.mountLocations.map((location, index) => (
                          <li key={index} className="flex justify-between">
                            <span className="text-gray-400">TV #{index + 1}:</span>
                            <span className="text-white">
                              {getTvSizeName(formData.tvSizes[index] || 'small')} - {getLocationName(location)}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </>
                )}
                
                {hasTvUnmounting && (
                  <div className="flex justify-between pt-2 border-t border-gray-700 mt-2">
                    <span className="text-gray-300">TV Unmounting:</span>
                    <span className="text-white">{formData.tvUnmountingCount} {formData.tvUnmountingCount === 1 ? 'TV' : 'TVs'}</span>
                  </div>
                )}
                
                {formData.distance > 0 && (
                  <div className="flex justify-between pt-2 border-t border-gray-700 mt-2">
                    <span className="text-gray-300">Travel Distance:</span>
                    <span className="text-white">{formData.distance} miles {formData.distance > 20 ? `(${formData.distance - 20} miles beyond free range)` : '(No fee)'}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
          {hasTvServices && (
            <Card className="border-gray-700 shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="p-4">
                <h3 className="font-medium text-white mb-3">Equipment</h3>
                <div className="space-y-2">
                  {formData.needsMounts ? (
                    <div>
                      <span className="text-gray-300">Selected Mounts:</span>
                      <ul className="mt-1 space-y-1">
                        {Object.entries(formData.mountTypes || {}).map(([index, type]) => (
                          <li key={index} className="flex justify-between">
                            <span className="text-gray-400">TV #{parseInt(index) + 1}:</span>
                            <span className="text-white">{getMountTypeName(type)}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ) : (
                    <div className="flex justify-between">
                      <span className="text-gray-300">Mounts:</span>
                      <span className="text-white">Customer Provided</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between pt-2 border-t border-gray-700 mt-2">
                    <span className="text-gray-300">Cable Management:</span>
                    <span className="text-white">{getCableManagementName(formData.cableManagement)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          
          <Card className="border-gray-700 shadow-md hover:shadow-lg transition-shadow">
            <CardContent className="p-4">
              <h3 className="font-medium text-white mb-3">Additional Services</h3>
              {(formData.additionalServices && formData.additionalServices.length > 0) || hasTvUnmounting ? (
                <ul className="space-y-1 mb-3">
                  {hasTvUnmounting && (
                    <li className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-2" />
                      <span className="text-white">TV Unmounting ({formData.tvUnmountingCount} {formData.tvUnmountingCount === 1 ? 'TV' : 'TVs'})</span>
                    </li>
                  )}
                  {formData.additionalServices && formData.additionalServices
                    .filter(service => service !== 'tv-unmounting') // Skip TV unmounting as it's shown separately
                    .map((service) => (
                      <li key={service} className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-2" />
                        <span className="text-white">{getServiceName(service)}</span>
                      </li>
                    ))}
                </ul>
              ) : (
                <p className="text-gray-400 mb-3">No additional services selected</p>
              )}
              
              {hasSmartHomeServices && formData.smartHomeServices && formData.smartHomeServices.length > 0 && (
                <div className="pt-2 border-t border-gray-700 mt-2 mb-3">
                  <span className="text-gray-300">Smart Home Services:</span>
                  <ul className="mt-1 space-y-1">
                    {formData.smartHomeServices.map((service) => (
                      <li key={service} className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-2" />
                        <span className="text-white">{getServiceName(service)}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700 shadow-md hover:shadow-lg transition-shadow">
            <CardContent className="p-4">
              <h3 className="font-medium text-white mb-3">Price Breakdown</h3>
              <div className="space-y-2">
                {Object.entries(priceBreakdown).map(([key, price]) => (
                  price !== 0 && (
                    <div key={key} className="flex justify-between">
                      <span className="text-gray-300">{formatBreakdownKey(key)}:</span>
                      <span className={key === 'discount' ? 'text-green-400' : 'text-white'}>
                        {key === 'discount' ? `-${formatCurrency(price)}` : formatCurrency(price)}
                      </span>
                    </div>
                  )
                ))}
                
                <div className="flex justify-between pt-2 border-t border-gray-700 mt-2 font-medium">
                  <span className="text-gray-200">Total:</span>
                  <span className="text-white">{formatCurrency(totalPrice)}</span>
                </div>
                
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Deposit Due Now:</span>
                  <span className="text-blue-400">{formatCurrency(depositAmount)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Balance Due at Installation:</span>
                  <span className="text-gray-300">{formatCurrency(totalPrice - depositAmount)}</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="bg-blue-900/30 border border-blue-800 rounded-md p-4 flex">
            <AlertTriangle className="h-5 w-5 text-blue-400 mr-3 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-blue-300 text-sm">
                Please review all details carefully. In the next step, you'll provide your contact information to complete the booking.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper function to format breakdown keys for display
const formatBreakdownKey = (key: string): string => {
  const formattedKeys: Record<string, string> = {
    'basePrice': 'Base Installation',
    'mountsPrice': 'TV Mounts',
    'wireConcealment': 'Cable Management',
    'additionalServices': 'Additional Services',
    'smartHomeServices': 'Smart Home Services',
    'tvUnmounting': 'TV Unmounting',
    'travelFee': 'Travel Fee',
    'discount': 'Multi-TV/Mount Discount',
  };
  
  return formattedKeys[key] || key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
};

export default BookingSummary;