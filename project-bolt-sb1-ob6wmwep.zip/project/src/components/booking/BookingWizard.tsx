import React, { useState, useEffect, useMemo } from 'react';
import { useForm, FormProvider, useWatch } from 'react-hook-form';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';
import Button from '../ui/Button';
import { ChevronLeft, ChevronRight, AlertTriangle } from 'lucide-react';
import { useStaging } from '../../hooks/useStaging';
import ServiceSelection from './steps/ServiceSelection';
import EquipmentSelection from './steps/EquipmentSelection';
import AdditionalServices from './steps/AdditionalServices';
import BookingSummary from './steps/BookingSummary';
import CustomerInfo from './steps/CustomerInfo';
import BookingConfirmed from './steps/BookingConfirmed';
import StepIndicator from './StepIndicator';
import { formatCurrency } from '../../lib/utils';
import { calculateTotalPrice } from '../../lib/pricing';

export type BookingFormData = {
  // Service Selection
  primaryService: string;
  tvCount: number;
  mountLocations: string[];
  tvSizes: Record<string, string>; // small (32"-55") or large (56"+)
  
  // Equipment
  mountTypes: Record<string, string>; // type-size format (e.g., "fixed-small")
  needsMounts: boolean;
  cableManagement: string;
  
  // Additional Services
  additionalServices: string[];
  tvUnmountingCount: number; // New field for TV unmounting quantity
  smartHomeServices: string[];
  distance: number;
  
  // Customer Info
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  preferredDate: string;
  preferredTime: string;
  specialInstructions: string;
};

const steps = [
  { id: 'services', title: 'Services' },
  { id: 'equipment', title: 'Equipment' },
  { id: 'additional', title: 'Add-ons' },
  { id: 'summary', title: 'Summary' },
  { id: 'customer', title: 'Your Info' },
];

const BookingWizard: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [priceBreakdown, setPriceBreakdown] = useState<Record<string, number>>({});
  const [errors, setErrors] = useState<string[]>([]);
  const [isBookingConfirmed, setIsBookingConfirmed] = useState(false);
  const [bookingReference, setBookingReference] = useState('');
  const { isFeatureEnabled, showFeedback, simulateBackendCall } = useStaging();
  
  const methods = useForm<BookingFormData>({
    defaultValues: {
      primaryService: '',
      tvCount: 1,
      mountLocations: [],
      tvSizes: {},
      mountTypes: {},
      needsMounts: true,
      cableManagement: 'no-concealment', // Updated default value
      additionalServices: [],
      tvUnmountingCount: 0, // Initialize TV unmounting count
      smartHomeServices: [],
      distance: 0,
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
      preferredDate: '',
      preferredTime: '',
      specialInstructions: '',
    }
  });
  
  const watchedValues = useWatch({
    control: methods.control
  });
  
  // Calculate price whenever form values change
  useEffect(() => {
    try {
      const { breakdown, total } = calculateTotalPrice(watchedValues as BookingFormData);
      setPriceBreakdown(breakdown);
    } catch (error) {
      console.error("Error calculating price:", error);
      // Set default empty breakdown to prevent UI errors
      setPriceBreakdown({});
    }
  }, [watchedValues]);
  
  // Determine if equipment step should be shown
  const shouldShowEquipmentStep = useMemo(() => {
    const primaryService = methods.getValues('primaryService');
    const tvCount = methods.getValues('tvCount');
    
    return primaryService !== 'smart-home' && tvCount > 0;
  }, [methods.getValues('primaryService'), methods.getValues('tvCount')]);
  
  // Get visible steps based on service selection
  const visibleSteps = useMemo(() => {
    if (shouldShowEquipmentStep) {
      return steps;
    } else {
      return steps.filter(step => step.id !== 'equipment');
    }
  }, [shouldShowEquipmentStep]);
  
  // Skip equipment step for smart-home only service
  const getNextStep = (currentStep: number): number => {
    const primaryService = methods.getValues('primaryService');
    const tvCount = methods.getValues('tvCount');
    
    // If smart-home only and moving from services to equipment, skip to additional services
    if (currentStep === 0 && !shouldShowEquipmentStep) {
      return 1; // Skip to additional services (which is now at index 1 in visibleSteps)
    }
    
    return Math.min(currentStep + 1, visibleSteps.length - 1);
  };
  
  // Map visible step index to actual step content
  const getActualStepContent = (visibleStepIndex: number): React.ReactNode => {
    if (!shouldShowEquipmentStep && visibleStepIndex >= 1) {
      // Adjust index to account for skipped equipment step
      const actualIndex = visibleStepIndex + 1;
      
      switch (actualIndex) {
        case 2: return <AdditionalServices />;
        case 3: return <BookingSummary priceBreakdown={priceBreakdown} />;
        case 4: return <CustomerInfo />;
        default: return null;
      }
    } else {
      switch (visibleStepIndex) {
        case 0: return <ServiceSelection />;
        case 1: return <EquipmentSelection />;
        case 2: return <AdditionalServices />;
        case 3: return <BookingSummary priceBreakdown={priceBreakdown} />;
        case 4: return <CustomerInfo />;
        default: return null;
      }
    }
  };
  
  // Validate current step before proceeding
  const validateCurrentStep = (): boolean => {
    const newErrors: string[] = [];
    const primaryService = methods.getValues('primaryService');
    const tvCount = methods.getValues('tvCount');
    
    if (currentStep === 0) {
      if (!primaryService) {
        newErrors.push('Please select a primary service');
      }
      
      // Only validate TV-related fields if TV mounting is selected
      if (primaryService === 'tv-mounting' || 
          (primaryService === 'multi-service' && tvCount > 0)) {
        
        if (watchedValues.mountLocations.length === 0) {
          newErrors.push('Please select at least one mounting location');
        }
        
        // Check if TV sizes are selected for all TVs
        if (tvCount > 0) {
          const tvSizesSelected = Object.keys(watchedValues.tvSizes || {}).length;
          if (tvSizesSelected < tvCount) {
            newErrors.push(`Please select sizes for all ${tvCount} TVs`);
          }
        }
      }
    }
    
    if (currentStep === 1 && shouldShowEquipmentStep) {
      // Only validate mount types if "I need mounts" is checked
      if (watchedValues.needsMounts) {
        const mountsSelected = Object.keys(watchedValues.mountTypes || {}).length;
        if (mountsSelected === 0) {
          newErrors.push('Please select mount types for your TVs');
        } else if (mountsSelected !== tvCount) {
          newErrors.push(`Please select mount types for all ${tvCount} TVs`);
        }
      }
      
      if (!watchedValues.cableManagement) {
        newErrors.push('Please select a cable management option');
      }
    }
    
    setErrors(newErrors);
    return newErrors.length === 0;
  };
  
  const nextStep = () => {
    if (validateCurrentStep()) {
      setCurrentStep(prev => getNextStep(prev));
      setErrors([]);
      
      // Scroll to top of form
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };
  
  const prevStep = () => {
    // If we're at additional services and coming from services (skipped equipment)
    if (currentStep === 1 && !shouldShowEquipmentStep) {
      setCurrentStep(0); // Go back to services
    } else {
      setCurrentStep(prev => Math.max(prev - 1, 0));
    }
    setErrors([]);
    
    // Scroll to top of form
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  const onSubmit = async (data: BookingFormData) => {
    setIsSubmitting(true);
    
    // Check if booking feature is enabled
    if (!isFeatureEnabled('enableBooking')) {
      setTimeout(() => {
        setIsSubmitting(false);
        showFeedback(
          'Booking Unavailable',
          'Online booking is currently disabled in this staging environment. Your booking details have been logged to the console.',
          'info'
        );
        console.log('Booking form data:', data);
      }, 1000);
      return;
    }
    
    try {
      // Simulate API call to backend
      const response = await simulateBackendCall(data, true, 1500);
      
      // Generate a booking reference number
      const bookingRef = `PPTV-${Math.floor(100000 + Math.random() * 900000)}`;
      setBookingReference(bookingRef);
      
      // Show booking confirmed page
      setIsBookingConfirmed(true);
      setIsSubmitting(false);
      
      // Scroll to top
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
      setIsSubmitting(false);
      showFeedback(
        'Booking Error',
        'There was an error processing your booking. Please try again later.',
        'error'
      );
    }
  };
  
  const handleNewBooking = () => {
    // Reset form and state
    methods.reset();
    setCurrentStep(0);
    setIsBookingConfirmed(false);
    setBookingReference('');
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  // If booking is confirmed, show the confirmation page
  if (isBookingConfirmed) {
    return (
      <BookingConfirmed 
        bookingReference={bookingReference}
        customerName={`${watchedValues.firstName} ${watchedValues.lastName}`}
        bookingDate={watchedValues.preferredDate}
        bookingTime={watchedValues.preferredTime}
        totalPrice={Object.values(priceBreakdown).reduce((sum, price) => sum + price, 0)}
        depositAmount={Math.max(20, Object.values(priceBreakdown).reduce((sum, price) => sum + price, 0) * 0.2)}
        onNewBooking={handleNewBooking}
      />
    );
  }
  
  const totalPrice = Object.values(priceBreakdown).reduce((sum, price) => sum + price, 0);
  const depositAmount = Math.max(20, totalPrice * 0.2); // 20% deposit or minimum $20
  
  return (
    <FormProvider {...methods}>
      <Card className="w-full max-w-4xl mx-auto shadow-lg border-gray-700">
        <CardHeader className="bg-gray-800/50">
          <div className="flex justify-between items-center">
            <CardTitle>Book Your Service</CardTitle>
            <div className="flex items-center">
              <span className="text-sm text-gray-400 mr-2">Total:</span>
              <span className="text-xl font-bold text-white">{formatCurrency(totalPrice)}</span>
            </div>
          </div>
          <StepIndicator steps={visibleSteps} currentStep={currentStep} />
        </CardHeader>
        
        <CardContent className="p-6">
          {errors.length > 0 && (
            <div className="mb-6 bg-red-900/30 border border-red-800 rounded-md p-4 animate-fadeIn">
              <div className="flex items-start">
                <AlertTriangle className="h-5 w-5 text-red-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="text-red-400 font-medium">Please correct the following:</h3>
                  <ul className="list-disc pl-5 mt-2 text-red-300 text-sm">
                    {errors.map((error, index) => (
                      <li key={index}>{error}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
          
          <form onSubmit={methods.handleSubmit(onSubmit)} className="animate-fadeIn">
            {getActualStepContent(currentStep)}
          </form>
        </CardContent>
        
        <CardFooter className="flex justify-between border-t border-gray-700 pt-4 bg-gray-800/50">
          <div>
            {currentStep > 0 && (
              <Button 
                type="button" 
                variant="outline" 
                onClick={prevStep}
                disabled={isSubmitting}
                className="transition-all"
              >
                <ChevronLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            )}
          </div>
          
          <div className="flex items-center">
            {currentStep === (shouldShowEquipmentStep ? 3 : 2) && (
              <div className="text-sm text-gray-400 mr-4">
                <span className="block">Deposit due: {formatCurrency(depositAmount)}</span>
                <span className="block text-xs">Balance due at installation</span>
              </div>
            )}
            
            {currentStep < visibleSteps.length - 1 ? (
              <Button 
                type="button" 
                onClick={nextStep}
                className="transition-all"
              >
                Continue
                <ChevronRight className="h-4 w-4 ml-2" />
              </Button>
            ) : (
              <Button 
                type="button"
                onClick={methods.handleSubmit(onSubmit)}
                disabled={isSubmitting}
                className="transition-all"
              >
                {isSubmitting ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </>
                ) : 'Complete Booking'}
              </Button>
            )}
          </div>
        </CardFooter>
      </Card>
    </FormProvider>
  );
};

export default BookingWizard;