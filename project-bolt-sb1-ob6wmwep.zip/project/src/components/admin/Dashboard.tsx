import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '../ui/Card';
import Button from '../ui/Button';
import { Calendar, Users, DollarSign, Clock, LogOut, Settings } from 'lucide-react';
import { useStaging } from '../../hooks/useStaging';
import ComingSoonBadge from '../common/ComingSoonBadge';

// Mock data for demonstration
const mockAppointments = [
  { id: 1, customer: 'John Doe', service: 'TV Mounting', date: '2025-06-15', time: '10:00 AM', status: 'confirmed' },
  { id: 2, customer: 'Jane Smith', service: 'Smart Home Installation', date: '2025-06-16', time: '2:00 PM', status: 'pending' },
  { id: 3, customer: 'Robert Johnson', service: 'TV Mounting', date: '2025-06-17', time: '11:00 AM', status: 'completed' },
  { id: 4, customer: 'Emily Davis', service: 'Security Camera Installation', date: '2025-06-18', time: '9:00 AM', status: 'confirmed' },
  { id: 5, customer: 'Michael Wilson', service: 'Multiple Services', date: '2025-06-19', time: '1:00 PM', status: 'pending' },
];

const Dashboard: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [appointments, setAppointments] = useState(mockAppointments);
  const navigate = useNavigate();
  const { isFeatureEnabled, showFeedback } = useStaging();

  useEffect(() => {
    // Check if user is authenticated
    const auth = localStorage.getItem('pptv_admin_authenticated');
    if (!auth) {
      navigate('/admin');
    } else {
      setIsAuthenticated(true);
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('pptv_admin_authenticated');
    navigate('/admin');
  };

  const handleStatusChange = (id: number, newStatus: string) => {
    if (!isFeatureEnabled('enableAdminDashboard')) {
      showFeedback(
        'Feature Disabled',
        'Status updates are disabled in staging mode. The change has been logged but not applied.',
        'info'
      );
      console.log(`Status change requested: Appointment #${id} to ${newStatus}`);
      return;
    }
    
    setAppointments(appointments.map(appointment => 
      appointment.id === id ? { ...appointment, status: newStatus } : appointment
    ));
  };

  const handleActionClick = (action: string) => {
    showFeedback(
      'Feature Disabled',
      `The "${action}" feature is not available in staging mode.`,
      'info'
    );
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {!isFeatureEnabled('enableAdminDashboard') && (
        <div className="bg-blue-900/30 border border-blue-800 text-blue-300 px-6 py-4 rounded-md mb-8 flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-lg mb-1">Admin Dashboard - Staging Mode</h3>
            <p>This is a limited preview of the admin dashboard. Most features are disabled in staging mode.</p>
          </div>
          <ComingSoonBadge className="ml-4" />
        </div>
      )}
      
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => handleActionClick('Settings')}>
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="bg-blue-500/20 p-3 rounded-full mr-4">
                <Calendar className="h-6 w-6 text-blue-500" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">Upcoming Appointments</p>
                <p className="text-2xl font-semibold text-white">12</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="bg-green-500/20 p-3 rounded-full mr-4">
                <Users className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">Total Customers</p>
                <p className="text-2xl font-semibold text-white">48</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="bg-purple-500/20 p-3 rounded-full mr-4">
                <DollarSign className="h-6 w-6 text-purple-500" />
              </div>
              <div>
                <p className="text-gray-400 text-sm">Monthly Revenue</p>
                <p className="text-2xl font-semibold text-white">$4,250</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Recent Appointments</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">Customer</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">Service</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">Date</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">Time</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">Status</th>
                  <th className="text-left py-3 px-4 text-gray-400 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((appointment) => (
                  <tr key={appointment.id} className="border-b border-gray-800">
                    <td className="py-3 px-4 text-white">{appointment.customer}</td>
                    <td className="py-3 px-4 text-white">{appointment.service}</td>
                    <td className="py-3 px-4 text-white">{appointment.date}</td>
                    <td className="py-3 px-4 text-white">{appointment.time}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-block px-2 py-1 rounded-full text-xs ${
                        appointment.status === 'confirmed' ? 'bg-blue-500/20 text-blue-400' :
                        appointment.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                        'bg-green-500/20 text-green-400'
                      }`}>
                        {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex space-x-2">
                        <select 
                          className="bg-gray-800 border border-gray-700 rounded text-sm px-2 py-1"
                          value={appointment.status}
                          onChange={(e) => handleStatusChange(appointment.id, e.target.value)}
                        >
                          <option value="pending">Pending</option>
                          <option value="confirmed">Confirmed</option>
                          <option value="completed">Completed</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleActionClick('View Details')}
                        >
                          Details
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {appointments.slice(0, 3).map((appointment) => (
                <div key={appointment.id} className="flex items-center p-3 rounded-lg bg-gray-800">
                  <div className="bg-gray-700 p-2 rounded-full mr-4">
                    <Clock className="h-5 w-5 text-blue-500" />
                  </div>
                  <div className="flex-1">
                    <p className="text-white font-medium">{appointment.customer}</p>
                    <p className="text-gray-400 text-sm">{appointment.service}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-white">{appointment.date}</p>
                    <p className="text-gray-400 text-sm">{appointment.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <Button 
                className="h-auto py-4 flex flex-col items-center justify-center"
                onClick={() => handleActionClick('New Appointment')}
              >
                <Calendar className="h-6 w-6 mb-2" />
                <span>New Appointment</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-auto py-4 flex flex-col items-center justify-center"
                onClick={() => handleActionClick('Add Customer')}
              >
                <Users className="h-6 w-6 mb-2" />
                <span>Add Customer</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-auto py-4 flex flex-col items-center justify-center"
                onClick={() => handleActionClick('View Payments')}
              >
                <DollarSign className="h-6 w-6 mb-2" />
                <span>View Payments</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-auto py-4 flex flex-col items-center justify-center"
                onClick={() => handleActionClick('Manage Schedule')}
              >
                <Clock className="h-6 w-6 mb-2" />
                <span>Manage Schedule</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;