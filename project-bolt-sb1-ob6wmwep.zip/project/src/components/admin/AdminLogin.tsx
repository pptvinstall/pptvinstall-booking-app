import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '../ui/Card';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { Lock } from 'lucide-react';
import { useStaging } from '../../hooks/useStaging';
import ComingSoonBadge from '../common/ComingSoonBadge';

const AdminLogin: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const navigate = useNavigate();
  const { isFeatureEnabled, showFeedback, simulateBackendCall } = useStaging();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    
    // In staging mode, accept any non-empty username/password
    try {
      // Simulate API call
      await simulateBackendCall({ username, password }, true, 1000);
      
      // Store authentication state
      localStorage.setItem('pptv_admin_authenticated', 'true');
      
      // Show feedback if admin dashboard is disabled
      if (!isFeatureEnabled('enableAdminDashboard')) {
        showFeedback(
          'Admin Dashboard Limited',
          'The admin dashboard is in staging mode with limited functionality. Some features may be disabled.',
          'info'
        );
      }
      
      navigate('/admin/dashboard');
    } catch (err) {
      setError('An error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-200px)] flex items-center justify-center">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto bg-gray-800 p-3 rounded-full w-16 h-16 flex items-center justify-center mb-4">
            <Lock className="h-8 w-8 text-blue-500" />
          </div>
          <div className="flex justify-center items-center gap-2">
            <CardTitle>Admin Portal</CardTitle>
            {!isFeatureEnabled('enableAdminDashboard') && (
              <ComingSoonBadge />
            )}
          </div>
          <p className="text-gray-400 text-sm mt-2">
            For staging environment, any username and password will work
          </p>
        </CardHeader>
        <CardContent>
          {error && (
            <div className="bg-red-900/30 border border-red-800 text-red-300 px-4 py-3 rounded-md mb-4">
              {error}
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
            <Input
              label="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </form>
        </CardContent>
        <CardFooter>
          <Button 
            className="w-full" 
            onClick={handleSubmit}
            disabled={isLoading}
          >
            {isLoading ? 'Signing in...' : 'Sign In'}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default AdminLogin;