import React from 'react';
import { Link } from 'react-router-dom';
import { Tv, Mail, Phone, MapPin, Facebook, Instagram, BookText as TikTok } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 border-t border-gray-800">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Tv className="h-6 w-6 text-blue-500" />
              <span className="text-xl font-bold text-white">PPTV</span>
            </div>
            <p className="text-gray-400 mb-4">
              Professional TV mounting and smart home installation services.
            </p>
            <div className="flex space-x-4">
              <a href="https://www.facebook.com/PPTVInstall/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="https://www.instagram.com/pptvinstall/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="https://www.tiktok.com/@pptvinstall" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors" aria-label="TikTok">
                <TikTok size={20} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-blue-500 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-gray-400 hover:text-blue-500 transition-colors">
                  Services
                </Link>
              </li>
              <li>
                <Link to="/pricing" className="text-gray-400 hover:text-blue-500 transition-colors">
                  Pricing
                </Link>
              </li>
              <li>
                <Link to="/booking" className="text-gray-400 hover:text-blue-500 transition-colors">
                  Book Now
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-blue-500 transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Services</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/services/tv-mounting" className="text-gray-400 hover:text-blue-500 transition-colors">
                  TV Mounting
                </Link>
              </li>
              <li>
                <Link to="/services/smart-home" className="text-gray-400 hover:text-blue-500 transition-colors">
                  Smart Home Installation
                </Link>
              </li>
              <li>
                <Link to="/services/outlet-relocation" className="text-gray-400 hover:text-blue-500 transition-colors">
                  Outlet Relocation
                </Link>
              </li>
              <li>
                <Link to="/services/security-cameras" className="text-gray-400 hover:text-blue-500 transition-colors">
                  Security Cameras
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-blue-500 mt-0.5" />
                <span className="text-gray-400">Decatur, GA 30034</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-blue-500" />
                <a href="tel:4047024748" className="text-gray-400 hover:text-blue-500 transition-colors">
                  (404) 702-4748
                </a>
              </li>
              <li className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-blue-500" />
                <a href="mailto:pptvinstall@gmail.com" className="text-gray-400 hover:text-blue-500 transition-colors">
                  pptvinstall@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Picture Perfect TV Install. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;