import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Tv, Home, Calendar, User, Facebook, Instagram, BookText as TikTok } from 'lucide-react';
import Button from '../ui/Button';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  // Add scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <header className={`sticky top-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-gray-900/95 backdrop-blur-sm shadow-md' : 'bg-gray-900 border-b border-gray-800'
    }`}>
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2 group">
            <Tv className="h-8 w-8 text-blue-500 transition-transform group-hover:scale-110" />
            <span className="text-xl font-bold text-white">PPTV</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link 
              to="/" 
              className={`text-gray-300 hover:text-white transition-colors ${
                location.pathname === '/' ? 'text-white font-medium' : ''
              }`}
            >
              Home
            </Link>
            <Link 
              to="/services" 
              className={`text-gray-300 hover:text-white transition-colors ${
                location.pathname === '/services' ? 'text-white font-medium' : ''
              }`}
            >
              Services
            </Link>
            <Link 
              to="/pricing" 
              className={`text-gray-300 hover:text-white transition-colors ${
                location.pathname === '/pricing' ? 'text-white font-medium' : ''
              }`}
            >
              Pricing
            </Link>
            <Link 
              to="/booking" 
              className={`text-gray-300 hover:text-white transition-colors ${
                location.pathname === '/booking' ? 'text-white font-medium' : ''
              }`}
            >
              Book Now
            </Link>
            <Link 
              to="/contact" 
              className={`text-gray-300 hover:text-white transition-colors ${
                location.pathname === '/contact' ? 'text-white font-medium' : ''
              }`}
            >
              Contact
            </Link>
            
            <div className="hidden lg:flex items-center space-x-3 ml-4">
              <a href="https://www.facebook.com/PPTVInstall/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors" aria-label="Facebook">
                <Facebook size={18} />
              </a>
              <a href="https://www.instagram.com/pptvinstall/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors" aria-label="Instagram">
                <Instagram size={18} />
              </a>
              <a href="https://www.tiktok.com/@pptvinstall" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors" aria-label="TikTok">
                <TikTok size={18} />
              </a>
            </div>
            
            <Link to="/admin">
              <Button variant="outline" size="sm" className="ml-2">
                Admin Portal
              </Button>
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-300 hover:text-white"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 space-y-4 animate-fadeIn">
            <Link
              to="/"
              className={`flex items-center space-x-2 text-gray-300 hover:text-white transition-colors py-2 ${
                location.pathname === '/' ? 'text-white font-medium' : ''
              }`}
            >
              <Home size={18} />
              <span>Home</span>
            </Link>
            <Link
              to="/services"
              className={`flex items-center space-x-2 text-gray-300 hover:text-white transition-colors py-2 ${
                location.pathname === '/services' ? 'text-white font-medium' : ''
              }`}
            >
              <Tv size={18} />
              <span>Services</span>
            </Link>
            <Link
              to="/pricing"
              className={`flex items-center space-x-2 text-gray-300 hover:text-white transition-colors py-2 ${
                location.pathname === '/pricing' ? 'text-white font-medium' : ''
              }`}
            >
              <span>Pricing</span>
            </Link>
            <Link
              to="/booking"
              className={`flex items-center space-x-2 text-gray-300 hover:text-white transition-colors py-2 ${
                location.pathname === '/booking' ? 'text-white font-medium' : ''
              }`}
            >
              <Calendar size={18} />
              <span>Book Now</span>
            </Link>
            <Link
              to="/contact"
              className={`flex items-center space-x-2 text-gray-300 hover:text-white transition-colors py-2 ${
                location.pathname === '/contact' ? 'text-white font-medium' : ''
              }`}
            >
              <span>Contact</span>
            </Link>
            <Link
              to="/admin"
              className={`flex items-center space-x-2 text-gray-300 hover:text-white transition-colors py-2 ${
                location.pathname === '/admin' ? 'text-white font-medium' : ''
              }`}
            >
              <User size={18} />
              <span>Admin Portal</span>
            </Link>
            
            <div className="flex items-center space-x-4 pt-2 border-t border-gray-800">
              <a href="https://www.facebook.com/PPTVInstall/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="https://www.instagram.com/pptvinstall/" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="https://www.tiktok.com/@pptvinstall" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-blue-500 transition-colors" aria-label="TikTok">
                <TikTok size={20} />
              </a>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;