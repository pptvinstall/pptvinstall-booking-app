import React, { useState } from 'react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { useStaging } from '../../hooks/useStaging';
import ComingSoonBadge from '../common/ComingSoonBadge';
import { Send } from 'lucide-react';

interface ContactFormProps {
  className?: string;
}

const ContactForm: React.FC<ContactFormProps> = ({ className }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { isFeatureEnabled, showFeedback, simulateBackendCall } = useStaging();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Validate form
    if (!formData.firstName || !formData.email || !formData.message) {
      showFeedback(
        'Missing Information',
        'Please fill out all required fields.',
        'error'
      );
      setIsSubmitting(false);
      return;
    }
    
    try {
      // Check if contact form is enabled
      if (!isFeatureEnabled('enableContactForm')) {
        await simulateBackendCall(formData, true, 1000);
        showFeedback(
          'Form Submission Disabled',
          'The contact form is currently in staging mode. Your message has been logged but not sent.',
          'info'
        );
        console.log('Contact form data:', formData);
      } else {
        // Simulate successful API call
        await simulateBackendCall(formData, true, 1500);
        showFeedback(
          'Message Sent',
          'Thank you for your message. We will get back to you shortly.',
          'success'
        );
        // Reset form
        setFormData({
          firstName: '',
          lastName: '',
          email: '',
          phone: '',
          message: ''
        });
      }
    } catch (error) {
      showFeedback(
        'Submission Error',
        'There was an error sending your message. Please try again later.',
        'error'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className={className}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">Get in Touch</h2>
        {!isFeatureEnabled('enableContactForm') && (
          <ComingSoonBadge />
        )}
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4 animate-fadeIn">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input 
            label="First Name" 
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
            required 
            className="transition-all focus:ring-blue-500"
          />
          <Input 
            label="Last Name" 
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
            required 
            className="transition-all focus:ring-blue-500"
          />
        </div>
        <Input 
          label="Email" 
          type="email" 
          name="email"
          value={formData.email}
          onChange={handleChange}
          required 
          className="transition-all focus:ring-blue-500"
        />
        <Input 
          label="Phone" 
          type="tel" 
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          className="transition-all focus:ring-blue-500"
        />
        <div>
          <label className="block text-sm font-medium text-gray-200 mb-1">
            Message
          </label>
          <textarea
            className="flex w-full rounded-md border border-gray-700 bg-gray-800 px-3 py-2 text-sm text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            rows={5}
            placeholder="How can we help you?"
            name="message"
            value={formData.message}
            onChange={handleChange}
            required
          ></textarea>
        </div>
        <Button 
          type="submit" 
          disabled={isSubmitting}
          className="w-full md:w-auto transition-all"
        >
          {isSubmitting ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Sending...
            </>
          ) : (
            <>
              <Send className="h-4 w-4 mr-2" />
              Send Message
            </>
          )}
        </Button>
      </form>
    </div>
  );
};

export default ContactForm;