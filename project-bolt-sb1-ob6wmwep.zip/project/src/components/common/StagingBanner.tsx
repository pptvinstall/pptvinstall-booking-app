import React, { useState } from 'react';
import { AlertTriangle, X, Settings } from 'lucide-react';
import { getFeatureFlags, toggleFeatureFlag, FeatureFlags } from '../../config/features';

const StagingBanner: React.FC = () => {
  const [isOpen, setIsOpen] = useState(true);
  const [showFeatureToggles, setShowFeatureToggles] = useState(false);
  const featureFlags = getFeatureFlags();

  const handleToggleFeature = (key: keyof FeatureFlags) => {
    const newValue = toggleFeatureFlag(key);
    console.log(`Feature "${key}" set to: ${newValue}`);
    // Force a re-render
    window.location.reload();
  };

  if (!isOpen) return null;

  return (
    <div className="bg-yellow-600 text-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2" />
            <span className="font-medium">
              Staging Environment - Backend functionality is limited
            </span>
          </div>
          <div className="flex items-center">
            <button 
              onClick={() => setShowFeatureToggles(!showFeatureToggles)}
              className="mr-4 text-sm flex items-center hover:text-yellow-200 transition-colors"
            >
              <Settings className="h-4 w-4 mr-1" />
              {showFeatureToggles ? 'Hide Feature Toggles' : 'Show Feature Toggles'}
            </button>
            <button 
              onClick={() => setIsOpen(false)}
              className="p-1 hover:bg-yellow-700 rounded transition-colors"
              aria-label="Close banner"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {showFeatureToggles && (
          <div className="mt-3 bg-yellow-700 p-3 rounded animate-fadeIn">
            <h4 className="font-medium mb-2">Feature Toggles</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {(Object.keys(featureFlags) as Array<keyof FeatureFlags>).map((key) => (
                <div key={key} className="flex items-center">
                  <label className="inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      id={`feature-${key}`}
                      checked={featureFlags[key]}
                      onChange={() => handleToggleFeature(key)}
                      className="sr-only peer"
                    />
                    <div className="relative w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    <span className="ml-2 text-sm">
                      {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                    </span>
                  </label>
                </div>
              ))}
            </div>
            <p className="text-xs mt-2 text-yellow-200">
              Note: Toggling these features will reload the page
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default StagingBanner;