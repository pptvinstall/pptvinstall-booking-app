import React from 'react';
import { cn } from '../../lib/utils';

interface ComingSoonBadgeProps {
  className?: string;
}

const ComingSoonBadge: React.FC<ComingSoonBadgeProps> = ({ className }) => {
  return (
    <span 
      className={cn(
        "inline-block bg-blue-500/20 text-blue-400 text-xs px-2 py-1 rounded-full font-medium transition-all hover:bg-blue-500/30",
        className
      )}
    >
      Coming Soon
    </span>
  );
};

export default ComingSoonBadge;