import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import StagingBanner from './components/common/StagingBanner';
import FeedbackModal from './components/common/FeedbackModal';
import HomePage from './pages/HomePage';
import ServicesPage from './pages/ServicesPage';
import PricingPage from './pages/PricingPage';
import BookingPage from './pages/BookingPage';
import ContactPage from './pages/ContactPage';
import AdminLogin from './components/admin/AdminLogin';
import Dashboard from './components/admin/Dashboard';
import NotFoundPage from './pages/NotFoundPage';
import { useStaging } from './hooks/useStaging';

function App() {
  const { feedbackState, closeFeedback } = useStaging();

  return (
    <Router>
      <div className="flex flex-col min-h-screen bg-gray-900 text-white">
        {/* Staging Banner */}
        <StagingBanner />
        
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/pricing" element={<PricingPage />} />
            <Route path="/booking" element={<BookingPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/admin" element={<AdminLogin />} />
            <Route path="/admin/dashboard" element={<Dashboard />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
        <Footer />
        
        {/* Global Feedback Modal */}
        <FeedbackModal
          isOpen={feedbackState.isOpen}
          onClose={closeFeedback}
          title={feedbackState.title}
          message={feedbackState.message}
          type={feedbackState.type}
        />
      </div>
    </Router>
  );
}

export default App;