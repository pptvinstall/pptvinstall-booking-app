import React, { useState, useEffect } from 'react';
import { Calendar, FileText, Phone, Mail, User, Tv, DollarSign, Upload, Volume2, Lightbulb, ToggleLeft, ToggleRight, Video, PlusCircle, MinusCircle, Cable, Wrench, Info } from 'lucide-react';
import { pricingData } from '../data/pricingData';

interface TvMountingOption {
  location: 'wall' | 'fireplace';
  fireplaceType?: 'brick' | 'drywall';
  fireplacePhoto?: File | null;
  wireConcealment: boolean;
  soundbarInstallation: boolean;
}

interface FormData {
  fullName: string;
  phoneNumber: string;
  email: string;
  installationDate: string;
  notes: string;
  // TV Mounting Options
  includeTvMounting: boolean;
  tvOptions: TvMountingOption[];
  // Mount Selection
  needsMounts: boolean;
  mountType: string;
  mountCount: number;
  // Additional Services
  wireConcealmentStandalone: boolean;
  wireConcealmentCount: number;
  smartFloodlight: boolean;
  smartFloodlightCount: number;
  smartVideoDoorbell: boolean;
  smartVideoDoorbellCount: number;
  customInstallation: string;
}

interface PricingCalculation {
  basicMounting: number;
  fireplaceMounting: {
    drywall: number;
    brick: number;
  };
  mounts: number;
  wireConcealment: number;
  soundbar: number;
  smartFloodlight: number;
  smartVideoDoorbell: number;
  total: number;
  requiresEstimate: boolean;
}

// Pricing constants
const PRICES = {
  BASIC_MOUNTING: 100,
  FIREPLACE_MOUNTING_DRYWALL: 200,
  FIREPLACE_MOUNTING_BRICK: 250,
  SMALL_MOUNT: 40,
  MEDIUM_MOUNT: 50,
  LARGE_MOUNT: 65,
  FULL_MOTION_MOUNT: 80,
  WIRE_CONCEALMENT: 100,
  SMART_FLOODLIGHT: 125,
  SOUNDBAR: 50,
  SMART_VIDEO_DOORBELL: 85
};

function BookingPage() {
  const initialTvOption: TvMountingOption = {
    location: 'wall',
    wireConcealment: false,
    soundbarInstallation: false
  };

  const initialFormData: FormData = {
    fullName: '',
    phoneNumber: '',
    email: '',
    installationDate: '',
    notes: '',
    // TV Mounting Options
    includeTvMounting: true,
    tvOptions: [{ ...initialTvOption }],
    // Mount Selection
    needsMounts: false,
    mountType: 'small',
    mountCount: 0,
    // Additional Services
    wireConcealmentStandalone: false,
    wireConcealmentCount: 0,
    smartFloodlight: false,
    smartFloodlightCount: 0,
    smartVideoDoorbell: false,
    smartVideoDoorbellCount: 1,
    customInstallation: ''
  };

  const initialPricing: PricingCalculation = {
    basicMounting: 0,
    fireplaceMounting: {
      drywall: 0,
      brick: 0
    },
    mounts: 0,
    wireConcealment: 0,
    soundbar: 0,
    smartFloodlight: 0,
    smartVideoDoorbell: 0,
    total: 0,
    requiresEstimate: false
  };

  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [pricing, setPricing] = useState<PricingCalculation>(initialPricing);

  // Calculate pricing whenever form data changes
  useEffect(() => {
    calculateTotalPrice();
  }, [formData]);

  const calculateTotalPrice = () => {
    const newPricing = { ...initialPricing };
    
    if (formData.includeTvMounting) {
      // Calculate TV mounting costs
      formData.tvOptions.forEach((tv, index) => {
        // Basic mounting
        if (tv.location === 'wall') {
          newPricing.basicMounting += PRICES.BASIC_MOUNTING;
        } 
        // Fireplace mounting
        else if (tv.location === 'fireplace') {
          if (tv.fireplaceType === 'drywall') {
            newPricing.fireplaceMounting.drywall += PRICES.FIREPLACE_MOUNTING_DRYWALL;
          } else if (tv.fireplaceType === 'brick') {
            newPricing.fireplaceMounting.brick += PRICES.FIREPLACE_MOUNTING_BRICK;
          }
          
          // If fireplace mounting AND wire concealment, mark as requiring estimate
          if (tv.wireConcealment) {
            newPricing.requiresEstimate = true;
          }
        }
        
        // Wire concealment per TV (only count if not requiring estimate)
        if (tv.wireConcealment && tv.location !== 'fireplace') {
          newPricing.wireConcealment += PRICES.WIRE_CONCEALMENT;
        }
        
        // Soundbar installation per TV
        if (tv.soundbarInstallation) {
          newPricing.soundbar += PRICES.SOUNDBAR;
        }
      });
    }
    
    // Mounts
    if (formData.needsMounts && formData.mountCount > 0) {
      let mountPrice = 0;
      switch (formData.mountType) {
        case 'small':
          mountPrice = PRICES.SMALL_MOUNT;
          break;
        case 'medium':
          mountPrice = PRICES.MEDIUM_MOUNT;
          break;
        case 'large':
          mountPrice = PRICES.LARGE_MOUNT;
          break;
        case 'fullMotion':
          mountPrice = PRICES.FULL_MOTION_MOUNT;
          break;
      }
      newPricing.mounts = formData.mountCount * mountPrice;
    }
    
    // Standalone wire concealment
    if (formData.wireConcealmentStandalone && formData.wireConcealmentCount > 0) {
      newPricing.wireConcealment += formData.wireConcealmentCount * PRICES.WIRE_CONCEALMENT;
    }
    
    // Smart floodlight
    if (formData.smartFloodlight && formData.smartFloodlightCount > 0) {
      newPricing.smartFloodlight = formData.smartFloodlightCount * PRICES.SMART_FLOODLIGHT;
    }
    
    // Smart video doorbell
    if (formData.smartVideoDoorbell) {
      newPricing.smartVideoDoorbell = formData.smartVideoDoorbellCount * PRICES.SMART_VIDEO_DOORBELL;
    }
    
    // Calculate total
    newPricing.total = 
      newPricing.basicMounting + 
      newPricing.fireplaceMounting.drywall +
      newPricing.fireplaceMounting.brick +
      newPricing.mounts + 
      newPricing.wireConcealment + 
      newPricing.smartFloodlight + 
      newPricing.soundbar +
      newPricing.smartVideoDoorbell;
    
    setPricing(newPricing);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    
    // Handle checkbox inputs
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({
        ...prev,
        [name]: checked
      }));
    } 
    // Handle number inputs
    else if (type === 'number') {
      setFormData(prev => ({
        ...prev,
        [name]: parseInt(value) || 0
      }));
    } 
    // Handle all other inputs
    else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleTvOptionChange = (index: number, field: keyof TvMountingOption, value: any) => {
    setFormData(prev => {
      const updatedTvOptions = [...prev.tvOptions];
      updatedTvOptions[index] = {
        ...updatedTvOptions[index],
        [field]: value
      };
      
      // If changing location from fireplace to wall, clear fireplace-specific fields
      if (field === 'location' && value === 'wall') {
        delete updatedTvOptions[index].fireplaceType;
        delete updatedTvOptions[index].fireplacePhoto;
      }
      
      return {
        ...prev,
        tvOptions: updatedTvOptions
      };
    });
    
    // Clear errors for this TV option
    const errorKey = `tvOptions[${index}].${field}`;
    if (errors[errorKey]) {
      setErrors(prev => ({
        ...prev,
        [errorKey]: ''
      }));
    }
  };

  const handleFireplacePhotoChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleTvOptionChange(index, 'fireplacePhoto', e.target.files[0]);
    }
  };

  const addTvOption = () => {
    setFormData(prev => ({
      ...prev,
      tvOptions: [...prev.tvOptions, { ...initialTvOption }]
    }));
  };

  const removeTvOption = (index: number) => {
    if (formData.tvOptions.length > 1) {
      setFormData(prev => {
        const updatedTvOptions = [...prev.tvOptions];
        updatedTvOptions.splice(index, 1);
        return {
          ...prev,
          tvOptions: updatedTvOptions
        };
      });
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    // Validate required fields
    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }
    
    if (!formData.phoneNumber.trim()) {
      newErrors.phoneNumber = 'Phone number is required';
    } else if (!/^\d{10}$/.test(formData.phoneNumber.replace(/\D/g, ''))) {
      newErrors.phoneNumber = 'Please enter a valid 10-digit phone number';
    }
    
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (!formData.installationDate) {
      newErrors.installationDate = 'Please select a preferred date';
    }
    
    // Validate TV options if TV mounting is included
    if (formData.includeTvMounting) {
      formData.tvOptions.forEach((tv, index) => {
        // Validate fireplace options
        if (tv.location === 'fireplace') {
          if (!tv.fireplaceType) {
            newErrors[`tvOptions[${index}].fireplaceType`] = 'Please select fireplace type';
          }
        }
      });
    }
    
    // Validate mount count if mounts are needed
    if (formData.needsMounts && formData.mountCount <= 0) {
      newErrors.mountCount = 'Please select at least 1 mount';
    }
    
    // Validate wire concealment count
    if (formData.wireConcealmentStandalone && formData.wireConcealmentCount <= 0) {
      newErrors.wireConcealmentCount = 'Please select at least 1';
    }
    
    // Validate smart floodlight count
    if (formData.smartFloodlight && formData.smartFloodlightCount <= 0) {
      newErrors.smartFloodlightCount = 'Please select at least 1';
    }
    
    // Validate that at least one service is selected
    const hasAnyService = 
      formData.includeTvMounting || 
      (formData.needsMounts && formData.mountCount > 0) ||
      (formData.wireConcealmentStandalone && formData.wireConcealmentCount > 0) ||
      (formData.smartFloodlight && formData.smartFloodlightCount > 0) ||
      formData.smartVideoDoorbell;
    
    if (!hasAnyService) {
      newErrors.services = 'Please select at least one service';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      // Create a submission object that includes all form data plus pricing
      const submissionData = {
        ...formData,
        pricing
      };
      
      console.log('Form submitted with data:', submissionData);
      setIsSubmitted(true);
      // Reset form after submission
      setFormData(initialFormData);
      setPricing(initialPricing);
    }
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Book Your TV Installation</h1>
        <p className="text-gray-600">Fill out the form below to schedule your professional TV mounting service</p>
      </div>
      
      {isSubmitted ? (
        <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
          <div className="text-green-600 text-xl font-semibold mb-2">Booking Request Received!</div>
          <p className="text-gray-700 mb-4">Thank you for your booking request. We'll contact you shortly to confirm your appointment.</p>
          <button 
            onClick={() => setIsSubmitted(false)}
            className="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-6 rounded-md transition-colors duration-300"
          >
            Book Another Service
          </button>
        </div>
      ) : (
        <div className="bg-white p-8 rounded-lg shadow-md">
          <form onSubmit={handleSubmit}>
            {/* Customer Information Section */}
            <div className="mb-8">
              <h2 className="text-xl font-bold text-gray-800 mb-4 pb-2 border-b">Customer Information</h2>
              <div className="grid md:grid-cols-2 gap-6">
                {/* Full Name */}
                <div>
                  <label htmlFor="fullName" className="block text-gray-700 font-medium mb-2 flex items-center">
                    <User size={18} className="mr-2 text-blue-500" />
                    Full Name <span className="text-red-500 ml-1">*</span>
                  </label>
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleChange}
                    className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.fullName ? 'border-red-500' : 'border-gray-300'
                    }`}
                    placeholder="John Doe"
                  />
                  {errors.fullName && <p className="text-red-500 text-sm mt-1">{errors.fullName}</p>}
                </div>
                
                {/* Phone Number */}
                <div>
                  <label htmlFor="phoneNumber" className="block text-gray-700 font-medium mb-2 flex items-center">
                    <Phone size={18} className="mr-2 text-blue-500" />
                    Phone Number <span className="text-red-500 ml-1">*</span>
                  </label>
                  <input
                    type="tel"
                    id="phoneNumber"
                    name="phoneNumber"
                    value={formData.phoneNumber}
                    onChange={handleChange}
                    className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.phoneNumber ? 'border-red-500' : 'border-gray-300'
                    }`}
                    placeholder="(123) 456-7890"
                  />
                  {errors.phoneNumber && <p className="text-red-500 text-sm mt-1">{errors.phoneNumber}</p>}
                </div>
                
                {/* Email Address */}
                <div>
                  <label htmlFor="email" className="block text-gray-700 font-medium mb-2 flex items-center">
                    <Mail size={18} className="mr-2 text-blue-500" />
                    Email Address <span className="text-gray-500 text-sm ml-1">(Optional)</span>
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.email ? 'border-red-500' : 'border-gray-300'
                    }`}
                    placeholder="johndoe@example.com"
                  />
                  {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
                </div>
                
                {/* Preferred Installation Date */}
                <div>
                  <label htmlFor="installationDate" className="block text-gray-700 font-medium mb-2 flex items-center">
                    <Calendar size={18} className="mr-2 text-blue-500" />
                    Preferred Installation Date <span className="text-red-500 ml-1">*</span>
                  </label>
                  <input
                    type="date"
                    id="installationDate"
                    name="installationDate"
                    value={formData.installationDate}
                    onChange={handleChange}
                    min={today}
                    className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                      errors.installationDate ? 'border-red-500' : 'border-gray-300'
                    }`}
                  />
                  {errors.installationDate && <p className="text-red-500 text-sm mt-1">{errors.installationDate}</p>}
                </div>
              </div>
            </div>
            
            {/* Service Selection */}
            <div className="mb-8">
              <h2 className="text-xl font-bold text-gray-800 mb-4 pb-2 border-b">Service Selection</h2>
              <div className="mb-4">
                <label className="block text-gray-700 font-medium mb-2">
                  What services are you interested in? <span className="text-red-500 ml-1">*</span>
                </label>
                {errors.services && <p className="text-red-500 text-sm mb-2">{errors.services}</p>}
                
                <div className="flex items-center mb-4">
                  <input
                    type="checkbox"
                    id="includeTvMounting"
                    name="includeTvMounting"
                    checked={formData.includeTvMounting}
                    onChange={handleChange}
                    className="form-checkbox h-5 w-5 text-blue-600"
                  />
                  <label htmlFor="includeTvMounting" className="ml-2 font-medium">
                    TV Mounting
                  </label>
                </div>
              </div>
            </div>
            
            {/* TV Mounting Options Section (conditional) */}
            {formData.includeTvMounting && (
              <div className="mb-8 bg-gray-50 p-6 rounded-lg border border-gray-200">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-xl font-bold text-gray-800">TV Mounting Details</h2>
                  <button
                    type="button"
                    onClick={addTvOption}
                    className="flex items-center text-blue-600 hover:text-blue-800"
                  >
                    <PlusCircle size={18} className="mr-1" />
                    Add Another TV
                  </button>
                </div>
                
                {formData.tvOptions.map((tv, index) => (
                  <div key={index} className="mb-6 pb-6 border-b border-gray-200 last:border-b-0 last:mb-0 last:pb-0">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-bold text-gray-700">TV #{index + 1}</h3>
                      {formData.tvOptions.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeTvOption(index)}
                          className="flex items-center text-red-500 hover:text-red-700"
                        >
                          <MinusCircle size={18} className="mr-1" />
                          Remove
                        </button>
                      )}
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Mounting Location */}
                      <div>
                        <label className="block text-gray-700 font-medium mb-2">
                          Mounting Location
                        </label>
                        <div className="flex items-center space-x-4">
                          <label className="inline-flex items-center">
                            <input
                              type="radio"
                              checked={tv.location === 'wall'}
                              onChange={() => handleTvOptionChange(index, 'location', 'wall')}
                              className="form-radio h-5 w-5 text-blue-600"
                            />
                            <span className="ml-2">Regular Wall</span>
                          </label>
                          <label className="inline-flex items-center">
                            <input
                              type="radio"
                              checked={tv.location === 'fireplace'}
                              onChange={() => handleTvOptionChange(index, 'location', 'fireplace')}
                              className="form-radio h-5 w-5 text-blue-600"
                            />
                            <span className="ml-2">Above Fireplace</span>
                          </label>
                        </div>
                      </div>
                      
                      {/* Fireplace Type (conditional) */}
                      {tv.location === 'fireplace' && (
                        <div>
                          <label className="block text-gray-700 font-medium mb-2">
                            Fireplace Type <span className="text-red-500 ml-1">*</span>
                          </label>
                          <div className="flex items-center space-x-4">
                            <label className="inline-flex items-center">
                              <input
                                type="radio"
                                checked={tv.fireplaceType === 'drywall'}
                                onChange={() => handleTvOptionChange(index, 'fireplaceType', 'drywall')}
                                className="form-radio h-5 w-5 text-blue-600"
                              />
                              <span className="ml-2">Drywall</span>
                            </label>
                            <label className="inline-flex items-center">
                              <input
                                type="radio"
                                checked={tv.fireplaceType === 'brick'}
                                onChange={() => handleTvOptionChange(index, 'fireplaceType', 'brick')}
                                className="form-radio h-5 w-5 text-blue-600"
                              />
                              <span className="ml-2">Brick/Stone</span>
                            </label>
                          </div>
                          {errors[`tvOptions[${index}].fireplaceType`] && (
                            <p className="text-red-500 text-sm mt-1">{errors[`tvOptions[${index}].fireplaceType`]}</p>
                          )}
                        </div>
                      )}
                      
                      {/* Fireplace Photo Upload (conditional) */}
                      {tv.location === 'fireplace' && (
                        <div className="md:col-span-2">
                          <label htmlFor={`fireplacePhoto-${index}`} className="block text-gray-700 font-medium mb-2 flex items-center">
                            <Upload size={18} className="mr-2 text-blue-500" />
                            Upload a photo of your fireplace
                          </label>
                          <div className="flex items-center mb-2 text-sm text-blue-600">
                            <Info size={16} className="mr-1" />
                            <span>Uploading a picture helps us give a more accurate estimate!</span>
                          </div>
                          <div className={`border-2 border-dashed rounded-md p-4 text-center ${
                            errors[`tvOptions[${index}].fireplacePhoto`] ? 'border-red-500' : 'border-gray-300'
                          }`}>
                            <input
                              type="file"
                              id={`fireplacePhoto-${index}`}
                              accept="image/*"
                              onChange={(e) => handleFireplacePhotoChange(index, e)}
                              className="hidden"
                            />
                            <label htmlFor={`fireplacePhoto-${index}`} className="cursor-pointer">
                              <div className="flex flex-col items-center justify-center py-3">
                                <Upload size={24} className="text-blue-500 mb-2" />
                                <p className="text-sm text-gray-600 mb-1">
                                  {tv.fireplacePhoto 
                                    ? `Selected: ${tv.fireplacePhoto.name}` 
                                    : 'Click to upload or drag and drop'}
                                </p>
                                <p className="text-xs text-gray-500">JPG, PNG or GIF (max. 5MB)</p>
                              </div>
                            </label>
                          </div>
                          {errors[`tvOptions[${index}].fireplacePhoto`] && (
                            <p className="text-red-500 text-sm mt-1">{errors[`tvOptions[${index}].fireplacePhoto`]}</p>
                          )}
                        </div>
                      )}
                      
                      {/* Wire Concealment */}
                      <div>
                        <label className="inline-flex items-center">
                          <input
                            type="checkbox"
                            checked={tv.wireConcealment}
                            onChange={(e) => handleTvOptionChange(index, 'wireConcealment', e.target.checked)}
                            className="form-checkbox h-5 w-5 text-blue-600"
                          />
                          <span className="ml-2 font-medium">Wire Concealment</span>
                        </label>
                        {tv.location === 'fireplace' ? (
                          <p className="text-sm text-orange-600 ml-7 flex items-center">
                            <Info size={14} className="mr-1" />
                            We will provide an in-person estimate for this service
                          </p>
                        ) : (
                          <p className="text-sm text-gray-600 ml-7">${PRICES.WIRE_CONCEALMENT} per TV</p>
                        )}
                      </div>
                      
                      {/* Soundbar Installation */}
                      <div>
                        <label className="inline-flex items-center">
                          <input
                            type="checkbox"
                            checked={tv.soundbarInstallation}
                            onChange={(e) => handleTvOptionChange(index, 'soundbarInstallation', e.target.checked)}
                            className="form-checkbox h-5 w-5 text-blue-600"
                          />
                          <span className="ml-2 font-medium">Soundbar Installation</span>
                        </label>
                        <p className="text-sm text-gray-600 ml-7">${PRICES.SOUNDBAR} per TV</p>
                        <p className="text-xs text-blue-600 ml-7">Price includes mounting the soundbar with a customer-provided mount</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Mount Selection Section */}
            <div className="mb-8">
              <h2 className="text-xl font-bold text-gray-800 mb-4 pb-2 border-b">Mount Selection</h2>
              <div className="mb-4">
                <label className="block text-gray-700 font-medium mb-2">
                  Do you need TV mount(s)?
                </label>
                <div className="flex items-center space-x-4">
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      name="needsMounts"
                      checked={!formData.needsMounts}
                      onChange={() => setFormData(prev => ({ ...prev, needsMounts: false }))}
                      className="form-radio h-5 w-5 text-blue-600"
                    />
                    <span className="ml-2">No, I have my own</span>
                  </label>
                  <label className="inline-flex items-center">
                    <input
                      type="radio"
                      name="needsMounts"
                      checked={formData.needsMounts}
                      onChange={() => setFormData(prev => ({ ...prev, needsMounts: true }))}
                      className="form-radio h-5 w-5 text-blue-600"
                    />
                    <span className="ml-2">Yes, I need to purchase</span>
                  </label>
                </div>
              </div>
              
              {formData.needsMounts && (
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Mount Type */}
                  <div>
                    <label htmlFor="mountType" className="block text-gray-700 font-medium mb-2">
                      Type of Mount
                    </label>
                    <select
                      id="mountType"
                      name="mountType"
                      value={formData.mountType}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="small">Small Mount (32"-50") - ${PRICES.SMALL_MOUNT}</option>
                      <option value="medium">Medium Mount (51"-65") - ${PRICES.MEDIUM_MOUNT}</option>
                      <option value="large">Large Mount (66"-85") - ${PRICES.LARGE_MOUNT}</option>
                      <option value="fullMotion">Full-Motion Mount (Any size) - ${PRICES.FULL_MOTION_MOUNT}</option>
                    </select>
                  </div>
                  
                  {/* Mount Count */}
                  <div>
                    <label htmlFor="mountCount" className="block text-gray-700 font-medium mb-2">
                      Number of Mounts <span className="text-red-500 ml-1">*</span>
                    </label>
                    <select
                      id="mountCount"
                      name="mountCount"
                      value={formData.mountCount}
                      onChange={handleChange}
                      className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                        errors.mountCount ? 'border-red-500' : 'border-gray-300'
                      }`}
                    >
                      <option value="0">Select quantity</option>
                      {[1, 2, 3, 4, 5].map(num => (
                        <option key={num} value={num}>{num} Mount{num > 1 ? 's' : ''}</option>
                      ))}
                    </select>
                    {errors.mountCount && <p className="text-red-500 text-sm mt-1">{errors.mountCount}</p>}
                  </div>
                </div>
              )}
            </div>
            
            {/* Additional Services Section */}
            <div className="mb-8">
              <h2 className="text-xl font-bold text-gray-800 mb-4 pb-2 border-b">Additional Services</h2>
              <div className="space-y-6">
                {/* Standalone Wire Concealment */}
                <div className="grid md:grid-cols-2 gap-6 items-center">
                  <div>
                    <label className="inline-flex items-center">
                      <input
                        type="checkbox"
                        name="wireConcealmentStandalone"
                        checked={formData.wireConcealmentStandalone}
                        onChange={handleChange}
                        className="form-checkbox h-5 w-5 text-blue-600"
                      />
                      <span className="ml-2 font-medium">Wire Concealment & Outlet Relocation</span>
                    </label>
                    <p className="text-sm text-gray-600 ml-7">${PRICES.WIRE_CONCEALMENT} per location</p>
                  </div>
                  
                  {formData.wireConcealmentStandalone && (
                    <div>
                      <select
                        id="wireConcealmentCount"
                        name="wireConcealmentCount"
                        value={formData.wireConcealmentCount}
                        onChange={handleChange}
                        className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                          errors.wireConcealmentCount ? 'border-red-500' : 'border-gray-300'
                        }`}
                      >
                        <option value="0">Select quantity</option>
                        {[1, 2, 3, 4, 5].map(num => (
                          <option key={num} value={num}>{num} Location{num > 1 ? 's' : ''}</option>
                        ))}
                      </select>
                      {errors.wireConcealmentCount && <p className="text-red-500 text-sm mt-1">{errors.wireConcealmentCount}</p>}
                    </div>
                  )}
                </div>
                
                {/* Smart Floodlight Installation */}
                <div className="grid md:grid-cols-2 gap-6 items-center">
                  <div>
                    <label className="inline-flex items-center">
                      <input
                        type="checkbox"
                        name="smartFloodlight"
                        checked={formData.smartFloodlight}
                        onChange={handleChange}
                        className="form-checkbox h-5 w-5 text-blue-600"
                      />
                      <span className="ml-2 font-medium">Smart Floodlight Installation</span>
                    </label>
                    <p className="text-sm text-gray-600 ml-7">${PRICES.SMART_FLOODLIGHT} per floodlight</p>
                    <p className="text-xs text-blue-600 ml-7">This price applies to both wired and wireless setups. If choosing wireless, existing wiring must be present.</p>
                  </div>
                  
                  {formData.smartFloodlight && (
                    <div>
                      <select
                        id="smartFloodlightCount"
                        name="smartFloodlightCount"
                        value={formData.smartFloodlightCount}
                        onChange={handleChange}
                        className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                          errors.smartFloodlightCount ? 'border-red-500' : 'border-gray-300'
                        }`}
                      >
                        <option value="0">Select quantity</option>
                        {[1, 2, 3, 4].map(num => (
                          <option key={num} value={num}>{num} Floodlight{num > 1 ? 's' : ''}</option>
                        ))}
                      </select>
                      {errors.smartFloodlightCount && <p className="text-red-500 text-sm mt-1">{errors.smartFloodlightCount}</p>}
                    </div>
                  )}
                </div>
                
                {/* Smart Video Doorbell */}
                <div className="grid md:grid-cols-2 gap-6 items-center">
                  <div>
                    <label className="inline-flex items-center">
                      <input
                        type="checkbox"
                        name="smartVideoDoorbell"
                        checked={formData.smartVideoDoorbell}
                        onChange={handleChange}
                        className="form-checkbox h-5 w-5 text-blue-600"
                      />
                      <span className="ml-2 font-medium">Smart Video Doorbell Installation</span>
                    </label>
                    <p className="text-sm text-gray-600 ml-7">${PRICES.SMART_VIDEO_DOORBELL} per doorbell</p>
                  </div>
                  
                  {formData.smartVideoDoorbell && (
                    <div>
                      <select
                        id="smartVideoDoorbellCount"
                        name="smartVideoDoorbellCount"
                        value={formData.smartVideoDoorbellCount}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        {[1, 2, 3].map(num => (
                          <option key={num} value={num}>{num} Doorbell{num > 1 ? 's' : ''}</option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            {/* Custom Installation Requests */}
            <div className="mb-8">
              <label htmlFor="customInstallation" className="block text-gray-700 font-medium mb-2 flex items-center">
                <Wrench size={18} className="mr-2 text-blue-500" />
                Custom Installation Requests <span className="text-gray-500 text-sm ml-1">(Optional)</span>
              </label>
              <textarea
                id="customInstallation"
                name="customInstallation"
                value={formData.customInstallation}
                onChange={handleChange}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Describe any custom installation needs or special requirements..."
              ></textarea>
            </div>
            
            {/* Additional Notes */}
            <div className="mb-8">
              <label htmlFor="notes" className="block text-gray-700 font-medium mb-2 flex items-center">
                <FileText size={18} className="mr-2 text-blue-500" />
                Additional Notes <span className="text-gray-500 text-sm ml-1">(Optional)</span>
              </label>
              <textarea
                id="notes"
                name="notes"
                value={formData.notes}
                onChange={handleChange}
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Tell us about any special requirements or questions you have..."
              ></textarea>
            </div>
            
            {/* Price Summary */}
            <div className="mb-8 bg-gray-50 p-6 rounded-lg border border-gray-200">
              <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <DollarSign size={20} className="mr-2 text-green-600" />
                Estimated Price
              </h2>
              <div className="space-y-2">
                {/* TV Mounting */}
                {pricing.basicMounting > 0 && (
                  <div className="flex justify-between">
                    <span>Basic TV Mounting ({formData.tvOptions.filter(tv => tv.location === 'wall').length} TV{formData.tvOptions.filter(tv => tv.location === 'wall').length !== 1 ? 's' : ''})</span>
                    <span>${pricing.basicMounting}</span>
                  </div>
                )}
                
                {/* Fireplace Mounting - Drywall */}
                {pricing.fireplaceMounting.drywall > 0 && (
                  <div className="flex justify-between">
                    <span>Fireplace Installation - Drywall ({formData.tvOptions.filter(tv => tv.location === 'fireplace' && tv.fireplaceType === 'drywall').length} TV{formData.tvOptions.filter(tv => tv.location === 'fireplace' && tv.fireplaceType === 'drywall').length !== 1 ? 's' : ''})</span>
                    <span>${pricing.fireplaceMounting.drywall}</span>
                  </div>
                )}
                
                {/* Fireplace Mounting - Brick */}
                {pricing.fireplaceMounting.brick > 0 && (
                  <div className="flex justify-between">
                    <span>Fireplace Installation - Brick/Stone ({formData.tvOptions.filter(tv => tv.location === 'fireplace' && tv.fireplaceType === 'brick').length} TV{formData.tvOptions.filter(tv => tv.location === 'fireplace' && tv.fireplaceType === 'brick').length !== 1 ? 's' : ''})</span>
                    <span>${pricing.fireplaceMounting.brick}</span>
                  </div>
                )}
                
                {/* Mounts */}
                {pricing.mounts > 0 && (
                  <div className="flex justify-between">
                    <span>
                      {formData.mountType === 'small' && 'Small Mount (32"-50")'}
                      {formData.mountType === 'medium' && 'Medium Mount (51"-65")'}
                      {formData.mountType === 'large' && 'Large Mount (66"-85")'}
                      {formData.mountType === 'fullMotion' && 'Full-Motion Mount (Any size)'}
                      {' ('}{formData.mountCount}{')'}
                    </span>
                    <span>${pricing.mounts}</span>
                  </div>
                )}
                
                {/* Wire Concealment */}
                {pricing.wireConcealment > 0 && (
                  <div className="flex justify-between">
                    <span>
                      Wire Concealment (
                      {formData.tvOptions.filter(tv => tv.wireConcealment && tv.location !== 'fireplace').length + 
                       (formData.wireConcealmentStandalone ? formData.wireConcealmentCount : 0)} 
                      {formData.tvOptions.filter(tv => tv.wireConcealment && tv.location !== 'fireplace').length > 0 && 
                       formData.wireConcealmentStandalone && formData.wireConcealmentCount > 0 ? 
                       ' total' : ''} location{(formData.tvOptions.filter(tv => tv.wireConcealment && tv.location !== 'fireplace').length + 
                       (formData.wireConcealmentStandalone ? formData.wireConcealmentCount : 0)) !== 1 ? 's' : ''})
                    </span>
                    <span>${pricing.wireConcealment}</span>
                  </div>
                )}
                
                {/* Soundbar Installation */}
                {pricing.soundbar > 0 && (
                  <div className="flex justify-between">
                    <span>
                      Soundbar Installation ({formData.tvOptions.filter(tv => tv.soundbarInstallation).length} 
                      soundbar{formData.tvOptions.filter(tv => tv.soundbarInstallation).length !== 1 ? 's' : ''})
                    </span>
                    <span>${pricing.soundbar}</span>
                  </div>
                )}
                
                {/* Smart Floodlight */}
                {pricing.smartFloodlight > 0 && (
                  <div className="flex justify-between">
                    <span>Smart Floodlight ({formData.smartFloodlightCount} Unit{formData.smartFloodlightCount !== 1 ? 's' : ''})</span>
                    <span>${pricing.smartFloodlight}</span>
                  </div>
                )}
                
                {/* Smart Video Doorbell */}
                {pricing.smartVideoDoorbell > 0 && (
                  <div className="flex justify-between">
                    <span>Smart Video Doorbell ({formData.smartVideoDoorbellCount} Unit{formData.smartVideoDoorbellCount !== 1 ? 's' : ''})</span>
                    <span>${pricing.smartVideoDoorbell}</span>
                  </div>
                )}
                
                {/* Fireplace Wire Concealment - Requires Estimate */}
                {formData.tvOptions.some(tv => tv.location === 'fireplace' && tv.wireConcealment) && (
                  <div className="flex justify-between text-orange-600 font-medium">
                    <span>Fireplace Wire Concealment</span>
                    <span>Requires in-person estimate</span>
                  </div>
                )}
                
                {/* Total */}
                <div className="border-t border-gray-300 pt-2 <div className="border-t border-gray-300 pt-2 mt-2">
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total Estimate</span>
                    <span className="text-green-600">${pricing.total}</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Submit Button */}
            <div className="text-center">
              <button 
                type="submit"
                className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-8 rounded-md transition-colors duration-300"
              >
                Submit Booking Request
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

export default BookingPage;